#  (c) Copyright 2025 Palantir Technologies Inc. All rights reserved.

import logging
from typing import Optional

from foundry_sdk.v2.ontologies import OntologiesClient
from foundry_sdk.v2.ontologies.models import ObjectSetReferenceType
from foundry_sdk_runtime.decorators import beta
from foundry_sdk_runtime.ontology_object_set import OntologyObjectSet
from foundry_sdk_runtime.properties import ObjectTypeProperty
from foundry_sdk_runtime.properties.helpers import validate_property_list
from physical_ai_qa_cell_sdk.ontology.objects import ModelRegistry
from typing_extensions import Self

from ..search import ModelRegistryObjectType

logger = logging.getLogger(__name__)


class ModelRegistryObjectSet(OntologyObjectSet[ModelRegistry]):
    """
    Model versions and lifecycle management.

    Edge agents poll for new published versions and hot-swap on the Jetson.
    """

    _BASE_OBJECT_CLASS = ModelRegistry

    @staticmethod
    def object_type_api_name() -> str:
        return "ModelRegistry"

    @classmethod
    def init_from_object_set_rid(
        cls,
        object_set_rid: str,
        _ontologies_client: Optional[OntologiesClient] = None,
    ) -> Self:
        # You must have context variables or environment variables set for FoundryClient to be initialized
        from physical_ai_qa_cell_sdk import FoundryClient

        client = (
            FoundryClient._init_from_ontologies_client(ontologies_client=_ontologies_client)
            if _ontologies_client
            else FoundryClient()
        )
        return ModelRegistryObjectSet(
            _ontologies_client=client.foundry_sdk.ontologies,
            _ontology_rid=client.ontology.rid,
            object_set_type=ObjectSetReferenceType(reference=object_set_rid),
        )

    def get(
        self, model_id, properties: Optional[list[ObjectTypeProperty]] = None, include_rid: bool = False
    ) -> Optional[ModelRegistry]:
        validate_property_list(properties)
        object_list = self.where(ModelRegistryObjectType.model_id == model_id).take(
            num_items=1,
            properties=properties,
            include_rid=include_rid,
        )
        if len(object_list) > 0:
            return object_list[0]
        else:
            return None

    @beta("async features are in beta and may change in future versions.")
    async def async_get(
        self, model_id, properties: Optional[list[ObjectTypeProperty]] = None, include_rid: bool = False
    ) -> Optional[ModelRegistry]:
        validate_property_list(properties)
        object_list = await self.where(ModelRegistryObjectType.model_id == model_id).async_take(
            num_items=1,
            properties=properties,
            include_rid=include_rid,
        )
        if len(object_list) > 0:
            return object_list[0]
        else:
            return None
