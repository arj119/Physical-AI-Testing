#  (c) Copyright 2025 Palantir Technologies Inc. All rights reserved.

import logging
from typing import TYPE_CHECKING, Optional

from foundry_sdk.v2.ontologies import OntologiesClient
from foundry_sdk.v2.ontologies.models import ObjectSetReferenceType, ObjectSetSearchAroundType
from foundry_sdk_runtime.decorators import beta
from foundry_sdk_runtime.ontology_object_set import BaseOntologyObjectSet, OntologyObjectSet
from foundry_sdk_runtime.properties import ObjectTypeProperty
from foundry_sdk_runtime.properties.helpers import validate_property_list
from physical_ai_qa_cell_sdk.ontology.objects import GripReading
from physical_ai_qa_cell_sdk.ontology.objects.grip_reading.__links import LinkApiNames
from typing_extensions import Self

from ..search import GripReadingObjectType

if TYPE_CHECKING:
    from physical_ai_qa_cell_sdk.ontology.object_sets._inspection_event import InspectionEventObjectSet
    from physical_ai_qa_cell_sdk.ontology.object_sets._robot import RobotObjectSet


logger = logging.getLogger(__name__)


class GripReadingObjectSet(OntologyObjectSet[GripReading]):
    """
    Individual gripper servo load measurements from the myCobot 280.

    Streamed in real-time from the Jetson Nano via Foundry Streams.
    """

    _BASE_OBJECT_CLASS = GripReading

    @staticmethod
    def object_type_api_name() -> str:
        return "GripReading"

    @classmethod
    def init_from_object_set_rid(
        cls,
        object_set_rid: str,
        _ontologies_client: Optional[OntologiesClient] = None,
    ) -> Self:
        # You must have context variables or environment variables set for FoundryClient to be initialized
        from physical_ai_qa_cell_sdk import FoundryClient

        client = (
            FoundryClient._init_from_ontologies_client(ontologies_client=_ontologies_client)
            if _ontologies_client
            else FoundryClient()
        )
        return GripReadingObjectSet(
            _ontologies_client=client.foundry_sdk.ontologies,
            _ontology_rid=client.ontology.rid,
            object_set_type=ObjectSetReferenceType(reference=object_set_rid),
        )

    def get(
        self, reading_id, properties: Optional[list[ObjectTypeProperty]] = None, include_rid: bool = False
    ) -> Optional[GripReading]:
        validate_property_list(properties)
        object_list = self.where(GripReadingObjectType.reading_id == reading_id).take(
            num_items=1,
            properties=properties,
            include_rid=include_rid,
        )
        if len(object_list) > 0:
            return object_list[0]
        else:
            return None

    @beta("async features are in beta and may change in future versions.")
    async def async_get(
        self, reading_id, properties: Optional[list[ObjectTypeProperty]] = None, include_rid: bool = False
    ) -> Optional[GripReading]:
        validate_property_list(properties)
        object_list = await self.where(GripReadingObjectType.reading_id == reading_id).async_take(
            num_items=1,
            properties=properties,
            include_rid=include_rid,
        )
        if len(object_list) > 0:
            return object_list[0]
        else:
            return None

    def search_around_inspection_event(self) -> "InspectionEventObjectSet":
        from physical_ai_qa_cell_sdk.ontology.object_sets._inspection_event import InspectionEventObjectSet

        return InspectionEventObjectSet(
            _ontologies_client=self._ontologies_client,
            _ontology_rid=self._ontology_rid,
            object_set_type=ObjectSetSearchAroundType(
                objectSet=self._object_set_type, link="inspectionEvent", type="searchAround"
            ),
        )

    def search_around_robot(self) -> "RobotObjectSet":
        from physical_ai_qa_cell_sdk.ontology.object_sets._robot import RobotObjectSet

        return RobotObjectSet(
            _ontologies_client=self._ontologies_client,
            _ontology_rid=self._ontology_rid,
            object_set_type=ObjectSetSearchAroundType(
                objectSet=self._object_set_type, link="robot", type="searchAround"
            ),
        )

    def search_around(self, link_name: LinkApiNames) -> BaseOntologyObjectSet:
        search_around_methods = {
            "inspectionEvent": self.search_around_inspection_event,
            "robot": self.search_around_robot,
        }
        try:
            return search_around_methods[link_name]()
        except KeyError:
            raise RuntimeError(f"No object set found for the given link API name: '{link_name}'")
