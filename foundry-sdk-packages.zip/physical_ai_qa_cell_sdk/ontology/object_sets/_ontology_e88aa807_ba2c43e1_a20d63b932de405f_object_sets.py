from foundry_sdk.v2.ontologies import OntologiesClient
from physical_ai_qa_cell_sdk.ontology.object_sets._grip_reading import GripReadingObjectSet
from physical_ai_qa_cell_sdk.ontology.object_sets._inspection_event import InspectionEventObjectSet
from physical_ai_qa_cell_sdk.ontology.object_sets._model_registry import ModelRegistryObjectSet
from physical_ai_qa_cell_sdk.ontology.object_sets._operator_command import OperatorCommandObjectSet
from physical_ai_qa_cell_sdk.ontology.object_sets._robot import RobotObjectSet
from physical_ai_qa_cell_sdk.ontology.object_sets._sensor import SensorObjectSet
from physical_ai_qa_cell_sdk.ontology.object_sets._vision_reading import VisionReadingObjectSet


class OntologyE88aa807Ba2c43e1A20d63b932de405fObjectSets:

    def __init__(self, _ontologies_client: OntologiesClient, _ontology_rid: str) -> None:
        self._ontologies_client = _ontologies_client
        self._ontology_rid = _ontology_rid

    @property
    def GripReading(self) -> GripReadingObjectSet:
        return GripReadingObjectSet(self._ontologies_client, self._ontology_rid)

    @property
    def InspectionEvent(self) -> InspectionEventObjectSet:
        return InspectionEventObjectSet(self._ontologies_client, self._ontology_rid)

    @property
    def ModelRegistry(self) -> ModelRegistryObjectSet:
        return ModelRegistryObjectSet(self._ontologies_client, self._ontology_rid)

    @property
    def OperatorCommand(self) -> OperatorCommandObjectSet:
        return OperatorCommandObjectSet(self._ontologies_client, self._ontology_rid)

    @property
    def Robot(self) -> RobotObjectSet:
        return RobotObjectSet(self._ontologies_client, self._ontology_rid)

    @property
    def Sensor(self) -> SensorObjectSet:
        return SensorObjectSet(self._ontologies_client, self._ontology_rid)

    @property
    def VisionReading(self) -> VisionReadingObjectSet:
        return VisionReadingObjectSet(self._ontologies_client, self._ontology_rid)
