#  (c) Copyright 2025 Palantir Technologies Inc. All rights reserved.

import logging
from typing import TYPE_CHECKING, Optional

from foundry_sdk.v2.ontologies import OntologiesClient
from foundry_sdk.v2.ontologies.models import ObjectSetReferenceType, ObjectSetSearchAroundType
from foundry_sdk_runtime.decorators import beta
from foundry_sdk_runtime.ontology_object_set import BaseOntologyObjectSet, OntologyObjectSet
from foundry_sdk_runtime.properties import ObjectTypeProperty
from foundry_sdk_runtime.properties.helpers import validate_property_list
from physical_ai_qa_cell_sdk.ontology.objects import Robot
from physical_ai_qa_cell_sdk.ontology.objects.robot.__links import LinkApiNames
from typing_extensions import Self

from ..search import RobotObjectType

if TYPE_CHECKING:
    from physical_ai_qa_cell_sdk.ontology.object_sets._grip_reading import GripReadingObjectSet
    from physical_ai_qa_cell_sdk.ontology.object_sets._inspection_event import InspectionEventObjectSet
    from physical_ai_qa_cell_sdk.ontology.object_sets._operator_command import OperatorCommandObjectSet
    from physical_ai_qa_cell_sdk.ontology.object_sets._sensor import SensorObjectSet
    from physical_ai_qa_cell_sdk.ontology.object_sets._vision_reading import VisionReadingObjectSet


logger = logging.getLogger(__name__)


class RobotObjectSet(OntologyObjectSet[Robot]):
    """
    Physical robot in the QA cell.

    Tracks status, configuration, and heartbeat. Updated by the edge agent via OSDK.
    """

    _BASE_OBJECT_CLASS = Robot

    @staticmethod
    def object_type_api_name() -> str:
        return "Robot"

    @classmethod
    def init_from_object_set_rid(
        cls,
        object_set_rid: str,
        _ontologies_client: Optional[OntologiesClient] = None,
    ) -> Self:
        # You must have context variables or environment variables set for FoundryClient to be initialized
        from physical_ai_qa_cell_sdk import FoundryClient

        client = (
            FoundryClient._init_from_ontologies_client(ontologies_client=_ontologies_client)
            if _ontologies_client
            else FoundryClient()
        )
        return RobotObjectSet(
            _ontologies_client=client.foundry_sdk.ontologies,
            _ontology_rid=client.ontology.rid,
            object_set_type=ObjectSetReferenceType(reference=object_set_rid),
        )

    def get(
        self, robot_id, properties: Optional[list[ObjectTypeProperty]] = None, include_rid: bool = False
    ) -> Optional[Robot]:
        validate_property_list(properties)
        object_list = self.where(RobotObjectType.robot_id == robot_id).take(
            num_items=1,
            properties=properties,
            include_rid=include_rid,
        )
        if len(object_list) > 0:
            return object_list[0]
        else:
            return None

    @beta("async features are in beta and may change in future versions.")
    async def async_get(
        self, robot_id, properties: Optional[list[ObjectTypeProperty]] = None, include_rid: bool = False
    ) -> Optional[Robot]:
        validate_property_list(properties)
        object_list = await self.where(RobotObjectType.robot_id == robot_id).async_take(
            num_items=1,
            properties=properties,
            include_rid=include_rid,
        )
        if len(object_list) > 0:
            return object_list[0]
        else:
            return None

    def search_around_grip_readings(self) -> "GripReadingObjectSet":
        from physical_ai_qa_cell_sdk.ontology.object_sets._grip_reading import GripReadingObjectSet

        return GripReadingObjectSet(
            _ontologies_client=self._ontologies_client,
            _ontology_rid=self._ontology_rid,
            object_set_type=ObjectSetSearchAroundType(
                objectSet=self._object_set_type, link="gripReadings", type="searchAround"
            ),
        )

    def search_around_inspection_events(self) -> "InspectionEventObjectSet":
        from physical_ai_qa_cell_sdk.ontology.object_sets._inspection_event import InspectionEventObjectSet

        return InspectionEventObjectSet(
            _ontologies_client=self._ontologies_client,
            _ontology_rid=self._ontology_rid,
            object_set_type=ObjectSetSearchAroundType(
                objectSet=self._object_set_type, link="inspectionEvents", type="searchAround"
            ),
        )

    def search_around_operator_commands(self) -> "OperatorCommandObjectSet":
        from physical_ai_qa_cell_sdk.ontology.object_sets._operator_command import OperatorCommandObjectSet

        return OperatorCommandObjectSet(
            _ontologies_client=self._ontologies_client,
            _ontology_rid=self._ontology_rid,
            object_set_type=ObjectSetSearchAroundType(
                objectSet=self._object_set_type, link="operatorCommands", type="searchAround"
            ),
        )

    def search_around_sensors(self) -> "SensorObjectSet":
        from physical_ai_qa_cell_sdk.ontology.object_sets._sensor import SensorObjectSet

        return SensorObjectSet(
            _ontologies_client=self._ontologies_client,
            _ontology_rid=self._ontology_rid,
            object_set_type=ObjectSetSearchAroundType(
                objectSet=self._object_set_type, link="sensors", type="searchAround"
            ),
        )

    def search_around_vision_readings(self) -> "VisionReadingObjectSet":
        from physical_ai_qa_cell_sdk.ontology.object_sets._vision_reading import VisionReadingObjectSet

        return VisionReadingObjectSet(
            _ontologies_client=self._ontologies_client,
            _ontology_rid=self._ontology_rid,
            object_set_type=ObjectSetSearchAroundType(
                objectSet=self._object_set_type, link="visionReadings", type="searchAround"
            ),
        )

    def search_around(self, link_name: LinkApiNames) -> BaseOntologyObjectSet:
        search_around_methods = {
            "gripReadings": self.search_around_grip_readings,
            "inspectionEvents": self.search_around_inspection_events,
            "operatorCommands": self.search_around_operator_commands,
            "sensors": self.search_around_sensors,
            "visionReadings": self.search_around_vision_readings,
        }
        try:
            return search_around_methods[link_name]()
        except KeyError:
            raise RuntimeError(f"No object set found for the given link API name: '{link_name}'")
