class OntologyE88aa807Ba2c43e1A20d63b932de405fQueryTypes:
    """
    Ontology query types.

    Enables the following syntax to access query types on an ontology:

    .. code-block:: python

        client.ontology.queries.my_query(...)

    Attributes:
        _ontologies_client: The client to use for requests against the ontology
        _functions_client: The client to use for requests against functions service
        _ontology_rid: The ontology requests are made against
    """

    def __init__(
        self, _ontologies_client: "OntologiesClient", _functions_client: "FunctionsClient", _ontology_rid: str
    ) -> None:
        self._ontologies_client = _ontologies_client
        self._functions_client = _functions_client
        self._ontology_rid = _ontology_rid
