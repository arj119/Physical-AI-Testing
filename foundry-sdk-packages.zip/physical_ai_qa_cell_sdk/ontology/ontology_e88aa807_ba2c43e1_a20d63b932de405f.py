#  (c) Copyright 2024 Palantir Technologies Inc. All rights reserved.
from typing import TYPE_CHECKING

from foundry_sdk.v2.ontologies import OntologiesClient
from foundry_sdk_runtime.attachments import Attachments
from foundry_sdk_runtime.decorators import beta
from foundry_sdk_runtime.media import MediaSet
from physical_ai_qa_cell_sdk.ontology.action_types._ontology_e88aa807_ba2c43e1_a20d63b932de405f_action_types import (
    OntologyE88aa807Ba2c43e1A20d63b932de405fActionTypes,
)
from physical_ai_qa_cell_sdk.ontology.action_types._ontology_e88aa807_ba2c43e1_a20d63b932de405f_batch_action_types import (
    OntologyE88aa807Ba2c43e1A20d63b932de405fBatchActionTypes,
)
from physical_ai_qa_cell_sdk.ontology.edits._ontology_e88aa807_ba2c43e1_a20d63b932de405f_edits import (
    OntologyE88aa807Ba2c43e1A20d63b932de405fEdits,
)
from physical_ai_qa_cell_sdk.ontology.object_sets._ontology_e88aa807_ba2c43e1_a20d63b932de405f_object_sets import (
    OntologyE88aa807Ba2c43e1A20d63b932de405fObjectSets,
)
from physical_ai_qa_cell_sdk.ontology.query_types._ontology_e88aa807_ba2c43e1_a20d63b932de405f_query_types import (
    OntologyE88aa807Ba2c43e1A20d63b932de405fQueryTypes,
)

if TYPE_CHECKING:
    from foundry_sdk.v2.functions import FunctionsClient


class OntologyE88aa807Ba2c43e1A20d63b932de405f:
    """Ontology."""

    def __init__(self, _ontologies_client: OntologiesClient, _functions_client: "FunctionsClient", _ontology_rid: str):
        self._ontologies_client = _ontologies_client
        self._functions_client = _functions_client
        self._ontology_rid = _ontology_rid

    @property
    def api_name(self):
        return "ontology-e88aa807-ba2c-43e1-a20d-63b932de405f"

    @property
    def display_name(self):
        return "Modeling Guild-5f4bf2 Ontology"

    @property
    def rid(self):
        return self._ontology_rid

    @property
    def objects(self):
        return OntologyE88aa807Ba2c43e1A20d63b932de405fObjectSets(self._ontologies_client, self._ontology_rid)

    @property
    def attachments(self):
        return Attachments(self._ontologies_client)

    @property
    @beta("Media types are in beta and may change in future versions.")
    def media(self):
        return MediaSet(self._ontologies_client)

    @property
    def actions(self):
        return OntologyE88aa807Ba2c43e1A20d63b932de405fActionTypes(self._ontologies_client, self._ontology_rid)

    @property
    def batch_actions(self):
        return OntologyE88aa807Ba2c43e1A20d63b932de405fBatchActionTypes(self._ontologies_client, self._ontology_rid)

    @property
    def queries(self):
        return OntologyE88aa807Ba2c43e1A20d63b932de405fQueryTypes(
            self._ontologies_client, self._functions_client, self._ontology_rid
        )

    def edits(self):
        return OntologyE88aa807Ba2c43e1A20d63b932de405fEdits(self._ontologies_client, self._ontology_rid)
