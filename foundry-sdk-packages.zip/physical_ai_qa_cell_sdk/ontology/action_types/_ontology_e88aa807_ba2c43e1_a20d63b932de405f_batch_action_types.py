from functools import reduce
from typing import Iterable, Optional

from foundry_sdk.v2.ontologies import OntologiesClient
from foundry_sdk.v2.ontologies.models import BatchApplyActionRequestItem, BatchApplyActionRequestOptions
from foundry_sdk_runtime.actions import BatchApplyActionResponse
from foundry_sdk_runtime.client import RequestContextOverriddenClient
from foundry_sdk_runtime.types import BatchActionConfig, _get_action_return_edits
from physical_ai_qa_cell_sdk.ontology.action_types import (
    AcknowledgeCommandBatchRequest,
    CreateInspectionEventBatchRequest,
    CreateRobotBatchRequest,
    CreateSensorBatchRequest,
    PublishModelBatchRequest,
    ReviewInspectionEventBatchRequest,
    SendCommandBatchRequest,
    UpdateRobotStatusBatchRequest,
)


class OntologyE88aa807Ba2c43e1A20d63b932de405fBatchActionTypes:
    """
    Ontology batch action types.

    Enables the following syntax to access action types on an ontology:

    .. code-block:: python

        client.ontology.batch_actions.my_action(...)

    Attributes:
        _ontologies_client: The client to use for all requests.
        _ontology_rid: The ontology requests are made against
    """

    def __init__(self, _ontologies_client: OntologiesClient, _ontology_rid: str) -> None:
        self._ontologies_client = _ontologies_client
        self._ontology_rid = _ontology_rid

    def acknowledge_command(
        self,
        batch_action_config: Optional[BatchActionConfig] = None,
        requests: Optional[Iterable[AcknowledgeCommandBatchRequest]] = None,
    ) -> BatchApplyActionResponse:
        requests = requests or []
        """
        Called by the edge agent when it picks up and executes a command.

        Updates the command status and execution timestamp.
        """
        if not isinstance(requests, Iterable):
            raise TypeError("requests need to be an Iterable.")
        for request in requests:
            if not isinstance(request, AcknowledgeCommandBatchRequest):
                raise TypeError(f"{request} is not an instance of AcknowledgeCommandBatchRequest")
        if batch_action_config != None and not isinstance(batch_action_config, BatchActionConfig):
            raise ValueError("batch_action_config must be of type BatchActionConfig.")
        batch_action_config = batch_action_config or BatchActionConfig()
        with RequestContextOverriddenClient(
            self._ontologies_client.Action,
            {
                "nullParameters": list(
                    reduce(lambda null_param_list, request: null_param_list + request._null_params, requests, [])
                )
            },
        ) as client:
            response = client.apply_batch(
                ontology=self._ontology_rid,
                action="acknowledge-command",
                requests=[BatchApplyActionRequestItem.model_validate(req.to_json()) for req in requests],
                options=BatchApplyActionRequestOptions.model_validate(
                    {"returnEdits": _get_action_return_edits(batch_action_config.return_edits, batch=True)}
                ),
            )
        return BatchApplyActionResponse.model_validate(response.to_dict())

    def create_inspection_event(
        self,
        batch_action_config: Optional[BatchActionConfig] = None,
        requests: Optional[Iterable[CreateInspectionEventBatchRequest]] = None,
    ) -> BatchApplyActionResponse:
        requests = requests or []
        """
        Called by the edge agent after each sensor fusion cycle.

        Creates an InspectionEvent with the fusion decision.
        """
        if not isinstance(requests, Iterable):
            raise TypeError("requests need to be an Iterable.")
        for request in requests:
            if not isinstance(request, CreateInspectionEventBatchRequest):
                raise TypeError(f"{request} is not an instance of CreateInspectionEventBatchRequest")
        if batch_action_config != None and not isinstance(batch_action_config, BatchActionConfig):
            raise ValueError("batch_action_config must be of type BatchActionConfig.")
        batch_action_config = batch_action_config or BatchActionConfig()
        with RequestContextOverriddenClient(
            self._ontologies_client.Action,
            {
                "nullParameters": list(
                    reduce(lambda null_param_list, request: null_param_list + request._null_params, requests, [])
                )
            },
        ) as client:
            response = client.apply_batch(
                ontology=self._ontology_rid,
                action="create-inspection-event",
                requests=[BatchApplyActionRequestItem.model_validate(req.to_json()) for req in requests],
                options=BatchApplyActionRequestOptions.model_validate(
                    {"returnEdits": _get_action_return_edits(batch_action_config.return_edits, batch=True)}
                ),
            )
        return BatchApplyActionResponse.model_validate(response.to_dict())

    def create_robot(
        self,
        batch_action_config: Optional[BatchActionConfig] = None,
        requests: Optional[Iterable[CreateRobotBatchRequest]] = None,
    ) -> BatchApplyActionResponse:
        requests = requests or []
        """
        Registers a new physical robot in the QA cell.

        Creates the Robot object with initial configuration. Used by the dashboard registration flow and edge agent
        onboarding.
        """
        if not isinstance(requests, Iterable):
            raise TypeError("requests need to be an Iterable.")
        for request in requests:
            if not isinstance(request, CreateRobotBatchRequest):
                raise TypeError(f"{request} is not an instance of CreateRobotBatchRequest")
        if batch_action_config != None and not isinstance(batch_action_config, BatchActionConfig):
            raise ValueError("batch_action_config must be of type BatchActionConfig.")
        batch_action_config = batch_action_config or BatchActionConfig()
        with RequestContextOverriddenClient(
            self._ontologies_client.Action,
            {
                "nullParameters": list(
                    reduce(lambda null_param_list, request: null_param_list + request._null_params, requests, [])
                )
            },
        ) as client:
            response = client.apply_batch(
                ontology=self._ontology_rid,
                action="create-robot",
                requests=[BatchApplyActionRequestItem.model_validate(req.to_json()) for req in requests],
                options=BatchApplyActionRequestOptions.model_validate(
                    {"returnEdits": _get_action_return_edits(batch_action_config.return_edits, batch=True)}
                ),
            )
        return BatchApplyActionResponse.model_validate(response.to_dict())

    def create_sensor(
        self,
        batch_action_config: Optional[BatchActionConfig] = None,
        requests: Optional[Iterable[CreateSensorBatchRequest]] = None,
    ) -> BatchApplyActionResponse:
        requests = requests or []
        """
        Registers a new sensor attached to a robot.

        Automatically links to the Robot via robotId. Used during robot registration to create the default sensor suite.
        """
        if not isinstance(requests, Iterable):
            raise TypeError("requests need to be an Iterable.")
        for request in requests:
            if not isinstance(request, CreateSensorBatchRequest):
                raise TypeError(f"{request} is not an instance of CreateSensorBatchRequest")
        if batch_action_config != None and not isinstance(batch_action_config, BatchActionConfig):
            raise ValueError("batch_action_config must be of type BatchActionConfig.")
        batch_action_config = batch_action_config or BatchActionConfig()
        with RequestContextOverriddenClient(
            self._ontologies_client.Action,
            {
                "nullParameters": list(
                    reduce(lambda null_param_list, request: null_param_list + request._null_params, requests, [])
                )
            },
        ) as client:
            response = client.apply_batch(
                ontology=self._ontology_rid,
                action="create-sensor",
                requests=[BatchApplyActionRequestItem.model_validate(req.to_json()) for req in requests],
                options=BatchApplyActionRequestOptions.model_validate(
                    {"returnEdits": _get_action_return_edits(batch_action_config.return_edits, batch=True)}
                ),
            )
        return BatchApplyActionResponse.model_validate(response.to_dict())

    def publish_model(
        self,
        batch_action_config: Optional[BatchActionConfig] = None,
        requests: Optional[Iterable[PublishModelBatchRequest]] = None,
    ) -> BatchApplyActionResponse:
        requests = requests or []
        """
        Publish a new model version or update an existing model entry in the registry.

        Edge agents poll for published models and hot-swap.
        """
        if not isinstance(requests, Iterable):
            raise TypeError("requests need to be an Iterable.")
        for request in requests:
            if not isinstance(request, PublishModelBatchRequest):
                raise TypeError(f"{request} is not an instance of PublishModelBatchRequest")
        if batch_action_config != None and not isinstance(batch_action_config, BatchActionConfig):
            raise ValueError("batch_action_config must be of type BatchActionConfig.")
        batch_action_config = batch_action_config or BatchActionConfig()
        with RequestContextOverriddenClient(
            self._ontologies_client.Action,
            {
                "nullParameters": list(
                    reduce(lambda null_param_list, request: null_param_list + request._null_params, requests, [])
                )
            },
        ) as client:
            response = client.apply_batch(
                ontology=self._ontology_rid,
                action="publish-model",
                requests=[BatchApplyActionRequestItem.model_validate(req.to_json()) for req in requests],
                options=BatchApplyActionRequestOptions.model_validate(
                    {"returnEdits": _get_action_return_edits(batch_action_config.return_edits, batch=True)}
                ),
            )
        return BatchApplyActionResponse.model_validate(response.to_dict())

    def review_inspection_event(
        self,
        batch_action_config: Optional[BatchActionConfig] = None,
        requests: Optional[Iterable[ReviewInspectionEventBatchRequest]] = None,
    ) -> BatchApplyActionResponse:
        requests = requests or []
        """Operator reviews an uncertain inspection event (PENDING_REVIEW) and provides a final PASS/FAIL decision with
        optional notes.
        """
        if not isinstance(requests, Iterable):
            raise TypeError("requests need to be an Iterable.")
        for request in requests:
            if not isinstance(request, ReviewInspectionEventBatchRequest):
                raise TypeError(f"{request} is not an instance of ReviewInspectionEventBatchRequest")
        if batch_action_config != None and not isinstance(batch_action_config, BatchActionConfig):
            raise ValueError("batch_action_config must be of type BatchActionConfig.")
        batch_action_config = batch_action_config or BatchActionConfig()
        with RequestContextOverriddenClient(
            self._ontologies_client.Action,
            {
                "nullParameters": list(
                    reduce(lambda null_param_list, request: null_param_list + request._null_params, requests, [])
                )
            },
        ) as client:
            response = client.apply_batch(
                ontology=self._ontology_rid,
                action="review-inspection-event",
                requests=[BatchApplyActionRequestItem.model_validate(req.to_json()) for req in requests],
                options=BatchApplyActionRequestOptions.model_validate(
                    {"returnEdits": _get_action_return_edits(batch_action_config.return_edits, batch=True)}
                ),
            )
        return BatchApplyActionResponse.model_validate(response.to_dict())

    def send_command(
        self,
        batch_action_config: Optional[BatchActionConfig] = None,
        requests: Optional[Iterable[SendCommandBatchRequest]] = None,
    ) -> BatchApplyActionResponse:
        requests = requests or []
        """Send a control command from the dashboard to a robot."""
        if not isinstance(requests, Iterable):
            raise TypeError("requests need to be an Iterable.")
        for request in requests:
            if not isinstance(request, SendCommandBatchRequest):
                raise TypeError(f"{request} is not an instance of SendCommandBatchRequest")
        if batch_action_config != None and not isinstance(batch_action_config, BatchActionConfig):
            raise ValueError("batch_action_config must be of type BatchActionConfig.")
        batch_action_config = batch_action_config or BatchActionConfig()
        with RequestContextOverriddenClient(
            self._ontologies_client.Action,
            {
                "nullParameters": list(
                    reduce(lambda null_param_list, request: null_param_list + request._null_params, requests, [])
                )
            },
        ) as client:
            response = client.apply_batch(
                ontology=self._ontology_rid,
                action="send-command",
                requests=[BatchApplyActionRequestItem.model_validate(req.to_json()) for req in requests],
                options=BatchApplyActionRequestOptions.model_validate(
                    {"returnEdits": _get_action_return_edits(batch_action_config.return_edits, batch=True)}
                ),
            )
        return BatchApplyActionResponse.model_validate(response.to_dict())

    def update_robot_status(
        self,
        batch_action_config: Optional[BatchActionConfig] = None,
        requests: Optional[Iterable[UpdateRobotStatusBatchRequest]] = None,
    ) -> BatchApplyActionResponse:
        requests = requests or []
        """Called by the edge agent on heartbeat to update robot status, model version, and inspection count."""
        if not isinstance(requests, Iterable):
            raise TypeError("requests need to be an Iterable.")
        for request in requests:
            if not isinstance(request, UpdateRobotStatusBatchRequest):
                raise TypeError(f"{request} is not an instance of UpdateRobotStatusBatchRequest")
        if batch_action_config != None and not isinstance(batch_action_config, BatchActionConfig):
            raise ValueError("batch_action_config must be of type BatchActionConfig.")
        batch_action_config = batch_action_config or BatchActionConfig()
        with RequestContextOverriddenClient(
            self._ontologies_client.Action,
            {
                "nullParameters": list(
                    reduce(lambda null_param_list, request: null_param_list + request._null_params, requests, [])
                )
            },
        ) as client:
            response = client.apply_batch(
                ontology=self._ontology_rid,
                action="update-robot-status",
                requests=[BatchApplyActionRequestItem.model_validate(req.to_json()) for req in requests],
                options=BatchApplyActionRequestOptions.model_validate(
                    {"returnEdits": _get_action_return_edits(batch_action_config.return_edits, batch=True)}
                ),
            )
        return BatchApplyActionResponse.model_validate(response.to_dict())
