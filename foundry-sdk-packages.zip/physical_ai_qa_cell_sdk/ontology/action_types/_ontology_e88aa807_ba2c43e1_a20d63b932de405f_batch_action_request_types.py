from datetime import datetime
from typing import Optional, Union

from foundry_sdk.v2.core.models import MediaReference
from foundry_sdk_runtime.media import Media
from foundry_sdk_runtime.serialization import convert_to_platform_sdk_type
from foundry_sdk_runtime.types import NULL_VALUE_MAP, Empty
from physical_ai_qa_cell_sdk.ontology.objects import InspectionEvent, OperatorCommand, Robot


class AcknowledgeCommandBatchRequest:
    def __init__(
        self,
        *,
        command: Union[str, OperatorCommand],
        new_status: str,
    ):
        self._null_params = []
        self._request_body_json = {
            "parameters": convert_to_platform_sdk_type({"command": command, "new-status": new_status})
        }

    def to_json(self):
        return self._request_body_json


class CreateInspectionEventBatchRequest:
    def __init__(
        self,
        *,
        vision_confidence: float,
        fusion_reason: Union[str, Optional[Empty]] = Empty.value,
        vision_agrees: Union[bool, Optional[Empty]] = Empty.value,
        inspection_id: str,
        grip_load: float,
        cycle_time_ms: Union[int, Optional[Empty]] = Empty.value,
        vision_class: str,
        review_status: str,
        captured_image_ref: Union[Media, MediaReference],
        robot_id: str,
        model_version: Union[str, Optional[Empty]] = Empty.value,
        fusion_decision: str,
        timestamp: datetime,
    ):
        self._null_params = []
        if fusion_reason in (None, Empty.value):
            self._null_params.append(NULL_VALUE_MAP[fusion_reason])
        if vision_agrees in (None, Empty.value):
            self._null_params.append(NULL_VALUE_MAP[vision_agrees])
        if cycle_time_ms in (None, Empty.value):
            self._null_params.append(NULL_VALUE_MAP[cycle_time_ms])
        if model_version in (None, Empty.value):
            self._null_params.append(NULL_VALUE_MAP[model_version])
        self._request_body_json = {
            "parameters": convert_to_platform_sdk_type(
                {
                    "vision-confidence": vision_confidence,
                    "fusion-reason": None if fusion_reason == Empty.value else fusion_reason,
                    "vision-agrees": None if vision_agrees == Empty.value else vision_agrees,
                    "inspection-id": inspection_id,
                    "grip-load": grip_load,
                    "cycle-time-ms": None if cycle_time_ms == Empty.value else cycle_time_ms,
                    "vision-class": vision_class,
                    "review-status": review_status,
                    "captured-image-ref": captured_image_ref,
                    "robot-id": robot_id,
                    "model-version": None if model_version == Empty.value else model_version,
                    "fusion-decision": fusion_decision,
                    "timestamp": timestamp,
                }
            )
        }

    def to_json(self):
        return self._request_body_json


class CreateRobotBatchRequest:
    def __init__(
        self,
        *,
        current_model_version: Union[str, Optional[Empty]] = Empty.value,
        robot_id: str,
        name: str,
        grip_tolerance: Union[float, Optional[Empty]] = Empty.value,
        status: str,
    ):
        self._null_params = []
        if current_model_version in (None, Empty.value):
            self._null_params.append(NULL_VALUE_MAP[current_model_version])
        if grip_tolerance in (None, Empty.value):
            self._null_params.append(NULL_VALUE_MAP[grip_tolerance])
        self._request_body_json = {
            "parameters": convert_to_platform_sdk_type(
                {
                    "current-model-version": None if current_model_version == Empty.value else current_model_version,
                    "robot-id": robot_id,
                    "name": name,
                    "grip-tolerance": None if grip_tolerance == Empty.value else grip_tolerance,
                    "status": status,
                }
            )
        }

    def to_json(self):
        return self._request_body_json


class CreateSensorBatchRequest:
    def __init__(
        self,
        *,
        sensor_name: str,
        robot_id: str,
        location: Union[str, Optional[Empty]] = Empty.value,
        units: Union[str, Optional[Empty]] = Empty.value,
        sensor_type: str,
        sensor_id: str,
        status: str,
    ):
        self._null_params = []
        if location in (None, Empty.value):
            self._null_params.append(NULL_VALUE_MAP[location])
        if units in (None, Empty.value):
            self._null_params.append(NULL_VALUE_MAP[units])
        self._request_body_json = {
            "parameters": convert_to_platform_sdk_type(
                {
                    "sensor-name": sensor_name,
                    "robot-id": robot_id,
                    "location": None if location == Empty.value else location,
                    "units": None if units == Empty.value else units,
                    "sensor-type": sensor_type,
                    "sensor-id": sensor_id,
                    "status": status,
                }
            )
        }

    def to_json(self):
        return self._request_body_json


class PublishModelBatchRequest:
    def __init__(
        self,
        *,
        artifact_path: Union[str, Optional[Empty]] = Empty.value,
        model_status: str,
        model_id: str,
        model_description: Union[str, Optional[Empty]] = Empty.value,
        accuracy: Union[float, Optional[Empty]] = Empty.value,
        model_artifact_ref: Union[Media, MediaReference],
        version: str,
    ):
        self._null_params = []
        if artifact_path in (None, Empty.value):
            self._null_params.append(NULL_VALUE_MAP[artifact_path])
        if model_description in (None, Empty.value):
            self._null_params.append(NULL_VALUE_MAP[model_description])
        if accuracy in (None, Empty.value):
            self._null_params.append(NULL_VALUE_MAP[accuracy])
        self._request_body_json = {
            "parameters": convert_to_platform_sdk_type(
                {
                    "artifact-path": None if artifact_path == Empty.value else artifact_path,
                    "model-status": model_status,
                    "model-id": model_id,
                    "model-description": None if model_description == Empty.value else model_description,
                    "accuracy": None if accuracy == Empty.value else accuracy,
                    "model-artifact-ref": model_artifact_ref,
                    "version": version,
                }
            )
        }

    def to_json(self):
        return self._request_body_json


class ReviewInspectionEventBatchRequest:
    def __init__(
        self,
        *,
        inspection_event: Union[str, InspectionEvent],
        final_decision: str,
        operator_notes: Union[str, Optional[Empty]] = Empty.value,
    ):
        self._null_params = []
        if operator_notes in (None, Empty.value):
            self._null_params.append(NULL_VALUE_MAP[operator_notes])
        self._request_body_json = {
            "parameters": convert_to_platform_sdk_type(
                {
                    "inspection-event": inspection_event,
                    "final-decision": final_decision,
                    "operator-notes": None if operator_notes == Empty.value else operator_notes,
                }
            )
        }

    def to_json(self):
        return self._request_body_json


class SendCommandBatchRequest:
    def __init__(
        self,
        *,
        robot: Union[str, Robot],
        command_id: Union[str, Optional[Empty]] = Empty.value,
        command_type: str,
        payload: Union[str, Optional[Empty]] = Empty.value,
    ):
        self._null_params = []
        if command_id in (None, Empty.value):
            self._null_params.append(NULL_VALUE_MAP[command_id])
        if payload in (None, Empty.value):
            self._null_params.append(NULL_VALUE_MAP[payload])
        self._request_body_json = {
            "parameters": convert_to_platform_sdk_type(
                {
                    "robot": robot,
                    "command-id": None if command_id == Empty.value else command_id,
                    "command-type": command_type,
                    "payload": None if payload == Empty.value else payload,
                }
            )
        }

    def to_json(self):
        return self._request_body_json


class UpdateRobotStatusBatchRequest:
    def __init__(
        self,
        *,
        robot: Union[str, Robot],
        total_inspections: Union[int, Optional[Empty]] = Empty.value,
        current_model_version: Union[str, Optional[Empty]] = Empty.value,
        status: str,
    ):
        self._null_params = []
        if total_inspections in (None, Empty.value):
            self._null_params.append(NULL_VALUE_MAP[total_inspections])
        if current_model_version in (None, Empty.value):
            self._null_params.append(NULL_VALUE_MAP[current_model_version])
        self._request_body_json = {
            "parameters": convert_to_platform_sdk_type(
                {
                    "robot": robot,
                    "total-inspections": None if total_inspections == Empty.value else total_inspections,
                    "current-model-version": None if current_model_version == Empty.value else current_model_version,
                    "status": status,
                }
            )
        }

    def to_json(self):
        return self._request_body_json
