from datetime import datetime
from typing import Optional, Union

from foundry_sdk.v2.core.models import MediaReference
from foundry_sdk.v2.ontologies import OntologiesClient
from foundry_sdk.v2.ontologies.models import ApplyActionRequestOptions
from foundry_sdk_runtime.actions import SyncApplyActionResponse
from foundry_sdk_runtime.client import RequestContextOverriddenClient
from foundry_sdk_runtime.errors import InvalidApplyActionOptionCombination
from foundry_sdk_runtime.media import Media
from foundry_sdk_runtime.serialization import convert_to_platform_sdk_type
from foundry_sdk_runtime.types import (
    ActionConfig,
    ActionMode,
    Empty,
    ReturnEditsMode,
    _get_action_mode,
    _get_action_return_edits,
    extract_null_params,
)
from physical_ai_qa_cell_sdk.ontology.objects import InspectionEvent, OperatorCommand, Robot


class OntologyE88aa807Ba2c43e1A20d63b932de405fActionTypes:
    """
    Ontology action types service.

    Enables the following syntax to access action types on an ontology:

    .. code-block:: python

        client.ontology.actions.my_action(...)

    Attributes:
        _ontologies_client: The client to use for all requests.
        _ontology_rid: The ontology requests are made against
    """

    def __init__(self, _ontologies_client: "OntologiesClient", _ontology_rid: str) -> None:
        self._ontologies_client = _ontologies_client
        self._ontology_rid = _ontology_rid

    def acknowledge_command(
        self,
        action_config: Optional[ActionConfig] = None,
        *,
        command: Union[str, OperatorCommand],
        new_status: str,
    ) -> SyncApplyActionResponse:
        """
        Called by the edge agent when it picks up and executes a command.

        Updates the command status and execution timestamp.
        """
        if action_config and not isinstance(action_config, ActionConfig):
            raise ValueError("action_config must be of type ActionConfig.")
        action_config = action_config or ActionConfig()
        action_mode = _get_action_mode(action_config.mode)
        action_return_edits = _get_action_return_edits(action_config.return_edits)
        if action_mode == ActionMode.VALIDATE_ONLY and action_return_edits != ReturnEditsMode.NONE:
            raise InvalidApplyActionOptionCombination()
        parameters = {"command": command, "new-status": new_status}
        options = ApplyActionRequestOptions.model_validate({"mode": action_mode, "returnEdits": action_return_edits})
        with RequestContextOverriddenClient(self._ontologies_client.Action, extract_null_params(parameters)) as client:
            response = client.apply(
                ontology=self._ontology_rid,
                action="acknowledge-command",
                parameters=convert_to_platform_sdk_type(parameters),
                options=options,
            )
        return SyncApplyActionResponse.model_validate(response.to_dict())

    def create_inspection_event(
        self,
        action_config: Optional[ActionConfig] = None,
        *,
        vision_confidence: float,
        fusion_reason: Union[str, Optional[Empty]] = Empty.value,
        vision_agrees: Union[bool, Optional[Empty]] = Empty.value,
        inspection_id: str,
        grip_load: float,
        cycle_time_ms: Union[int, Optional[Empty]] = Empty.value,
        vision_class: str,
        review_status: str,
        captured_image_ref: Union[Media, MediaReference],
        robot_id: str,
        model_version: Union[str, Optional[Empty]] = Empty.value,
        fusion_decision: str,
        timestamp: datetime,
    ) -> SyncApplyActionResponse:
        """
        Called by the edge agent after each sensor fusion cycle.

        Creates an InspectionEvent with the fusion decision.
        """
        if action_config and not isinstance(action_config, ActionConfig):
            raise ValueError("action_config must be of type ActionConfig.")
        action_config = action_config or ActionConfig()
        action_mode = _get_action_mode(action_config.mode)
        action_return_edits = _get_action_return_edits(action_config.return_edits)
        if action_mode == ActionMode.VALIDATE_ONLY and action_return_edits != ReturnEditsMode.NONE:
            raise InvalidApplyActionOptionCombination()
        parameters = {
            "vision-confidence": vision_confidence,
            "fusion-reason": fusion_reason,
            "vision-agrees": vision_agrees,
            "inspection-id": inspection_id,
            "grip-load": grip_load,
            "cycle-time-ms": cycle_time_ms,
            "vision-class": vision_class,
            "review-status": review_status,
            "captured-image-ref": captured_image_ref,
            "robot-id": robot_id,
            "model-version": model_version,
            "fusion-decision": fusion_decision,
            "timestamp": timestamp,
        }
        options = ApplyActionRequestOptions.model_validate({"mode": action_mode, "returnEdits": action_return_edits})
        with RequestContextOverriddenClient(self._ontologies_client.Action, extract_null_params(parameters)) as client:
            response = client.apply(
                ontology=self._ontology_rid,
                action="create-inspection-event",
                parameters=convert_to_platform_sdk_type(parameters),
                options=options,
            )
        return SyncApplyActionResponse.model_validate(response.to_dict())

    def create_robot(
        self,
        action_config: Optional[ActionConfig] = None,
        *,
        current_model_version: Union[str, Optional[Empty]] = Empty.value,
        robot_id: str,
        name: str,
        grip_tolerance: Union[float, Optional[Empty]] = Empty.value,
        status: str,
    ) -> SyncApplyActionResponse:
        """
        Registers a new physical robot in the QA cell.

        Creates the Robot object with initial configuration. Used by the dashboard registration flow and edge agent
        onboarding.
        """
        if action_config and not isinstance(action_config, ActionConfig):
            raise ValueError("action_config must be of type ActionConfig.")
        action_config = action_config or ActionConfig()
        action_mode = _get_action_mode(action_config.mode)
        action_return_edits = _get_action_return_edits(action_config.return_edits)
        if action_mode == ActionMode.VALIDATE_ONLY and action_return_edits != ReturnEditsMode.NONE:
            raise InvalidApplyActionOptionCombination()
        parameters = {
            "current-model-version": current_model_version,
            "robot-id": robot_id,
            "name": name,
            "grip-tolerance": grip_tolerance,
            "status": status,
        }
        options = ApplyActionRequestOptions.model_validate({"mode": action_mode, "returnEdits": action_return_edits})
        with RequestContextOverriddenClient(self._ontologies_client.Action, extract_null_params(parameters)) as client:
            response = client.apply(
                ontology=self._ontology_rid,
                action="create-robot",
                parameters=convert_to_platform_sdk_type(parameters),
                options=options,
            )
        return SyncApplyActionResponse.model_validate(response.to_dict())

    def create_sensor(
        self,
        action_config: Optional[ActionConfig] = None,
        *,
        sensor_name: str,
        robot_id: str,
        location: Union[str, Optional[Empty]] = Empty.value,
        units: Union[str, Optional[Empty]] = Empty.value,
        sensor_type: str,
        sensor_id: str,
        status: str,
    ) -> SyncApplyActionResponse:
        """
        Registers a new sensor attached to a robot.

        Automatically links to the Robot via robotId. Used during robot registration to create the default sensor suite.
        """
        if action_config and not isinstance(action_config, ActionConfig):
            raise ValueError("action_config must be of type ActionConfig.")
        action_config = action_config or ActionConfig()
        action_mode = _get_action_mode(action_config.mode)
        action_return_edits = _get_action_return_edits(action_config.return_edits)
        if action_mode == ActionMode.VALIDATE_ONLY and action_return_edits != ReturnEditsMode.NONE:
            raise InvalidApplyActionOptionCombination()
        parameters = {
            "sensor-name": sensor_name,
            "robot-id": robot_id,
            "location": location,
            "units": units,
            "sensor-type": sensor_type,
            "sensor-id": sensor_id,
            "status": status,
        }
        options = ApplyActionRequestOptions.model_validate({"mode": action_mode, "returnEdits": action_return_edits})
        with RequestContextOverriddenClient(self._ontologies_client.Action, extract_null_params(parameters)) as client:
            response = client.apply(
                ontology=self._ontology_rid,
                action="create-sensor",
                parameters=convert_to_platform_sdk_type(parameters),
                options=options,
            )
        return SyncApplyActionResponse.model_validate(response.to_dict())

    def publish_model(
        self,
        action_config: Optional[ActionConfig] = None,
        *,
        artifact_path: Union[str, Optional[Empty]] = Empty.value,
        model_status: str,
        model_id: str,
        model_description: Union[str, Optional[Empty]] = Empty.value,
        accuracy: Union[float, Optional[Empty]] = Empty.value,
        model_artifact_ref: Union[Media, MediaReference],
        version: str,
    ) -> SyncApplyActionResponse:
        """
        Publish a new model version or update an existing model entry in the registry.

        Edge agents poll for published models and hot-swap.
        """
        if action_config and not isinstance(action_config, ActionConfig):
            raise ValueError("action_config must be of type ActionConfig.")
        action_config = action_config or ActionConfig()
        action_mode = _get_action_mode(action_config.mode)
        action_return_edits = _get_action_return_edits(action_config.return_edits)
        if action_mode == ActionMode.VALIDATE_ONLY and action_return_edits != ReturnEditsMode.NONE:
            raise InvalidApplyActionOptionCombination()
        parameters = {
            "artifact-path": artifact_path,
            "model-status": model_status,
            "model-id": model_id,
            "model-description": model_description,
            "accuracy": accuracy,
            "model-artifact-ref": model_artifact_ref,
            "version": version,
        }
        options = ApplyActionRequestOptions.model_validate({"mode": action_mode, "returnEdits": action_return_edits})
        with RequestContextOverriddenClient(self._ontologies_client.Action, extract_null_params(parameters)) as client:
            response = client.apply(
                ontology=self._ontology_rid,
                action="publish-model",
                parameters=convert_to_platform_sdk_type(parameters),
                options=options,
            )
        return SyncApplyActionResponse.model_validate(response.to_dict())

    def review_inspection_event(
        self,
        action_config: Optional[ActionConfig] = None,
        *,
        inspection_event: Union[str, InspectionEvent],
        final_decision: str,
        operator_notes: Union[str, Optional[Empty]] = Empty.value,
    ) -> SyncApplyActionResponse:
        """Operator reviews an uncertain inspection event (PENDING_REVIEW) and provides a final PASS/FAIL decision with
        optional notes.
        """
        if action_config and not isinstance(action_config, ActionConfig):
            raise ValueError("action_config must be of type ActionConfig.")
        action_config = action_config or ActionConfig()
        action_mode = _get_action_mode(action_config.mode)
        action_return_edits = _get_action_return_edits(action_config.return_edits)
        if action_mode == ActionMode.VALIDATE_ONLY and action_return_edits != ReturnEditsMode.NONE:
            raise InvalidApplyActionOptionCombination()
        parameters = {
            "inspection-event": inspection_event,
            "final-decision": final_decision,
            "operator-notes": operator_notes,
        }
        options = ApplyActionRequestOptions.model_validate({"mode": action_mode, "returnEdits": action_return_edits})
        with RequestContextOverriddenClient(self._ontologies_client.Action, extract_null_params(parameters)) as client:
            response = client.apply(
                ontology=self._ontology_rid,
                action="review-inspection-event",
                parameters=convert_to_platform_sdk_type(parameters),
                options=options,
            )
        return SyncApplyActionResponse.model_validate(response.to_dict())

    def send_command(
        self,
        action_config: Optional[ActionConfig] = None,
        *,
        robot: Union[str, Robot],
        command_id: Union[str, Optional[Empty]] = Empty.value,
        command_type: str,
        payload: Union[str, Optional[Empty]] = Empty.value,
    ) -> SyncApplyActionResponse:
        """Send a control command from the dashboard to a robot."""
        if action_config and not isinstance(action_config, ActionConfig):
            raise ValueError("action_config must be of type ActionConfig.")
        action_config = action_config or ActionConfig()
        action_mode = _get_action_mode(action_config.mode)
        action_return_edits = _get_action_return_edits(action_config.return_edits)
        if action_mode == ActionMode.VALIDATE_ONLY and action_return_edits != ReturnEditsMode.NONE:
            raise InvalidApplyActionOptionCombination()
        parameters = {"robot": robot, "command-id": command_id, "command-type": command_type, "payload": payload}
        options = ApplyActionRequestOptions.model_validate({"mode": action_mode, "returnEdits": action_return_edits})
        with RequestContextOverriddenClient(self._ontologies_client.Action, extract_null_params(parameters)) as client:
            response = client.apply(
                ontology=self._ontology_rid,
                action="send-command",
                parameters=convert_to_platform_sdk_type(parameters),
                options=options,
            )
        return SyncApplyActionResponse.model_validate(response.to_dict())

    def update_robot_status(
        self,
        action_config: Optional[ActionConfig] = None,
        *,
        robot: Union[str, Robot],
        total_inspections: Union[int, Optional[Empty]] = Empty.value,
        current_model_version: Union[str, Optional[Empty]] = Empty.value,
        status: str,
    ) -> SyncApplyActionResponse:
        """Called by the edge agent on heartbeat to update robot status, model version, and inspection count."""
        if action_config and not isinstance(action_config, ActionConfig):
            raise ValueError("action_config must be of type ActionConfig.")
        action_config = action_config or ActionConfig()
        action_mode = _get_action_mode(action_config.mode)
        action_return_edits = _get_action_return_edits(action_config.return_edits)
        if action_mode == ActionMode.VALIDATE_ONLY and action_return_edits != ReturnEditsMode.NONE:
            raise InvalidApplyActionOptionCombination()
        parameters = {
            "robot": robot,
            "total-inspections": total_inspections,
            "current-model-version": current_model_version,
            "status": status,
        }
        options = ApplyActionRequestOptions.model_validate({"mode": action_mode, "returnEdits": action_return_edits})
        with RequestContextOverriddenClient(self._ontologies_client.Action, extract_null_params(parameters)) as client:
            response = client.apply(
                ontology=self._ontology_rid,
                action="update-robot-status",
                parameters=convert_to_platform_sdk_type(parameters),
                options=options,
            )
        return SyncApplyActionResponse.model_validate(response.to_dict())
