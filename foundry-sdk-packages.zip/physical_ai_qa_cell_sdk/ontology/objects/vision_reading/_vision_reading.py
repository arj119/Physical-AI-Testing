#  (c) Copyright 2023 Palantir Technologies Inc. All rights reserved.
from datetime import datetime
from functools import cache
from typing import TYPE_CHECKING, Any, Optional

from foundry_sdk.v2.ontologies import OntologiesClient
from foundry_sdk_runtime import OntologyObject
from foundry_sdk_runtime.properties import ObjectTypeProperty
from foundry_sdk_runtime.properties.helpers import AggregationType
from foundry_sdk_runtime.types import sanitize_for_hashing

from ...search import VisionReadingObjectType

if TYPE_CHECKING:
    from physical_ai_qa_cell_sdk.ontology.object_sets import VisionReadingObjectSet
    from ._inspection_event import InspectionEvent
    from ._robot import Robot

from typing import Any


class VisionReading(OntologyObject):
    """
    Wraps the VisionReading ontology object.

    Individual vision inference results from the edge camera/YOLOv5 model. Streamed in real-time from the Jetson Nano via Foundry Streams.
    # Code Samples

    ## Declare a function taking an object as a parameter
    ```
    from physical_ai_qa_cell_sdk.ontology.objects import VisionReading

    def get_key_for_VisionReading(obj: VisionReading) -> str:
      return obj.reading_id
    ```

    ## Using a FoundryClient to retrieve an instance of an object
    ```
    from physical_ai_qa_cell_sdk import FoundryClient

    def get_title_for_VisionReading(key: str) -> str:
      client = FoundryClient()

      obj = client.ontology.objects.VisionReading.get(key)
      return obj.title_PLACEHOLDER
    ```

    ## Return an instance of an object
    ```
    from physical_ai_qa_cell_sdk import FoundryClient

    def get_with_id_VisionReading(key: str) -> VisionReading:
        client = FoundryClient()

        return client.ontology.objects.VisionReading.get(key)
    ```

    ## Retrieve an object via a query
    ```
    from physical_ai_qa_cell_sdk import FoundryClient
    from physical_ai_qa_cell_sdk.ontology.objects import VisionReading

    def get_first_by_name_VisionReading(name: str) -> VisionReading:
        client = FoundryClient()

        objset = client.ontology.objects.VisionReading.where(
          VisionReading.PLACEHOLDER == name)

        return next(iter(objset, None))
    ```
    """

    object_type: VisionReadingObjectType = VisionReadingObjectType()

    def __init__(
        self,
        bounding_box: Optional[list[float]] = None,
        inspection_id: Optional[str] = None,
        inference_time_ms: Optional[int] = None,
        model_version: Optional[str] = None,
        thumbnail_base64: Optional[str] = None,
        confidence: Optional[float] = None,
        reading_id: Optional[str] = None,
        robot_id: Optional[str] = None,
        detected_class: Optional[str] = None,
        timestamp: Optional[datetime] = None,
        rid: Optional[str] = None,
        _ontologies_client: Optional[OntologiesClient] = None,
        _ontology_rid: Optional[str] = None,
    ) -> None:
        object.__setattr__(self, "_initialized", False)
        object.__setattr__(self, "_ontologies_client", _ontologies_client)
        object.__setattr__(self, "_ontology_rid", _ontology_rid)
        object.__setattr__(self, "rid", rid)
        object.__setattr__(self, "bounding_box", bounding_box)
        object.__setattr__(self, "inspection_id", inspection_id)
        object.__setattr__(self, "inference_time_ms", inference_time_ms)
        object.__setattr__(self, "model_version", model_version)
        object.__setattr__(self, "thumbnail_base64", thumbnail_base64)
        object.__setattr__(self, "confidence", confidence)
        object.__setattr__(self, "reading_id", reading_id)
        object.__setattr__(self, "robot_id", robot_id)
        object.__setattr__(self, "detected_class", detected_class)
        object.__setattr__(self, "timestamp", timestamp)

        if TYPE_CHECKING:
            self.rid = rid
            self.bounding_box = bounding_box
            self.inspection_id = inspection_id
            self.inference_time_ms = inference_time_ms
            self.model_version = model_version
            self.thumbnail_base64 = thumbnail_base64
            self.confidence = confidence
            self.reading_id = reading_id
            self.robot_id = robot_id
            self.detected_class = detected_class
            self.timestamp = timestamp

    def count() -> AggregationType:
        return AggregationType(aggregation_type="count")

    def __setattr__(self, name, value):
        if self._initialized:
            raise AttributeError("Cannot modify attributes after initialization")
        object.__setattr__(self, name, value)

    @staticmethod
    def api_name() -> str:
        return "VisionReading"

    @staticmethod
    def primary_key() -> str:
        return "reading_id"

    @staticmethod
    def primary_key_type() -> type:
        return str

    @staticmethod
    def init_from_primary_key(
        primary_key: str, ontologies_client: Optional[OntologiesClient] = None
    ) -> "VisionReading":
        from physical_ai_qa_cell_sdk import FoundryClient

        client = (
            FoundryClient._init_from_ontologies_client(ontologies_client=ontologies_client)
            if ontologies_client
            else FoundryClient()
        )
        return client.ontology.objects.VisionReading.get(primary_key)

    def get_primary_key(self) -> str:
        return self.reading_id

    def to_object_set(self) -> "VisionReadingObjectSet":
        from physical_ai_qa_cell_sdk import FoundryClient

        return FoundryClient().ontology.objects.VisionReading.where(
            VisionReadingObjectType.reading_id == self.reading_id
        )

    def __eq__(self, other: Any) -> bool:
        return self is other or (
            type(self) == type(other)
            and (self.bounding_box == other.bounding_box)
            and (self.inspection_id == other.inspection_id)
            and (self.inference_time_ms == other.inference_time_ms)
            and (self.model_version == other.model_version)
            and (self.thumbnail_base64 == other.thumbnail_base64)
            and (self.confidence == other.confidence)
            and (self.reading_id == other.reading_id)
            and (self.robot_id == other.robot_id)
            and (self.detected_class == other.detected_class)
            and (self.timestamp == other.timestamp)
            and (self.rid == other.rid)
        )

    def __hash__(self) -> int:
        return hash(
            (
                type(self),
                sanitize_for_hashing(self.bounding_box),
                sanitize_for_hashing(self.inspection_id),
                sanitize_for_hashing(self.inference_time_ms),
                sanitize_for_hashing(self.model_version),
                sanitize_for_hashing(self.thumbnail_base64),
                sanitize_for_hashing(self.confidence),
                sanitize_for_hashing(self.reading_id),
                sanitize_for_hashing(self.robot_id),
                sanitize_for_hashing(self.detected_class),
                sanitize_for_hashing(self.timestamp),
                sanitize_for_hashing(self.rid),
            )
        )

    def __repr__(self) -> str:
        attrs = {
            key.removeprefix("BETA_PROPERTY__"): value
            for key, value in vars(self).items()
            if not key.startswith("_") or key == "_score"
        }
        attrs_str = ", ".join(f"{key}={value}" for key, value in attrs.items())
        return f"VisionReading({attrs_str})"

    def _asdict(self) -> dict[str, Any]:
        return {
            "boundingBox": self.bounding_box,
            "inspectionId": self.inspection_id,
            "inferenceTimeMs": self.inference_time_ms,
            "modelVersion": self.model_version,
            "thumbnailBase64": self.thumbnail_base64,
            "confidence": self.confidence,
            "readingId": self.reading_id,
            "robotId": self.robot_id,
            "detectedClass": self.detected_class,
            "timestamp": self.timestamp,
            "$rid": self.rid,
        }

    @staticmethod
    @cache
    def _fields() -> dict[str, Any]:
        return {
            "boundingBox": Optional[list[float]],
            "inspectionId": Optional[str],
            "inferenceTimeMs": Optional[int],
            "modelVersion": Optional[str],
            "thumbnailBase64": Optional[str],
            "confidence": Optional[float],
            "readingId": Optional[str],
            "robotId": Optional[str],
            "detectedClass": Optional[str],
            "timestamp": Optional[datetime],
            "$rid": Optional[str],
        }

    @staticmethod
    @cache
    def _api_name_to_property_name() -> dict[str, str]:
        return {
            "boundingBox": "bounding_box",
            "inspectionId": "inspection_id",
            "inferenceTimeMs": "inference_time_ms",
            "modelVersion": "model_version",
            "thumbnailBase64": "thumbnail_base64",
            "confidence": "confidence",
            "readingId": "reading_id",
            "robotId": "robot_id",
            "detectedClass": "detected_class",
            "timestamp": "timestamp",
            "$rid": "rid",
        }

    def inspection_event(
        self, properties: Optional[list[ObjectTypeProperty]] = None, include_rid: bool = False
    ) -> Optional["InspectionEvent"]:
        from physical_ai_qa_cell_sdk.ontology.object_sets import VisionReadingObjectSet

        linked_objects = (
            VisionReadingObjectSet(
                _ontologies_client=self._ontologies_client,
                _ontology_rid=self._ontology_rid,
            )
            .where(VisionReadingObjectType.reading_id == self.reading_id)
            .search_around_inspection_event()
            .take(
                num_items=1,
                properties=properties,
                include_rid=include_rid,
            )
        )
        if len(linked_objects) > 0:
            return linked_objects[0]
        else:
            return None

    def robot(
        self, properties: Optional[list[ObjectTypeProperty]] = None, include_rid: bool = False
    ) -> Optional["Robot"]:
        from physical_ai_qa_cell_sdk.ontology.object_sets import VisionReadingObjectSet

        linked_objects = (
            VisionReadingObjectSet(
                _ontologies_client=self._ontologies_client,
                _ontology_rid=self._ontology_rid,
            )
            .where(VisionReadingObjectType.reading_id == self.reading_id)
            .search_around_robot()
            .take(
                num_items=1,
                properties=properties,
                include_rid=include_rid,
            )
        )
        if len(linked_objects) > 0:
            return linked_objects[0]
        else:
            return None
