#  (c) Copyright 2023 Palantir Technologies Inc. All rights reserved.
from datetime import datetime
from functools import cache
from typing import TYPE_CHECKING, Any, Optional

from foundry_sdk.v2.ontologies import OntologiesClient
from foundry_sdk_runtime import OntologyObject
from foundry_sdk_runtime.decorators import beta
from foundry_sdk_runtime.media import Media
from foundry_sdk_runtime.properties.helpers import AggregationType
from foundry_sdk_runtime.types import sanitize_for_hashing

from ...search import ModelRegistryObjectType

if TYPE_CHECKING:
    from physical_ai_qa_cell_sdk.ontology.object_sets import ModelRegistryObjectSet

from typing import Any


class ModelRegistry(OntologyObject):
    """
    Wraps the ModelRegistry ontology object.

    Model versions and lifecycle management. Edge agents poll for new published versions and hot-swap on the Jetson.
    # Code Samples

    ## Declare a function taking an object as a parameter
    ```
    from physical_ai_qa_cell_sdk.ontology.objects import ModelRegistry

    def get_key_for_ModelRegistry(obj: ModelRegistry) -> str:
      return obj.model_id
    ```

    ## Using a FoundryClient to retrieve an instance of an object
    ```
    from physical_ai_qa_cell_sdk import FoundryClient

    def get_title_for_ModelRegistry(key: str) -> str:
      client = FoundryClient()

      obj = client.ontology.objects.ModelRegistry.get(key)
      return obj.title_PLACEHOLDER
    ```

    ## Return an instance of an object
    ```
    from physical_ai_qa_cell_sdk import FoundryClient

    def get_with_id_ModelRegistry(key: str) -> ModelRegistry:
        client = FoundryClient()

        return client.ontology.objects.ModelRegistry.get(key)
    ```

    ## Retrieve an object via a query
    ```
    from physical_ai_qa_cell_sdk import FoundryClient
    from physical_ai_qa_cell_sdk.ontology.objects import ModelRegistry

    def get_first_by_name_ModelRegistry(name: str) -> ModelRegistry:
        client = FoundryClient()

        objset = client.ontology.objects.ModelRegistry.where(
          ModelRegistry.PLACEHOLDER == name)

        return next(iter(objset, None))
    ```
    """

    object_type: ModelRegistryObjectType = ModelRegistryObjectType()

    def __init__(
        self,
        published_at: Optional[datetime] = None,
        model_id: Optional[str] = None,
        accuracy: Optional[float] = None,
        description: Optional[str] = None,
        artifact_path: Optional[str] = None,
        version: Optional[str] = None,
        status: Optional[str] = None,
        model_artifact_ref: Optional[Media] = None,
        rid: Optional[str] = None,
        _ontologies_client: Optional[OntologiesClient] = None,
        _ontology_rid: Optional[str] = None,
    ) -> None:
        object.__setattr__(self, "_initialized", False)
        object.__setattr__(self, "_ontologies_client", _ontologies_client)
        object.__setattr__(self, "_ontology_rid", _ontology_rid)
        object.__setattr__(self, "rid", rid)
        object.__setattr__(self, "published_at", published_at)
        object.__setattr__(self, "model_id", model_id)
        object.__setattr__(self, "accuracy", accuracy)
        object.__setattr__(self, "description", description)
        object.__setattr__(self, "artifact_path", artifact_path)
        object.__setattr__(self, "version", version)
        object.__setattr__(self, "status", status)
        object.__setattr__(
            self,
            "BETA_PROPERTY__model_artifact_ref",
            (
                Media(
                    _ontologies_client=self._ontologies_client,
                    _ontology_rid=self._ontology_rid,
                    object_type="ModelRegistry",
                    object_primary_key=self.model_id,
                    property_name="modelArtifactRef",
                    media_reference=model_artifact_ref._media_reference,
                )
                if (
                    model_artifact_ref is not None
                    and self._ontologies_client is not None
                    and self._ontology_rid is not None
                )
                else None
            ),
        )

        if TYPE_CHECKING:
            self.rid = rid
            self.published_at = published_at
            self.model_id = model_id
            self.accuracy = accuracy
            self.description = description
            self.artifact_path = artifact_path
            self.version = version
            self.status = status

    def count() -> AggregationType:
        return AggregationType(aggregation_type="count")

    def __setattr__(self, name, value):
        if self._initialized:
            raise AttributeError("Cannot modify attributes after initialization")
        object.__setattr__(self, name, value)

    @property
    @beta("Properties of type Media are in beta and may change in future versions.")
    def model_artifact_ref(self) -> Optional[Media]:
        return self.BETA_PROPERTY__model_artifact_ref

    @staticmethod
    def api_name() -> str:
        return "ModelRegistry"

    @staticmethod
    def primary_key() -> str:
        return "model_id"

    @staticmethod
    def primary_key_type() -> type:
        return str

    @staticmethod
    def init_from_primary_key(
        primary_key: str, ontologies_client: Optional[OntologiesClient] = None
    ) -> "ModelRegistry":
        from physical_ai_qa_cell_sdk import FoundryClient

        client = (
            FoundryClient._init_from_ontologies_client(ontologies_client=ontologies_client)
            if ontologies_client
            else FoundryClient()
        )
        return client.ontology.objects.ModelRegistry.get(primary_key)

    def get_primary_key(self) -> str:
        return self.model_id

    def to_object_set(self) -> "ModelRegistryObjectSet":
        from physical_ai_qa_cell_sdk import FoundryClient

        return FoundryClient().ontology.objects.ModelRegistry.where(ModelRegistryObjectType.model_id == self.model_id)

    def __eq__(self, other: Any) -> bool:
        return self is other or (
            type(self) == type(other)
            and (self.published_at == other.published_at)
            and (self.model_id == other.model_id)
            and (self.accuracy == other.accuracy)
            and (self.description == other.description)
            and (self.artifact_path == other.artifact_path)
            and (self.version == other.version)
            and (self.status == other.status)
            and (self.model_artifact_ref == other.model_artifact_ref)
            and (self.rid == other.rid)
        )

    def __hash__(self) -> int:
        return hash(
            (
                type(self),
                sanitize_for_hashing(self.published_at),
                sanitize_for_hashing(self.model_id),
                sanitize_for_hashing(self.accuracy),
                sanitize_for_hashing(self.description),
                sanitize_for_hashing(self.artifact_path),
                sanitize_for_hashing(self.version),
                sanitize_for_hashing(self.status),
                sanitize_for_hashing(self.model_artifact_ref),
                sanitize_for_hashing(self.rid),
            )
        )

    def __repr__(self) -> str:
        attrs = {
            key.removeprefix("BETA_PROPERTY__"): value
            for key, value in vars(self).items()
            if not key.startswith("_") or key == "_score"
        }
        attrs_str = ", ".join(f"{key}={value}" for key, value in attrs.items())
        return f"ModelRegistry({attrs_str})"

    def _asdict(self) -> dict[str, Any]:
        return {
            "publishedAt": self.published_at,
            "modelId": self.model_id,
            "accuracy": self.accuracy,
            "description": self.description,
            "artifactPath": self.artifact_path,
            "version": self.version,
            "status": self.status,
            "modelArtifactRef": self.model_artifact_ref._asdict() if self.model_artifact_ref else None,
            "$rid": self.rid,
        }

    @staticmethod
    @cache
    def _fields() -> dict[str, Any]:
        return {
            "publishedAt": Optional[datetime],
            "modelId": Optional[str],
            "accuracy": Optional[float],
            "description": Optional[str],
            "artifactPath": Optional[str],
            "version": Optional[str],
            "status": Optional[str],
            "modelArtifactRef": Optional[Media],
            "$rid": Optional[str],
        }

    @staticmethod
    @cache
    def _api_name_to_property_name() -> dict[str, str]:
        return {
            "publishedAt": "published_at",
            "modelId": "model_id",
            "accuracy": "accuracy",
            "description": "description",
            "artifactPath": "artifact_path",
            "version": "version",
            "status": "status",
            "modelArtifactRef": "model_artifact_ref",
            "$rid": "rid",
        }
