#  (c) Copyright 2023 Palantir Technologies Inc. All rights reserved.
from datetime import datetime
from functools import cache
from typing import TYPE_CHECKING, Any, Optional

from foundry_sdk.v2.ontologies import OntologiesClient
from foundry_sdk_runtime import OntologyObject
from foundry_sdk_runtime.properties import ObjectTypeProperty
from foundry_sdk_runtime.properties.helpers import AggregationType
from foundry_sdk_runtime.types import sanitize_for_hashing

from ...search import GripReadingObjectType

if TYPE_CHECKING:
    from physical_ai_qa_cell_sdk.ontology.object_sets import GripReadingObjectSet
    from ._inspection_event import InspectionEvent
    from ._robot import Robot

from typing import Any


class GripReading(OntologyObject):
    """
    Wraps the GripReading ontology object.

    Individual gripper servo load measurements from the myCobot 280. Streamed in real-time from the Jetson Nano via Foundry Streams.
    # Code Samples

    ## Declare a function taking an object as a parameter
    ```
    from physical_ai_qa_cell_sdk.ontology.objects import GripReading

    def get_key_for_GripReading(obj: GripReading) -> str:
      return obj.reading_id
    ```

    ## Using a FoundryClient to retrieve an instance of an object
    ```
    from physical_ai_qa_cell_sdk import FoundryClient

    def get_title_for_GripReading(key: str) -> str:
      client = FoundryClient()

      obj = client.ontology.objects.GripReading.get(key)
      return obj.title_PLACEHOLDER
    ```

    ## Return an instance of an object
    ```
    from physical_ai_qa_cell_sdk import FoundryClient

    def get_with_id_GripReading(key: str) -> GripReading:
        client = FoundryClient()

        return client.ontology.objects.GripReading.get(key)
    ```

    ## Retrieve an object via a query
    ```
    from physical_ai_qa_cell_sdk import FoundryClient
    from physical_ai_qa_cell_sdk.ontology.objects import GripReading

    def get_first_by_name_GripReading(name: str) -> GripReading:
        client = FoundryClient()

        objset = client.ontology.objects.GripReading.where(
          GripReading.PLACEHOLDER == name)

        return next(iter(objset, None))
    ```
    """

    object_type: GripReadingObjectType = GripReadingObjectType()

    def __init__(
        self,
        normalized_load: Optional[float] = None,
        inspection_id: Optional[str] = None,
        servo_load: Optional[float] = None,
        reading_id: Optional[str] = None,
        object_detected: Optional[bool] = None,
        grip_state: Optional[str] = None,
        robot_id: Optional[str] = None,
        timestamp: Optional[datetime] = None,
        rid: Optional[str] = None,
        _ontologies_client: Optional[OntologiesClient] = None,
        _ontology_rid: Optional[str] = None,
    ) -> None:
        object.__setattr__(self, "_initialized", False)
        object.__setattr__(self, "_ontologies_client", _ontologies_client)
        object.__setattr__(self, "_ontology_rid", _ontology_rid)
        object.__setattr__(self, "rid", rid)
        object.__setattr__(self, "normalized_load", normalized_load)
        object.__setattr__(self, "inspection_id", inspection_id)
        object.__setattr__(self, "servo_load", servo_load)
        object.__setattr__(self, "reading_id", reading_id)
        object.__setattr__(self, "object_detected", object_detected)
        object.__setattr__(self, "grip_state", grip_state)
        object.__setattr__(self, "robot_id", robot_id)
        object.__setattr__(self, "timestamp", timestamp)

        if TYPE_CHECKING:
            self.rid = rid
            self.normalized_load = normalized_load
            self.inspection_id = inspection_id
            self.servo_load = servo_load
            self.reading_id = reading_id
            self.object_detected = object_detected
            self.grip_state = grip_state
            self.robot_id = robot_id
            self.timestamp = timestamp

    def count() -> AggregationType:
        return AggregationType(aggregation_type="count")

    def __setattr__(self, name, value):
        if self._initialized:
            raise AttributeError("Cannot modify attributes after initialization")
        object.__setattr__(self, name, value)

    @staticmethod
    def api_name() -> str:
        return "GripReading"

    @staticmethod
    def primary_key() -> str:
        return "reading_id"

    @staticmethod
    def primary_key_type() -> type:
        return str

    @staticmethod
    def init_from_primary_key(primary_key: str, ontologies_client: Optional[OntologiesClient] = None) -> "GripReading":
        from physical_ai_qa_cell_sdk import FoundryClient

        client = (
            FoundryClient._init_from_ontologies_client(ontologies_client=ontologies_client)
            if ontologies_client
            else FoundryClient()
        )
        return client.ontology.objects.GripReading.get(primary_key)

    def get_primary_key(self) -> str:
        return self.reading_id

    def to_object_set(self) -> "GripReadingObjectSet":
        from physical_ai_qa_cell_sdk import FoundryClient

        return FoundryClient().ontology.objects.GripReading.where(GripReadingObjectType.reading_id == self.reading_id)

    def __eq__(self, other: Any) -> bool:
        return self is other or (
            type(self) == type(other)
            and (self.normalized_load == other.normalized_load)
            and (self.inspection_id == other.inspection_id)
            and (self.servo_load == other.servo_load)
            and (self.reading_id == other.reading_id)
            and (self.object_detected == other.object_detected)
            and (self.grip_state == other.grip_state)
            and (self.robot_id == other.robot_id)
            and (self.timestamp == other.timestamp)
            and (self.rid == other.rid)
        )

    def __hash__(self) -> int:
        return hash(
            (
                type(self),
                sanitize_for_hashing(self.normalized_load),
                sanitize_for_hashing(self.inspection_id),
                sanitize_for_hashing(self.servo_load),
                sanitize_for_hashing(self.reading_id),
                sanitize_for_hashing(self.object_detected),
                sanitize_for_hashing(self.grip_state),
                sanitize_for_hashing(self.robot_id),
                sanitize_for_hashing(self.timestamp),
                sanitize_for_hashing(self.rid),
            )
        )

    def __repr__(self) -> str:
        attrs = {
            key.removeprefix("BETA_PROPERTY__"): value
            for key, value in vars(self).items()
            if not key.startswith("_") or key == "_score"
        }
        attrs_str = ", ".join(f"{key}={value}" for key, value in attrs.items())
        return f"GripReading({attrs_str})"

    def _asdict(self) -> dict[str, Any]:
        return {
            "normalizedLoad": self.normalized_load,
            "inspectionId": self.inspection_id,
            "servoLoad": self.servo_load,
            "readingId": self.reading_id,
            "objectDetected": self.object_detected,
            "gripState": self.grip_state,
            "robotId": self.robot_id,
            "timestamp": self.timestamp,
            "$rid": self.rid,
        }

    @staticmethod
    @cache
    def _fields() -> dict[str, Any]:
        return {
            "normalizedLoad": Optional[float],
            "inspectionId": Optional[str],
            "servoLoad": Optional[float],
            "readingId": Optional[str],
            "objectDetected": Optional[bool],
            "gripState": Optional[str],
            "robotId": Optional[str],
            "timestamp": Optional[datetime],
            "$rid": Optional[str],
        }

    @staticmethod
    @cache
    def _api_name_to_property_name() -> dict[str, str]:
        return {
            "normalizedLoad": "normalized_load",
            "inspectionId": "inspection_id",
            "servoLoad": "servo_load",
            "readingId": "reading_id",
            "objectDetected": "object_detected",
            "gripState": "grip_state",
            "robotId": "robot_id",
            "timestamp": "timestamp",
            "$rid": "rid",
        }

    def inspection_event(
        self, properties: Optional[list[ObjectTypeProperty]] = None, include_rid: bool = False
    ) -> Optional["InspectionEvent"]:
        from physical_ai_qa_cell_sdk.ontology.object_sets import GripReadingObjectSet

        linked_objects = (
            GripReadingObjectSet(
                _ontologies_client=self._ontologies_client,
                _ontology_rid=self._ontology_rid,
            )
            .where(GripReadingObjectType.reading_id == self.reading_id)
            .search_around_inspection_event()
            .take(
                num_items=1,
                properties=properties,
                include_rid=include_rid,
            )
        )
        if len(linked_objects) > 0:
            return linked_objects[0]
        else:
            return None

    def robot(
        self, properties: Optional[list[ObjectTypeProperty]] = None, include_rid: bool = False
    ) -> Optional["Robot"]:
        from physical_ai_qa_cell_sdk.ontology.object_sets import GripReadingObjectSet

        linked_objects = (
            GripReadingObjectSet(
                _ontologies_client=self._ontologies_client,
                _ontology_rid=self._ontology_rid,
            )
            .where(GripReadingObjectType.reading_id == self.reading_id)
            .search_around_robot()
            .take(
                num_items=1,
                properties=properties,
                include_rid=include_rid,
            )
        )
        if len(linked_objects) > 0:
            return linked_objects[0]
        else:
            return None
