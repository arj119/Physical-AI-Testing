#  (c) Copyright 2023 Palantir Technologies Inc. All rights reserved.
from functools import cache
from typing import TYPE_CHECKING, Any, Optional

from foundry_sdk.v2.ontologies import OntologiesClient
from foundry_sdk_runtime import OntologyObject
from foundry_sdk_runtime.properties import ObjectTypeProperty
from foundry_sdk_runtime.properties.helpers import AggregationType
from foundry_sdk_runtime.timeseries import Timeseries
from foundry_sdk_runtime.types import sanitize_for_hashing

from ...search import SensorObjectType

if TYPE_CHECKING:
    from physical_ai_qa_cell_sdk.ontology.object_sets import SensorObjectSet
    from ._robot import Robot

from typing import Any


class Sensor(OntologyObject):
    """
    Wraps the Sensor ontology object.

    Physical sensor hardware attached to a robot (camera, gripper load cell, temperature probe, etc.). Each Sensor is a first-class entity for management, calibration tracking, and time series visualization. Manual setup required: configure seriesId as Time Series Property in Ontology Manager for native time series charts.
    # Code Samples

    ## Declare a function taking an object as a parameter
    ```
    from physical_ai_qa_cell_sdk.ontology.objects import Sensor

    def get_key_for_Sensor(obj: Sensor) -> str:
      return obj.sensor_id
    ```

    ## Using a FoundryClient to retrieve an instance of an object
    ```
    from physical_ai_qa_cell_sdk import FoundryClient

    def get_title_for_Sensor(key: str) -> str:
      client = FoundryClient()

      obj = client.ontology.objects.Sensor.get(key)
      return obj.title_PLACEHOLDER
    ```

    ## Return an instance of an object
    ```
    from physical_ai_qa_cell_sdk import FoundryClient

    def get_with_id_Sensor(key: str) -> Sensor:
        client = FoundryClient()

        return client.ontology.objects.Sensor.get(key)
    ```

    ## Retrieve an object via a query
    ```
    from physical_ai_qa_cell_sdk import FoundryClient
    from physical_ai_qa_cell_sdk.ontology.objects import Sensor

    def get_first_by_name_Sensor(name: str) -> Sensor:
        client = FoundryClient()

        objset = client.ontology.objects.Sensor.where(
          Sensor.PLACEHOLDER == name)

        return next(iter(objset, None))
    ```
    """

    object_type: SensorObjectType = SensorObjectType()

    def __init__(
        self,
        is_categorical: Optional[bool] = None,
        internal_interpolation: Optional[str] = None,
        sensor_name1: Optional[str] = None,
        sensor_type: Optional[str] = None,
        location: Optional[str] = None,
        units: Optional[str] = None,
        robot_id: Optional[str] = None,
        sensor_type_id: Optional[str] = None,
        sensor_id: Optional[str] = None,
        status: Optional[str] = None,
        series_id: Optional[Timeseries[float]] = None,
        rid: Optional[str] = None,
        _ontologies_client: Optional[OntologiesClient] = None,
        _ontology_rid: Optional[str] = None,
    ) -> None:
        object.__setattr__(self, "_initialized", False)
        object.__setattr__(self, "_ontologies_client", _ontologies_client)
        object.__setattr__(self, "_ontology_rid", _ontology_rid)
        object.__setattr__(self, "rid", rid)
        object.__setattr__(self, "is_categorical", is_categorical)
        object.__setattr__(self, "internal_interpolation", internal_interpolation)
        object.__setattr__(self, "sensor_name1", sensor_name1)
        object.__setattr__(self, "sensor_type", sensor_type)
        object.__setattr__(self, "location", location)
        object.__setattr__(self, "units", units)
        object.__setattr__(self, "robot_id", robot_id)
        object.__setattr__(self, "sensor_type_id", sensor_type_id)
        object.__setattr__(self, "sensor_id", sensor_id)
        object.__setattr__(self, "status", status)
        object.__setattr__(
            self,
            "series_id",
            (
                Timeseries[float](
                    _ontologies_client=self._ontologies_client,
                    _ontology_rid=self._ontology_rid,
                    object_type="Sensor",
                    object_primary_key=self.sensor_id,
                    property_name="seriesId",
                )
                if (series_id is not None and self._ontologies_client is not None and self._ontology_rid is not None)
                else None
            ),
        )

        if TYPE_CHECKING:
            self.rid = rid
            self.is_categorical = is_categorical
            self.internal_interpolation = internal_interpolation
            self.sensor_name1 = sensor_name1
            self.sensor_type = sensor_type
            self.location = location
            self.units = units
            self.robot_id = robot_id
            self.sensor_type_id = sensor_type_id
            self.sensor_id = sensor_id
            self.status = status
            self.series_id = (
                Timeseries[float](
                    _ontologies_client=self._ontologies_client,
                    _ontology_rid=self._ontology_rid,
                    object_type="Sensor",
                    object_primary_key=self.sensor_id,
                    property_name="seriesId",
                )
                if (series_id is not None and self._ontologies_client is not None and self._ontology_rid is not None)
                else None
            )

    def count() -> AggregationType:
        return AggregationType(aggregation_type="count")

    def __setattr__(self, name, value):
        if self._initialized:
            raise AttributeError("Cannot modify attributes after initialization")
        object.__setattr__(self, name, value)

    @staticmethod
    def api_name() -> str:
        return "Sensor"

    @staticmethod
    def primary_key() -> str:
        return "sensor_id"

    @staticmethod
    def primary_key_type() -> type:
        return str

    @staticmethod
    def init_from_primary_key(primary_key: str, ontologies_client: Optional[OntologiesClient] = None) -> "Sensor":
        from physical_ai_qa_cell_sdk import FoundryClient

        client = (
            FoundryClient._init_from_ontologies_client(ontologies_client=ontologies_client)
            if ontologies_client
            else FoundryClient()
        )
        return client.ontology.objects.Sensor.get(primary_key)

    def get_primary_key(self) -> str:
        return self.sensor_id

    def to_object_set(self) -> "SensorObjectSet":
        from physical_ai_qa_cell_sdk import FoundryClient

        return FoundryClient().ontology.objects.Sensor.where(SensorObjectType.sensor_id == self.sensor_id)

    def __eq__(self, other: Any) -> bool:
        return self is other or (
            type(self) == type(other)
            and (self.is_categorical == other.is_categorical)
            and (self.internal_interpolation == other.internal_interpolation)
            and (self.sensor_name1 == other.sensor_name1)
            and (self.sensor_type == other.sensor_type)
            and (self.location == other.location)
            and (self.units == other.units)
            and (self.robot_id == other.robot_id)
            and (self.sensor_type_id == other.sensor_type_id)
            and (self.sensor_id == other.sensor_id)
            and (self.status == other.status)
            and (self.series_id == other.series_id)
            and (self.rid == other.rid)
        )

    def __hash__(self) -> int:
        return hash(
            (
                type(self),
                sanitize_for_hashing(self.is_categorical),
                sanitize_for_hashing(self.internal_interpolation),
                sanitize_for_hashing(self.sensor_name1),
                sanitize_for_hashing(self.sensor_type),
                sanitize_for_hashing(self.location),
                sanitize_for_hashing(self.units),
                sanitize_for_hashing(self.robot_id),
                sanitize_for_hashing(self.sensor_type_id),
                sanitize_for_hashing(self.sensor_id),
                sanitize_for_hashing(self.status),
                sanitize_for_hashing(self.series_id),
                sanitize_for_hashing(self.rid),
            )
        )

    def __repr__(self) -> str:
        attrs = {
            key.removeprefix("BETA_PROPERTY__"): value
            for key, value in vars(self).items()
            if not key.startswith("_") or key == "_score"
        }
        attrs_str = ", ".join(f"{key}={value}" for key, value in attrs.items())
        return f"Sensor({attrs_str})"

    def _asdict(self) -> dict[str, Any]:
        return {
            "isCategorical": self.is_categorical,
            "internalInterpolation": self.internal_interpolation,
            "sensorName1": self.sensor_name1,
            "sensorType": self.sensor_type,
            "location": self.location,
            "units": self.units,
            "robotId": self.robot_id,
            "sensorTypeId": self.sensor_type_id,
            "sensorId": self.sensor_id,
            "status": self.status,
            "seriesId": self.series_id._asdict() if self.series_id else None,
            "$rid": self.rid,
        }

    @staticmethod
    @cache
    def _fields() -> dict[str, Any]:
        return {
            "isCategorical": Optional[bool],
            "internalInterpolation": Optional[str],
            "sensorName1": Optional[str],
            "sensorType": Optional[str],
            "location": Optional[str],
            "units": Optional[str],
            "robotId": Optional[str],
            "sensorTypeId": Optional[str],
            "sensorId": Optional[str],
            "status": Optional[str],
            "seriesId": Optional[Timeseries[float]],
            "$rid": Optional[str],
        }

    @staticmethod
    @cache
    def _api_name_to_property_name() -> dict[str, str]:
        return {
            "isCategorical": "is_categorical",
            "internalInterpolation": "internal_interpolation",
            "sensorName1": "sensor_name1",
            "sensorType": "sensor_type",
            "location": "location",
            "units": "units",
            "robotId": "robot_id",
            "sensorTypeId": "sensor_type_id",
            "sensorId": "sensor_id",
            "status": "status",
            "seriesId": "series_id",
            "$rid": "rid",
        }

    def robot(
        self, properties: Optional[list[ObjectTypeProperty]] = None, include_rid: bool = False
    ) -> Optional["Robot"]:
        from physical_ai_qa_cell_sdk.ontology.object_sets import SensorObjectSet

        linked_objects = (
            SensorObjectSet(
                _ontologies_client=self._ontologies_client,
                _ontology_rid=self._ontology_rid,
            )
            .where(SensorObjectType.sensor_id == self.sensor_id)
            .search_around_robot()
            .take(
                num_items=1,
                properties=properties,
                include_rid=include_rid,
            )
        )
        if len(linked_objects) > 0:
            return linked_objects[0]
        else:
            return None
