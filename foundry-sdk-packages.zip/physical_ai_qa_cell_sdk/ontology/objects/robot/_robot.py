#  (c) Copyright 2023 Palantir Technologies Inc. All rights reserved.
from datetime import datetime
from functools import cache
from typing import TYPE_CHECKING, Any, Optional

from foundry_sdk.v2.ontologies import OntologiesClient
from foundry_sdk_runtime import OntologyObject
from foundry_sdk_runtime.properties.helpers import AggregationType
from foundry_sdk_runtime.types import sanitize_for_hashing

from ...search import RobotObjectType

if TYPE_CHECKING:
    from physical_ai_qa_cell_sdk.ontology.object_sets import RobotObjectSet
    from physical_ai_qa_cell_sdk.ontology.object_sets._grip_reading import GripReadingObjectSet
    from physical_ai_qa_cell_sdk.ontology.object_sets._inspection_event import InspectionEventObjectSet
    from physical_ai_qa_cell_sdk.ontology.object_sets._operator_command import OperatorCommandObjectSet
    from physical_ai_qa_cell_sdk.ontology.object_sets._sensor import SensorObjectSet
    from physical_ai_qa_cell_sdk.ontology.object_sets._vision_reading import VisionReadingObjectSet

from typing import Any


class Robot(OntologyObject):
    """
    Wraps the Robot ontology object.

    Physical robot in the QA cell. Tracks status, configuration, and heartbeat. Updated by the edge agent via OSDK.
    # Code Samples

    ## Declare a function taking an object as a parameter
    ```
    from physical_ai_qa_cell_sdk.ontology.objects import Robot

    def get_key_for_Robot(obj: Robot) -> str:
      return obj.robot_id
    ```

    ## Using a FoundryClient to retrieve an instance of an object
    ```
    from physical_ai_qa_cell_sdk import FoundryClient

    def get_title_for_Robot(key: str) -> str:
      client = FoundryClient()

      obj = client.ontology.objects.Robot.get(key)
      return obj.title_PLACEHOLDER
    ```

    ## Return an instance of an object
    ```
    from physical_ai_qa_cell_sdk import FoundryClient

    def get_with_id_Robot(key: str) -> Robot:
        client = FoundryClient()

        return client.ontology.objects.Robot.get(key)
    ```

    ## Retrieve an object via a query
    ```
    from physical_ai_qa_cell_sdk import FoundryClient
    from physical_ai_qa_cell_sdk.ontology.objects import Robot

    def get_first_by_name_Robot(name: str) -> Robot:
        client = FoundryClient()

        objset = client.ontology.objects.Robot.where(
          Robot.PLACEHOLDER == name)

        return next(iter(objset, None))
    ```
    """

    object_type: RobotObjectType = RobotObjectType()

    def __init__(
        self,
        last_heartbeat: Optional[datetime] = None,
        current_model_version: Optional[str] = None,
        name: Optional[str] = None,
        total_inspections: Optional[int] = None,
        robot_id: Optional[str] = None,
        grip_tolerance: Optional[float] = None,
        status: Optional[str] = None,
        rid: Optional[str] = None,
        _ontologies_client: Optional[OntologiesClient] = None,
        _ontology_rid: Optional[str] = None,
    ) -> None:
        object.__setattr__(self, "_initialized", False)
        object.__setattr__(self, "_ontologies_client", _ontologies_client)
        object.__setattr__(self, "_ontology_rid", _ontology_rid)
        object.__setattr__(self, "rid", rid)
        object.__setattr__(self, "last_heartbeat", last_heartbeat)
        object.__setattr__(self, "current_model_version", current_model_version)
        object.__setattr__(self, "name", name)
        object.__setattr__(self, "total_inspections", total_inspections)
        object.__setattr__(self, "robot_id", robot_id)
        object.__setattr__(self, "grip_tolerance", grip_tolerance)
        object.__setattr__(self, "status", status)

        if TYPE_CHECKING:
            self.rid = rid
            self.last_heartbeat = last_heartbeat
            self.current_model_version = current_model_version
            self.name = name
            self.total_inspections = total_inspections
            self.robot_id = robot_id
            self.grip_tolerance = grip_tolerance
            self.status = status

    def count() -> AggregationType:
        return AggregationType(aggregation_type="count")

    def __setattr__(self, name, value):
        if self._initialized:
            raise AttributeError("Cannot modify attributes after initialization")
        object.__setattr__(self, name, value)

    @staticmethod
    def api_name() -> str:
        return "Robot"

    @staticmethod
    def primary_key() -> str:
        return "robot_id"

    @staticmethod
    def primary_key_type() -> type:
        return str

    @staticmethod
    def init_from_primary_key(primary_key: str, ontologies_client: Optional[OntologiesClient] = None) -> "Robot":
        from physical_ai_qa_cell_sdk import FoundryClient

        client = (
            FoundryClient._init_from_ontologies_client(ontologies_client=ontologies_client)
            if ontologies_client
            else FoundryClient()
        )
        return client.ontology.objects.Robot.get(primary_key)

    def get_primary_key(self) -> str:
        return self.robot_id

    def to_object_set(self) -> "RobotObjectSet":
        from physical_ai_qa_cell_sdk import FoundryClient

        return FoundryClient().ontology.objects.Robot.where(RobotObjectType.robot_id == self.robot_id)

    def __eq__(self, other: Any) -> bool:
        return self is other or (
            type(self) == type(other)
            and (self.last_heartbeat == other.last_heartbeat)
            and (self.current_model_version == other.current_model_version)
            and (self.name == other.name)
            and (self.total_inspections == other.total_inspections)
            and (self.robot_id == other.robot_id)
            and (self.grip_tolerance == other.grip_tolerance)
            and (self.status == other.status)
            and (self.rid == other.rid)
        )

    def __hash__(self) -> int:
        return hash(
            (
                type(self),
                sanitize_for_hashing(self.last_heartbeat),
                sanitize_for_hashing(self.current_model_version),
                sanitize_for_hashing(self.name),
                sanitize_for_hashing(self.total_inspections),
                sanitize_for_hashing(self.robot_id),
                sanitize_for_hashing(self.grip_tolerance),
                sanitize_for_hashing(self.status),
                sanitize_for_hashing(self.rid),
            )
        )

    def __repr__(self) -> str:
        attrs = {
            key.removeprefix("BETA_PROPERTY__"): value
            for key, value in vars(self).items()
            if not key.startswith("_") or key == "_score"
        }
        attrs_str = ", ".join(f"{key}={value}" for key, value in attrs.items())
        return f"Robot({attrs_str})"

    def _asdict(self) -> dict[str, Any]:
        return {
            "lastHeartbeat": self.last_heartbeat,
            "currentModelVersion": self.current_model_version,
            "name": self.name,
            "totalInspections": self.total_inspections,
            "robotId": self.robot_id,
            "gripTolerance": self.grip_tolerance,
            "status": self.status,
            "$rid": self.rid,
        }

    @staticmethod
    @cache
    def _fields() -> dict[str, Any]:
        return {
            "lastHeartbeat": Optional[datetime],
            "currentModelVersion": Optional[str],
            "name": Optional[str],
            "totalInspections": Optional[int],
            "robotId": Optional[str],
            "gripTolerance": Optional[float],
            "status": Optional[str],
            "$rid": Optional[str],
        }

    @staticmethod
    @cache
    def _api_name_to_property_name() -> dict[str, str]:
        return {
            "lastHeartbeat": "last_heartbeat",
            "currentModelVersion": "current_model_version",
            "name": "name",
            "totalInspections": "total_inspections",
            "robotId": "robot_id",
            "gripTolerance": "grip_tolerance",
            "status": "status",
            "$rid": "rid",
        }

    def grip_readings(self) -> "GripReadingObjectSet":
        from physical_ai_qa_cell_sdk.ontology.object_sets import RobotObjectSet

        return (
            RobotObjectSet(
                _ontologies_client=self._ontologies_client,
                _ontology_rid=self._ontology_rid,
            )
            .where(RobotObjectType.robot_id == self.robot_id)
            .search_around_grip_readings()
        )

    def inspection_events(self) -> "InspectionEventObjectSet":
        from physical_ai_qa_cell_sdk.ontology.object_sets import RobotObjectSet

        return (
            RobotObjectSet(
                _ontologies_client=self._ontologies_client,
                _ontology_rid=self._ontology_rid,
            )
            .where(RobotObjectType.robot_id == self.robot_id)
            .search_around_inspection_events()
        )

    def operator_commands(self) -> "OperatorCommandObjectSet":
        from physical_ai_qa_cell_sdk.ontology.object_sets import RobotObjectSet

        return (
            RobotObjectSet(
                _ontologies_client=self._ontologies_client,
                _ontology_rid=self._ontology_rid,
            )
            .where(RobotObjectType.robot_id == self.robot_id)
            .search_around_operator_commands()
        )

    def sensors(self) -> "SensorObjectSet":
        from physical_ai_qa_cell_sdk.ontology.object_sets import RobotObjectSet

        return (
            RobotObjectSet(
                _ontologies_client=self._ontologies_client,
                _ontology_rid=self._ontology_rid,
            )
            .where(RobotObjectType.robot_id == self.robot_id)
            .search_around_sensors()
        )

    def vision_readings(self) -> "VisionReadingObjectSet":
        from physical_ai_qa_cell_sdk.ontology.object_sets import RobotObjectSet

        return (
            RobotObjectSet(
                _ontologies_client=self._ontologies_client,
                _ontology_rid=self._ontology_rid,
            )
            .where(RobotObjectType.robot_id == self.robot_id)
            .search_around_vision_readings()
        )
