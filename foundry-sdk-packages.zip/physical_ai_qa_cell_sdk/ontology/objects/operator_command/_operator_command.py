#  (c) Copyright 2023 Palantir Technologies Inc. All rights reserved.
from datetime import datetime
from functools import cache
from typing import TYPE_CHECKING, Any, Optional

from foundry_sdk.v2.ontologies import OntologiesClient
from foundry_sdk_runtime import OntologyObject
from foundry_sdk_runtime.properties import ObjectTypeProperty
from foundry_sdk_runtime.properties.helpers import AggregationType
from foundry_sdk_runtime.types import sanitize_for_hashing

from ...search import OperatorCommandObjectType

if TYPE_CHECKING:
    from physical_ai_qa_cell_sdk.ontology.object_sets import OperatorCommandObjectSet
    from ._robot import Robot

from typing import Any


class OperatorCommand(OntologyObject):
    """
    Wraps the OperatorCommand ontology object.

    Commands sent from the dashboard to a robot. Created via OSDK action, polled by the edge agent, and acknowledged on execution.
    # Code Samples

    ## Declare a function taking an object as a parameter
    ```
    from physical_ai_qa_cell_sdk.ontology.objects import OperatorCommand

    def get_key_for_OperatorCommand(obj: OperatorCommand) -> str:
      return obj.command_id
    ```

    ## Using a FoundryClient to retrieve an instance of an object
    ```
    from physical_ai_qa_cell_sdk import FoundryClient

    def get_title_for_OperatorCommand(key: str) -> str:
      client = FoundryClient()

      obj = client.ontology.objects.OperatorCommand.get(key)
      return obj.title_PLACEHOLDER
    ```

    ## Return an instance of an object
    ```
    from physical_ai_qa_cell_sdk import FoundryClient

    def get_with_id_OperatorCommand(key: str) -> OperatorCommand:
        client = FoundryClient()

        return client.ontology.objects.OperatorCommand.get(key)
    ```

    ## Retrieve an object via a query
    ```
    from physical_ai_qa_cell_sdk import FoundryClient
    from physical_ai_qa_cell_sdk.ontology.objects import OperatorCommand

    def get_first_by_name_OperatorCommand(name: str) -> OperatorCommand:
        client = FoundryClient()

        objset = client.ontology.objects.OperatorCommand.where(
          OperatorCommand.PLACEHOLDER == name)

        return next(iter(objset, None))
    ```
    """

    object_type: OperatorCommandObjectType = OperatorCommandObjectType()

    def __init__(
        self,
        created_at: Optional[datetime] = None,
        command_type: Optional[str] = None,
        executed_at: Optional[datetime] = None,
        payload: Optional[str] = None,
        robot_id: Optional[str] = None,
        command_id: Optional[str] = None,
        status: Optional[str] = None,
        rid: Optional[str] = None,
        _ontologies_client: Optional[OntologiesClient] = None,
        _ontology_rid: Optional[str] = None,
    ) -> None:
        object.__setattr__(self, "_initialized", False)
        object.__setattr__(self, "_ontologies_client", _ontologies_client)
        object.__setattr__(self, "_ontology_rid", _ontology_rid)
        object.__setattr__(self, "rid", rid)
        object.__setattr__(self, "created_at", created_at)
        object.__setattr__(self, "command_type", command_type)
        object.__setattr__(self, "executed_at", executed_at)
        object.__setattr__(self, "payload", payload)
        object.__setattr__(self, "robot_id", robot_id)
        object.__setattr__(self, "command_id", command_id)
        object.__setattr__(self, "status", status)

        if TYPE_CHECKING:
            self.rid = rid
            self.created_at = created_at
            self.command_type = command_type
            self.executed_at = executed_at
            self.payload = payload
            self.robot_id = robot_id
            self.command_id = command_id
            self.status = status

    def count() -> AggregationType:
        return AggregationType(aggregation_type="count")

    def __setattr__(self, name, value):
        if self._initialized:
            raise AttributeError("Cannot modify attributes after initialization")
        object.__setattr__(self, name, value)

    @staticmethod
    def api_name() -> str:
        return "OperatorCommand"

    @staticmethod
    def primary_key() -> str:
        return "command_id"

    @staticmethod
    def primary_key_type() -> type:
        return str

    @staticmethod
    def init_from_primary_key(
        primary_key: str, ontologies_client: Optional[OntologiesClient] = None
    ) -> "OperatorCommand":
        from physical_ai_qa_cell_sdk import FoundryClient

        client = (
            FoundryClient._init_from_ontologies_client(ontologies_client=ontologies_client)
            if ontologies_client
            else FoundryClient()
        )
        return client.ontology.objects.OperatorCommand.get(primary_key)

    def get_primary_key(self) -> str:
        return self.command_id

    def to_object_set(self) -> "OperatorCommandObjectSet":
        from physical_ai_qa_cell_sdk import FoundryClient

        return FoundryClient().ontology.objects.OperatorCommand.where(
            OperatorCommandObjectType.command_id == self.command_id
        )

    def __eq__(self, other: Any) -> bool:
        return self is other or (
            type(self) == type(other)
            and (self.created_at == other.created_at)
            and (self.command_type == other.command_type)
            and (self.executed_at == other.executed_at)
            and (self.payload == other.payload)
            and (self.robot_id == other.robot_id)
            and (self.command_id == other.command_id)
            and (self.status == other.status)
            and (self.rid == other.rid)
        )

    def __hash__(self) -> int:
        return hash(
            (
                type(self),
                sanitize_for_hashing(self.created_at),
                sanitize_for_hashing(self.command_type),
                sanitize_for_hashing(self.executed_at),
                sanitize_for_hashing(self.payload),
                sanitize_for_hashing(self.robot_id),
                sanitize_for_hashing(self.command_id),
                sanitize_for_hashing(self.status),
                sanitize_for_hashing(self.rid),
            )
        )

    def __repr__(self) -> str:
        attrs = {
            key.removeprefix("BETA_PROPERTY__"): value
            for key, value in vars(self).items()
            if not key.startswith("_") or key == "_score"
        }
        attrs_str = ", ".join(f"{key}={value}" for key, value in attrs.items())
        return f"OperatorCommand({attrs_str})"

    def _asdict(self) -> dict[str, Any]:
        return {
            "createdAt": self.created_at,
            "commandType": self.command_type,
            "executedAt": self.executed_at,
            "payload": self.payload,
            "robotId": self.robot_id,
            "commandId": self.command_id,
            "status": self.status,
            "$rid": self.rid,
        }

    @staticmethod
    @cache
    def _fields() -> dict[str, Any]:
        return {
            "createdAt": Optional[datetime],
            "commandType": Optional[str],
            "executedAt": Optional[datetime],
            "payload": Optional[str],
            "robotId": Optional[str],
            "commandId": Optional[str],
            "status": Optional[str],
            "$rid": Optional[str],
        }

    @staticmethod
    @cache
    def _api_name_to_property_name() -> dict[str, str]:
        return {
            "createdAt": "created_at",
            "commandType": "command_type",
            "executedAt": "executed_at",
            "payload": "payload",
            "robotId": "robot_id",
            "commandId": "command_id",
            "status": "status",
            "$rid": "rid",
        }

    def target_robot(
        self, properties: Optional[list[ObjectTypeProperty]] = None, include_rid: bool = False
    ) -> Optional["Robot"]:
        from physical_ai_qa_cell_sdk.ontology.object_sets import OperatorCommandObjectSet

        linked_objects = (
            OperatorCommandObjectSet(
                _ontologies_client=self._ontologies_client,
                _ontology_rid=self._ontology_rid,
            )
            .where(OperatorCommandObjectType.command_id == self.command_id)
            .search_around_target_robot()
            .take(
                num_items=1,
                properties=properties,
                include_rid=include_rid,
            )
        )
        if len(linked_objects) > 0:
            return linked_objects[0]
        else:
            return None
