#  (c) Copyright 2023 Palantir Technologies Inc. All rights reserved.
from datetime import datetime
from functools import cache
from typing import TYPE_CHECKING, Any, Optional

from foundry_sdk.v2.ontologies import OntologiesClient
from foundry_sdk_runtime import OntologyObject
from foundry_sdk_runtime.decorators import beta
from foundry_sdk_runtime.media import Media
from foundry_sdk_runtime.properties import ObjectTypeProperty
from foundry_sdk_runtime.properties.helpers import AggregationType
from foundry_sdk_runtime.types import sanitize_for_hashing

from ...search import InspectionEventObjectType

if TYPE_CHECKING:
    from physical_ai_qa_cell_sdk.ontology.object_sets import InspectionEventObjectSet
    from physical_ai_qa_cell_sdk.ontology.object_sets._grip_reading import GripReadingObjectSet
    from physical_ai_qa_cell_sdk.ontology.object_sets._vision_reading import VisionReadingObjectSet
    from ._robot import Robot

from typing import Any


class InspectionEvent(OntologyObject):
    """
    Wraps the InspectionEvent ontology object.

    Fused inspection decision combining vision and grip data. Created by the edge agent via OSDK. Includes human-in-the-loop review workflow for uncertain decisions.
    # Code Samples

    ## Declare a function taking an object as a parameter
    ```
    from physical_ai_qa_cell_sdk.ontology.objects import InspectionEvent

    def get_key_for_InspectionEvent(obj: InspectionEvent) -> str:
      return obj.inspection_id
    ```

    ## Using a FoundryClient to retrieve an instance of an object
    ```
    from physical_ai_qa_cell_sdk import FoundryClient

    def get_title_for_InspectionEvent(key: str) -> str:
      client = FoundryClient()

      obj = client.ontology.objects.InspectionEvent.get(key)
      return obj.title_PLACEHOLDER
    ```

    ## Return an instance of an object
    ```
    from physical_ai_qa_cell_sdk import FoundryClient

    def get_with_id_InspectionEvent(key: str) -> InspectionEvent:
        client = FoundryClient()

        return client.ontology.objects.InspectionEvent.get(key)
    ```

    ## Retrieve an object via a query
    ```
    from physical_ai_qa_cell_sdk import FoundryClient
    from physical_ai_qa_cell_sdk.ontology.objects import InspectionEvent

    def get_first_by_name_InspectionEvent(name: str) -> InspectionEvent:
        client = FoundryClient()

        objset = client.ontology.objects.InspectionEvent.where(
          InspectionEvent.PLACEHOLDER == name)

        return next(iter(objset, None))
    ```
    """

    object_type: InspectionEventObjectType = InspectionEventObjectType()

    def __init__(
        self,
        grip_load: Optional[float] = None,
        model_version: Optional[str] = None,
        reviewed_at: Optional[datetime] = None,
        final_decision: Optional[str] = None,
        reviewed_by: Optional[str] = None,
        robot_id: Optional[str] = None,
        fusion_decision: Optional[str] = None,
        inspection_id: Optional[str] = None,
        vision_agrees: Optional[bool] = None,
        operator_notes: Optional[str] = None,
        vision_confidence: Optional[float] = None,
        review_status: Optional[str] = None,
        cycle_time_ms: Optional[int] = None,
        vision_class: Optional[str] = None,
        fusion_reason: Optional[str] = None,
        timestamp: Optional[datetime] = None,
        captured_image_ref: Optional[Media] = None,
        rid: Optional[str] = None,
        _ontologies_client: Optional[OntologiesClient] = None,
        _ontology_rid: Optional[str] = None,
    ) -> None:
        object.__setattr__(self, "_initialized", False)
        object.__setattr__(self, "_ontologies_client", _ontologies_client)
        object.__setattr__(self, "_ontology_rid", _ontology_rid)
        object.__setattr__(self, "rid", rid)
        object.__setattr__(self, "grip_load", grip_load)
        object.__setattr__(self, "model_version", model_version)
        object.__setattr__(self, "reviewed_at", reviewed_at)
        object.__setattr__(self, "final_decision", final_decision)
        object.__setattr__(self, "reviewed_by", reviewed_by)
        object.__setattr__(self, "robot_id", robot_id)
        object.__setattr__(self, "fusion_decision", fusion_decision)
        object.__setattr__(self, "inspection_id", inspection_id)
        object.__setattr__(self, "vision_agrees", vision_agrees)
        object.__setattr__(self, "operator_notes", operator_notes)
        object.__setattr__(self, "vision_confidence", vision_confidence)
        object.__setattr__(self, "review_status", review_status)
        object.__setattr__(self, "cycle_time_ms", cycle_time_ms)
        object.__setattr__(self, "vision_class", vision_class)
        object.__setattr__(self, "fusion_reason", fusion_reason)
        object.__setattr__(self, "timestamp", timestamp)
        object.__setattr__(
            self,
            "BETA_PROPERTY__captured_image_ref",
            (
                Media(
                    _ontologies_client=self._ontologies_client,
                    _ontology_rid=self._ontology_rid,
                    object_type="InspectionEvent",
                    object_primary_key=self.inspection_id,
                    property_name="capturedImageRef",
                    media_reference=captured_image_ref._media_reference,
                )
                if (
                    captured_image_ref is not None
                    and self._ontologies_client is not None
                    and self._ontology_rid is not None
                )
                else None
            ),
        )

        if TYPE_CHECKING:
            self.rid = rid
            self.grip_load = grip_load
            self.model_version = model_version
            self.reviewed_at = reviewed_at
            self.final_decision = final_decision
            self.reviewed_by = reviewed_by
            self.robot_id = robot_id
            self.fusion_decision = fusion_decision
            self.inspection_id = inspection_id
            self.vision_agrees = vision_agrees
            self.operator_notes = operator_notes
            self.vision_confidence = vision_confidence
            self.review_status = review_status
            self.cycle_time_ms = cycle_time_ms
            self.vision_class = vision_class
            self.fusion_reason = fusion_reason
            self.timestamp = timestamp

    def count() -> AggregationType:
        return AggregationType(aggregation_type="count")

    def __setattr__(self, name, value):
        if self._initialized:
            raise AttributeError("Cannot modify attributes after initialization")
        object.__setattr__(self, name, value)

    @property
    @beta("Properties of type Media are in beta and may change in future versions.")
    def captured_image_ref(self) -> Optional[Media]:
        return self.BETA_PROPERTY__captured_image_ref

    @staticmethod
    def api_name() -> str:
        return "InspectionEvent"

    @staticmethod
    def primary_key() -> str:
        return "inspection_id"

    @staticmethod
    def primary_key_type() -> type:
        return str

    @staticmethod
    def init_from_primary_key(
        primary_key: str, ontologies_client: Optional[OntologiesClient] = None
    ) -> "InspectionEvent":
        from physical_ai_qa_cell_sdk import FoundryClient

        client = (
            FoundryClient._init_from_ontologies_client(ontologies_client=ontologies_client)
            if ontologies_client
            else FoundryClient()
        )
        return client.ontology.objects.InspectionEvent.get(primary_key)

    def get_primary_key(self) -> str:
        return self.inspection_id

    def to_object_set(self) -> "InspectionEventObjectSet":
        from physical_ai_qa_cell_sdk import FoundryClient

        return FoundryClient().ontology.objects.InspectionEvent.where(
            InspectionEventObjectType.inspection_id == self.inspection_id
        )

    def __eq__(self, other: Any) -> bool:
        return self is other or (
            type(self) == type(other)
            and (self.grip_load == other.grip_load)
            and (self.model_version == other.model_version)
            and (self.reviewed_at == other.reviewed_at)
            and (self.final_decision == other.final_decision)
            and (self.reviewed_by == other.reviewed_by)
            and (self.robot_id == other.robot_id)
            and (self.fusion_decision == other.fusion_decision)
            and (self.inspection_id == other.inspection_id)
            and (self.vision_agrees == other.vision_agrees)
            and (self.operator_notes == other.operator_notes)
            and (self.vision_confidence == other.vision_confidence)
            and (self.review_status == other.review_status)
            and (self.cycle_time_ms == other.cycle_time_ms)
            and (self.vision_class == other.vision_class)
            and (self.fusion_reason == other.fusion_reason)
            and (self.timestamp == other.timestamp)
            and (self.captured_image_ref == other.captured_image_ref)
            and (self.rid == other.rid)
        )

    def __hash__(self) -> int:
        return hash(
            (
                type(self),
                sanitize_for_hashing(self.grip_load),
                sanitize_for_hashing(self.model_version),
                sanitize_for_hashing(self.reviewed_at),
                sanitize_for_hashing(self.final_decision),
                sanitize_for_hashing(self.reviewed_by),
                sanitize_for_hashing(self.robot_id),
                sanitize_for_hashing(self.fusion_decision),
                sanitize_for_hashing(self.inspection_id),
                sanitize_for_hashing(self.vision_agrees),
                sanitize_for_hashing(self.operator_notes),
                sanitize_for_hashing(self.vision_confidence),
                sanitize_for_hashing(self.review_status),
                sanitize_for_hashing(self.cycle_time_ms),
                sanitize_for_hashing(self.vision_class),
                sanitize_for_hashing(self.fusion_reason),
                sanitize_for_hashing(self.timestamp),
                sanitize_for_hashing(self.captured_image_ref),
                sanitize_for_hashing(self.rid),
            )
        )

    def __repr__(self) -> str:
        attrs = {
            key.removeprefix("BETA_PROPERTY__"): value
            for key, value in vars(self).items()
            if not key.startswith("_") or key == "_score"
        }
        attrs_str = ", ".join(f"{key}={value}" for key, value in attrs.items())
        return f"InspectionEvent({attrs_str})"

    def _asdict(self) -> dict[str, Any]:
        return {
            "gripLoad": self.grip_load,
            "modelVersion": self.model_version,
            "reviewedAt": self.reviewed_at,
            "finalDecision": self.final_decision,
            "reviewedBy": self.reviewed_by,
            "robotId": self.robot_id,
            "fusionDecision": self.fusion_decision,
            "inspectionId": self.inspection_id,
            "visionAgrees": self.vision_agrees,
            "operatorNotes": self.operator_notes,
            "visionConfidence": self.vision_confidence,
            "reviewStatus": self.review_status,
            "cycleTimeMs": self.cycle_time_ms,
            "visionClass": self.vision_class,
            "fusionReason": self.fusion_reason,
            "timestamp": self.timestamp,
            "capturedImageRef": self.captured_image_ref._asdict() if self.captured_image_ref else None,
            "$rid": self.rid,
        }

    @staticmethod
    @cache
    def _fields() -> dict[str, Any]:
        return {
            "gripLoad": Optional[float],
            "modelVersion": Optional[str],
            "reviewedAt": Optional[datetime],
            "finalDecision": Optional[str],
            "reviewedBy": Optional[str],
            "robotId": Optional[str],
            "fusionDecision": Optional[str],
            "inspectionId": Optional[str],
            "visionAgrees": Optional[bool],
            "operatorNotes": Optional[str],
            "visionConfidence": Optional[float],
            "reviewStatus": Optional[str],
            "cycleTimeMs": Optional[int],
            "visionClass": Optional[str],
            "fusionReason": Optional[str],
            "timestamp": Optional[datetime],
            "capturedImageRef": Optional[Media],
            "$rid": Optional[str],
        }

    @staticmethod
    @cache
    def _api_name_to_property_name() -> dict[str, str]:
        return {
            "gripLoad": "grip_load",
            "modelVersion": "model_version",
            "reviewedAt": "reviewed_at",
            "finalDecision": "final_decision",
            "reviewedBy": "reviewed_by",
            "robotId": "robot_id",
            "fusionDecision": "fusion_decision",
            "inspectionId": "inspection_id",
            "visionAgrees": "vision_agrees",
            "operatorNotes": "operator_notes",
            "visionConfidence": "vision_confidence",
            "reviewStatus": "review_status",
            "cycleTimeMs": "cycle_time_ms",
            "visionClass": "vision_class",
            "fusionReason": "fusion_reason",
            "timestamp": "timestamp",
            "capturedImageRef": "captured_image_ref",
            "$rid": "rid",
        }

    def grip_readings(self) -> "GripReadingObjectSet":
        from physical_ai_qa_cell_sdk.ontology.object_sets import InspectionEventObjectSet

        return (
            InspectionEventObjectSet(
                _ontologies_client=self._ontologies_client,
                _ontology_rid=self._ontology_rid,
            )
            .where(InspectionEventObjectType.inspection_id == self.inspection_id)
            .search_around_grip_readings()
        )

    def inspection_vision_readings(self) -> "VisionReadingObjectSet":
        from physical_ai_qa_cell_sdk.ontology.object_sets import InspectionEventObjectSet

        return (
            InspectionEventObjectSet(
                _ontologies_client=self._ontologies_client,
                _ontology_rid=self._ontology_rid,
            )
            .where(InspectionEventObjectType.inspection_id == self.inspection_id)
            .search_around_inspection_vision_readings()
        )

    def robot(
        self, properties: Optional[list[ObjectTypeProperty]] = None, include_rid: bool = False
    ) -> Optional["Robot"]:
        from physical_ai_qa_cell_sdk.ontology.object_sets import InspectionEventObjectSet

        linked_objects = (
            InspectionEventObjectSet(
                _ontologies_client=self._ontologies_client,
                _ontology_rid=self._ontology_rid,
            )
            .where(InspectionEventObjectType.inspection_id == self.inspection_id)
            .search_around_robot()
            .take(
                num_items=1,
                properties=properties,
                include_rid=include_rid,
            )
        )
        if len(linked_objects) > 0:
            return linked_objects[0]
        else:
            return None
