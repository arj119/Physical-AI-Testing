"""File containing all types associated with an Object Type."""

from typing import Literal

LinkApiNames = Literal[
    "gripReadings",
    "inspectionVisionReadings",
    "robot",
]
