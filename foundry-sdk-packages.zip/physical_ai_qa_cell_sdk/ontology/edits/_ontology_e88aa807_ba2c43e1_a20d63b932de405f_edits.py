from foundry_sdk.v2.ontologies import OntologiesClient
from foundry_sdk_runtime import OntologyEdits

from ._ontology_e88aa807_ba2c43e1_a20d63b932de405f_object_edits import (
    OntologyE88aa807Ba2c43e1A20d63b932de405fObjectEdits,
)


class OntologyE88aa807Ba2c43e1A20d63b932de405fEdits(OntologyEdits):
    def __init__(self, _ontologies_client: OntologiesClient, _ontology_rid: str):
        super().__init__()
        self._ontologies_client = _ontologies_client
        self._ontology_rid = _ontology_rid

    @property
    def objects(self) -> OntologyE88aa807Ba2c43e1A20d63b932de405fObjectEdits:
        return OntologyE88aa807Ba2c43e1A20d63b932de405fObjectEdits(
            _ontology_edits=self, _ontologies_client=self._ontologies_client, _ontology_rid=self._ontology_rid
        )
