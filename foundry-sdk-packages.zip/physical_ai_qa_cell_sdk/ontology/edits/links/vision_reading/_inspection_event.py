from typing import TYPE_CHECKING, Optional, Union

from foundry_sdk.v2.ontologies import OntologiesClient
from foundry_sdk_runtime import ObjectLocator
from physical_ai_qa_cell_sdk.ontology.objects import VisionReading

if TYPE_CHECKING:
    from foundry_sdk_runtime import OntologyEdits
    from physical_ai_qa_cell_sdk.ontology.edits.objects import InspectionEventEdits
    from physical_ai_qa_cell_sdk.ontology.objects import InspectionEvent


class VisionReadingInspectionEventLinkEdits:
    def __init__(
        self,
        ontology_edits: "OntologyEdits",
        _ontologies_client: OntologiesClient,
        _ontology_rid: str,
        reading_id: Optional[str] = None,
    ) -> None:
        self._ontologies_client = _ontologies_client
        self._ontology_rid = _ontology_rid
        self._ontology_edits = ontology_edits
        self._reading_id = reading_id

    def set(
        self,
        linked: Union[
            "InspectionEvent",
            "InspectionEventEdits",
        ],
    ):
        source_object_locator = ObjectLocator(object_api_name="VisionReading", primary_key=self._reading_id)
        self._ontology_edits.modify(locator=source_object_locator, fields={"inspectionId": linked.get_primary_key()})

    def clear(
        self,
    ):
        linked_object = VisionReading(
            reading_id=self._reading_id,
            _ontologies_client=self._ontologies_client,
            _ontology_rid=self._ontology_rid,
        ).inspection_event()
        if not linked_object:
            return
        source_object_locator = ObjectLocator(object_api_name="VisionReading", primary_key=self._reading_id)
        self._ontology_edits.modify(locator=source_object_locator, fields={"inspectionId": None})
