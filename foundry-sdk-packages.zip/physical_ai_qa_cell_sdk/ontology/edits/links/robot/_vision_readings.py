from typing import TYPE_CHECKING, Optional, Union

from foundry_sdk.v2.ontologies import OntologiesClient
from foundry_sdk_runtime import ObjectLocator

if TYPE_CHECKING:
    from foundry_sdk_runtime import OntologyEdits
    from physical_ai_qa_cell_sdk.ontology.edits.objects import VisionReadingEdits
    from physical_ai_qa_cell_sdk.ontology.object_sets import VisionReadingObjectSet
    from physical_ai_qa_cell_sdk.ontology.objects import VisionReading


class RobotVisionReadingsLinkEdits:
    def __init__(
        self,
        ontology_edits: "OntologyEdits",
        _ontologies_client: OntologiesClient,
        _ontology_rid: str,
        robot_id: Optional[str] = None,
    ) -> None:
        self._ontologies_client = _ontologies_client
        self._ontology_rid = _ontology_rid
        self._ontology_edits = ontology_edits
        self._robot_id = robot_id

    def add(
        self,
        linked: Union[
            "VisionReading",
            "VisionReadingEdits",
            "VisionReadingObjectSet",
        ],
    ):
        from physical_ai_qa_cell_sdk.ontology.edits.objects import VisionReadingEdits
        from physical_ai_qa_cell_sdk.ontology.object_sets import VisionReadingObjectSet
        from physical_ai_qa_cell_sdk.ontology.objects import VisionReading

        if isinstance(linked, VisionReadingObjectSet):
            for object in linked.iterate():
                self._add_link_helper(self._ontology_edits, object)
        elif isinstance(linked, (VisionReading, VisionReadingEdits)):
            self._add_link_helper(self._ontology_edits, linked)
        else:
            raise ValueError("linked must be of type VisionReading or VisionReadingObjectSet")

    def _add_link_helper(
        self,
        ontology_edits: "OntologyEdits",
        linked_object: Union[
            "VisionReading",
            "VisionReadingEdits",
        ],
    ):
        source_object_locator = ObjectLocator(
            object_api_name="VisionReading", primary_key=linked_object.get_primary_key()
        )
        ontology_edits.modify(locator=source_object_locator, fields={"robotId": self._robot_id})

    def remove(
        self,
        linked: Union[
            "VisionReading",
            "VisionReadingEdits",
            "VisionReadingObjectSet",
        ],
    ):
        from physical_ai_qa_cell_sdk.ontology.edits.objects import VisionReadingEdits
        from physical_ai_qa_cell_sdk.ontology.object_sets import VisionReadingObjectSet
        from physical_ai_qa_cell_sdk.ontology.objects import VisionReading

        if isinstance(linked, VisionReadingObjectSet):
            for object in linked.iterate():
                self._remove_link_helper(self._ontology_edits, object)
        elif isinstance(linked, (VisionReading, VisionReadingEdits)):
            self._remove_link_helper(self._ontology_edits, linked)
        else:
            raise ValueError("linked must be of type VisionReading or VisionReadingObjectSet")

    def _remove_link_helper(
        self,
        ontology_edits: "OntologyEdits",
        object: Union[
            "VisionReading",
            "VisionReadingEdits",
        ],
    ):

        source_object_locator = ObjectLocator(object_api_name="VisionReading", primary_key=object.get_primary_key())
        ontology_edits.modify(locator=source_object_locator, fields={"robotId": None})
