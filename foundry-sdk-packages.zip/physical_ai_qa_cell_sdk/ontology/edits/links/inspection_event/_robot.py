from typing import TYPE_CHECKING, Optional, Union

from foundry_sdk.v2.ontologies import OntologiesClient
from foundry_sdk_runtime import ObjectLocator
from physical_ai_qa_cell_sdk.ontology.objects import InspectionEvent

if TYPE_CHECKING:
    from foundry_sdk_runtime import OntologyEdits
    from physical_ai_qa_cell_sdk.ontology.edits.objects import RobotEdits
    from physical_ai_qa_cell_sdk.ontology.objects import Robot


class InspectionEventRobotLinkEdits:
    def __init__(
        self,
        ontology_edits: "OntologyEdits",
        _ontologies_client: OntologiesClient,
        _ontology_rid: str,
        inspection_id: Optional[str] = None,
    ) -> None:
        self._ontologies_client = _ontologies_client
        self._ontology_rid = _ontology_rid
        self._ontology_edits = ontology_edits
        self._inspection_id = inspection_id

    def set(
        self,
        linked: Union[
            "Robot",
            "RobotEdits",
        ],
    ):
        source_object_locator = ObjectLocator(object_api_name="InspectionEvent", primary_key=self._inspection_id)
        self._ontology_edits.modify(locator=source_object_locator, fields={"robotId": linked.get_primary_key()})

    def clear(
        self,
    ):
        linked_object = InspectionEvent(
            inspection_id=self._inspection_id,
            _ontologies_client=self._ontologies_client,
            _ontology_rid=self._ontology_rid,
        ).robot()
        if not linked_object:
            return
        source_object_locator = ObjectLocator(object_api_name="InspectionEvent", primary_key=self._inspection_id)
        self._ontology_edits.modify(locator=source_object_locator, fields={"robotId": None})
