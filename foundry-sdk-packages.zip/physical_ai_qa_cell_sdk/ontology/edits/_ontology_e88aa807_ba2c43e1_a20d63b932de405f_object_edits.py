from typing import TYPE_CHECKING

from foundry_sdk.v2.ontologies import OntologiesClient

from .object_edits_factory import (
    GripReadingEditsFactory,
    InspectionEventEditsFactory,
    ModelRegistryEditsFactory,
    OperatorCommandEditsFactory,
    RobotEditsFactory,
    SensorEditsFactory,
    VisionReadingEditsFactory,
)

if TYPE_CHECKING:
    from foundry_sdk_runtime import OntologyEdits


class OntologyE88aa807Ba2c43e1A20d63b932de405fObjectEdits:

    def __init__(self, _ontologies_client: OntologiesClient, _ontology_edits: "OntologyEdits", _ontology_rid: str):
        self._ontologies_client = _ontologies_client
        self._ontology_edits = _ontology_edits
        self._ontology_rid = _ontology_rid

    @property
    def GripReading(self) -> GripReadingEditsFactory:
        from physical_ai_qa_cell_sdk import FoundryClient

        foundry_client = FoundryClient._init_from_ontologies_client(self._ontologies_client, self._ontology_rid)

        return GripReadingEditsFactory(
            ontology_edits=self._ontology_edits,
            _ontologies_client=self._ontologies_client,
            _ontology_rid=self._ontology_rid,
            object_loader=foundry_client.ontology.objects.GripReading.get,
        )

    @property
    def InspectionEvent(self) -> InspectionEventEditsFactory:
        from physical_ai_qa_cell_sdk import FoundryClient

        foundry_client = FoundryClient._init_from_ontologies_client(self._ontologies_client, self._ontology_rid)

        return InspectionEventEditsFactory(
            ontology_edits=self._ontology_edits,
            _ontologies_client=self._ontologies_client,
            _ontology_rid=self._ontology_rid,
            object_loader=foundry_client.ontology.objects.InspectionEvent.get,
        )

    @property
    def ModelRegistry(self) -> ModelRegistryEditsFactory:
        from physical_ai_qa_cell_sdk import FoundryClient

        foundry_client = FoundryClient._init_from_ontologies_client(self._ontologies_client, self._ontology_rid)

        return ModelRegistryEditsFactory(
            ontology_edits=self._ontology_edits,
            _ontologies_client=self._ontologies_client,
            _ontology_rid=self._ontology_rid,
            object_loader=foundry_client.ontology.objects.ModelRegistry.get,
        )

    @property
    def OperatorCommand(self) -> OperatorCommandEditsFactory:
        from physical_ai_qa_cell_sdk import FoundryClient

        foundry_client = FoundryClient._init_from_ontologies_client(self._ontologies_client, self._ontology_rid)

        return OperatorCommandEditsFactory(
            ontology_edits=self._ontology_edits,
            _ontologies_client=self._ontologies_client,
            _ontology_rid=self._ontology_rid,
            object_loader=foundry_client.ontology.objects.OperatorCommand.get,
        )

    @property
    def Robot(self) -> RobotEditsFactory:
        from physical_ai_qa_cell_sdk import FoundryClient

        foundry_client = FoundryClient._init_from_ontologies_client(self._ontologies_client, self._ontology_rid)

        return RobotEditsFactory(
            ontology_edits=self._ontology_edits,
            _ontologies_client=self._ontologies_client,
            _ontology_rid=self._ontology_rid,
            object_loader=foundry_client.ontology.objects.Robot.get,
        )

    @property
    def Sensor(self) -> SensorEditsFactory:
        from physical_ai_qa_cell_sdk import FoundryClient

        foundry_client = FoundryClient._init_from_ontologies_client(self._ontologies_client, self._ontology_rid)

        return SensorEditsFactory(
            ontology_edits=self._ontology_edits,
            _ontologies_client=self._ontologies_client,
            _ontology_rid=self._ontology_rid,
            object_loader=foundry_client.ontology.objects.Sensor.get,
        )

    @property
    def VisionReading(self) -> VisionReadingEditsFactory:
        from physical_ai_qa_cell_sdk import FoundryClient

        foundry_client = FoundryClient._init_from_ontologies_client(self._ontologies_client, self._ontology_rid)

        return VisionReadingEditsFactory(
            ontology_edits=self._ontology_edits,
            _ontologies_client=self._ontologies_client,
            _ontology_rid=self._ontology_rid,
            object_loader=foundry_client.ontology.objects.VisionReading.get,
        )
