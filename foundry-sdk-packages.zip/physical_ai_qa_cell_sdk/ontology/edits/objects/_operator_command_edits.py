#  (c) Copyright 2023 Palantir Technologies Inc. All rights reserved.
import json
from datetime import datetime
from typing import TYPE_CHECKING, Any, Optional, Union

from foundry_sdk.v2.ontologies import OntologiesClient
from foundry_sdk_runtime import ObjectLocator
from foundry_sdk_runtime.serialization import serialize_json_for_ontology_edits
from foundry_sdk_runtime.types import sanitize_for_hashing
from physical_ai_qa_cell_sdk.ontology.edits.links.operator_command._target_robot import (
    OperatorCommandTargetRobotLinkEdits,
)

if TYPE_CHECKING:
    from foundry_sdk_runtime import OntologyEdits


class OperatorCommandEdits:
    """
    Used to track OperatorCommand ontology object edits.

    # Code Samples

    ## Create a new object
    ```
    from foundry_sdk_runtime import OntologyEdits
    from ontology_sdk import FoundryClient

    @function(edit=OperatorCommand)
    def create_new_operator_command() -> OntologyEdits:

        # You can create new objects using the MyObjectType.create() method on the Ontology edits container.
        # When creating a new object, you must specify a value for its primary key.
        edits = FoundryClient().ontology.edits()
        new_operator_command = edits.objects.OperatorCommand.create(command_id)

        # Must return the edits so that they can be applied
        return edits.get_edits()
    ```

    ## Edit an existing object
    ```
    from foundry_sdk_runtime import OntologyEdits
    from ontology_sdk import FoundryClient

    @function(edit=OperatorCommand)
    def change_name_operator_command(obj: OperatorCommand, new_name: str) -> OntologyEdits:
        edits = FoundryClient().ontology.edits()

        # Obtain an editable view of that object
        editable_operator_command = edits.objects.OperatorCommand.edit(obj)

        editable_operator_command.name = new_name

        # Must return the edits so that they can be applied
        return edits.get_edits()

    ```

    ## Delete an existing object
    ```
    from foundry_sdk_runtime import OntologyEdits
    from ontology_sdk import FoundryClient

    @function(edit=OperatorCommand)
    def delete_operator_command(obj: OperatorCommand) -> OntologyEdits:
        edits = FoundryClient().ontology.edits()

        # You can delete an object by calling the MyObjectType.delete() method on the Ontology edits container.
        edits.objects.OperatorCommand.delete(obj)

        # Must return the edits so that they can be applied
        return edits.get_edits()
    ```
    """

    def __init__(
        self,
        ontology_edits: "OntologyEdits",
        _ontologies_client: OntologiesClient,
        _ontology_rid: str,
        created_at: Optional[Union[datetime, int]] = None,
        command_type: Optional[str] = None,
        executed_at: Optional[Union[datetime, int]] = None,
        payload: Optional[str] = None,
        robot_id: Optional[str] = None,
        command_id: Optional[str] = None,
        status: Optional[str] = None,
    ) -> None:
        object.__setattr__(self, "_initialized", False)
        object.__setattr__(self, "_ontology_edits", ontology_edits)
        object.__setattr__(self, "_ontologies_client", _ontologies_client)
        object.__setattr__(self, "_ontology_rid", _ontology_rid)
        object.__setattr__(self, "_created_at", created_at)
        object.__setattr__(self, "_command_type", command_type)
        object.__setattr__(self, "_executed_at", executed_at)
        object.__setattr__(self, "_payload", payload)
        object.__setattr__(self, "_robot_id", robot_id)
        object.__setattr__(self, "_command_id", command_id)
        object.__setattr__(self, "_status", status)
        object.__setattr__(self, "_initialized", True)

    @staticmethod
    def api_name() -> str:
        return "OperatorCommand"

    @staticmethod
    def primary_key() -> str:
        return "command_id"

    def get_primary_key(self) -> str:
        return self._command_id

    @property
    def created_at(self) -> Union[datetime, int]:
        return self._created_at

    @created_at.setter
    def created_at(self, value: Union[datetime, int]) -> None:
        """
        Handle datetime setting for UNIX timestamps.

        The timestamp should be an int in milliseconds. Most granular datetime unit in the ontology is milliseconds.
        Alternatively, you can provide a Python datetime object.
        """
        self._created_at = value
        self._modify_object_edit("createdAt", value)

    @property
    def command_type(self) -> str:
        return self._command_type

    @command_type.setter
    def command_type(self, value: str) -> None:
        self._command_type = value
        self._modify_object_edit("commandType", value)

    @property
    def executed_at(self) -> Union[datetime, int]:
        return self._executed_at

    @executed_at.setter
    def executed_at(self, value: Union[datetime, int]) -> None:
        """
        Handle datetime setting for UNIX timestamps.

        The timestamp should be an int in milliseconds. Most granular datetime unit in the ontology is milliseconds.
        Alternatively, you can provide a Python datetime object.
        """
        self._executed_at = value
        self._modify_object_edit("executedAt", value)

    @property
    def payload(self) -> str:
        return self._payload

    @payload.setter
    def payload(self, value: str) -> None:
        self._payload = value
        self._modify_object_edit("payload", value)

    @property
    def robot_id(self) -> str:
        return self._robot_id

    @robot_id.setter
    def robot_id(self, value: str) -> None:
        self._robot_id = value
        self._modify_object_edit("robotId", value)

    @property
    def command_id(self) -> str:
        return self._command_id

    @command_id.setter
    def command_id(self, value: str) -> None:
        self._command_id = value
        self._modify_object_edit("commandId", value)

    @property
    def status(self) -> str:
        return self._status

    @status.setter
    def status(self, value: str) -> None:
        self._status = value
        self._modify_object_edit("status", value)

    def __eq__(self, other: Any) -> bool:
        return self is other or (
            type(self) == type(other)
            and (self.created_at == other.created_at)
            and (self.command_type == other.command_type)
            and (self.executed_at == other.executed_at)
            and (self.payload == other.payload)
            and (self.robot_id == other.robot_id)
            and (self.command_id == other.command_id)
            and (self.status == other.status)
        )

    def __hash__(self) -> int:
        return hash(
            (
                type(self),
                sanitize_for_hashing(self.created_at),
                sanitize_for_hashing(self.command_type),
                sanitize_for_hashing(self.executed_at),
                sanitize_for_hashing(self.payload),
                sanitize_for_hashing(self.robot_id),
                sanitize_for_hashing(self.command_id),
                sanitize_for_hashing(self.status),
            )
        )

    def __setattr__(self, name, value):
        if self._initialized and not hasattr(self, name):
            raise AttributeError(f"'OperatorCommandEdits' object has no attribute '{name}'")
        object.__setattr__(self, name, value)

    def __repr__(self) -> str:
        return (
            f"OperatorCommandEdits("
            f"created_at={self.created_at}, "
            f"command_type={self.command_type}, "
            f"executed_at={self.executed_at}, "
            f"payload={self.payload}, "
            f"robot_id={self.robot_id}, "
            f"command_id={self.command_id}, "
            f"status={self.status}, "
            ")"
        )

    def _modify_object_edit(self, name, value) -> None:
        if name == self.primary_key():
            raise AttributeError("Cannot modify the primary key of an ObjectEdit")
        object_locator = ObjectLocator(object_api_name="OperatorCommand", primary_key=self.get_primary_key())
        fields = {
            name: value,
        }
        self._ontology_edits.modify(locator=object_locator, fields=serialize_json_for_ontology_edits(fields))

    def _modify_object_struct_edit(self, name, value, struct_class_type, is_list) -> None:
        """
        Converts struct field API names to struct field RIDs and sets as JSON string.

        None / null values are required to be removed from the mapping to be set to null.
        """
        if name == self.primary_key():
            raise AttributeError("Cannot modify the primary key of an ObjectEdit")
        object_locator = ObjectLocator(object_api_name="OperatorCommand", primary_key=self.get_primary_key())
        fields = serialize_json_for_ontology_edits(
            {
                name: value,
            }
        )
        serialized_fields = {}
        for property_key, struct_values in fields.items():
            if is_list:
                serialized_list_structs = []
                for struct_value in struct_values:
                    serialized_list_structs.append(
                        json.dumps(
                            {
                                struct_class_type._api_name_to_property_rid()[k]: v
                                for k, v in struct_value.items()
                                if v is not None
                            }
                        )
                    )
                serialized_fields[property_key] = serialized_list_structs
            else:
                serialized_fields[property_key] = json.dumps(
                    {
                        struct_class_type._api_name_to_property_rid()[k]: v
                        for k, v in struct_values.items()
                        if v is not None
                    }
                )
        self._ontology_edits.modify(locator=object_locator, fields=serialized_fields)

    @property
    def target_robot(self) -> OperatorCommandTargetRobotLinkEdits:
        return OperatorCommandTargetRobotLinkEdits(
            ontology_edits=self._ontology_edits,
            _ontologies_client=self._ontologies_client,
            _ontology_rid=self._ontology_rid,
            command_id=self.command_id,
        )
