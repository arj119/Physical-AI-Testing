#  (c) Copyright 2023 Palantir Technologies Inc. All rights reserved.
import json
from datetime import datetime
from typing import TYPE_CHECKING, Any, Optional, Union

from foundry_sdk.v2.core.models import MediaReference
from foundry_sdk.v2.ontologies import OntologiesClient
from foundry_sdk_runtime import ObjectLocator
from foundry_sdk_runtime.decorators import beta
from foundry_sdk_runtime.media import Media
from foundry_sdk_runtime.serialization import serialize_json_for_ontology_edits
from foundry_sdk_runtime.types import sanitize_for_hashing

if TYPE_CHECKING:
    from foundry_sdk_runtime import OntologyEdits


class ModelRegistryEdits:
    """
    Used to track ModelRegistry ontology object edits.

    # Code Samples

    ## Create a new object
    ```
    from foundry_sdk_runtime import OntologyEdits
    from ontology_sdk import FoundryClient

    @function(edit=ModelRegistry)
    def create_new_model_registry() -> OntologyEdits:

        # You can create new objects using the MyObjectType.create() method on the Ontology edits container.
        # When creating a new object, you must specify a value for its primary key.
        edits = FoundryClient().ontology.edits()
        new_model_registry = edits.objects.ModelRegistry.create(model_id)

        # Must return the edits so that they can be applied
        return edits.get_edits()
    ```

    ## Edit an existing object
    ```
    from foundry_sdk_runtime import OntologyEdits
    from ontology_sdk import FoundryClient

    @function(edit=ModelRegistry)
    def change_name_model_registry(obj: ModelRegistry, new_name: str) -> OntologyEdits:
        edits = FoundryClient().ontology.edits()

        # Obtain an editable view of that object
        editable_model_registry = edits.objects.ModelRegistry.edit(obj)

        editable_model_registry.name = new_name

        # Must return the edits so that they can be applied
        return edits.get_edits()

    ```

    ## Delete an existing object
    ```
    from foundry_sdk_runtime import OntologyEdits
    from ontology_sdk import FoundryClient

    @function(edit=ModelRegistry)
    def delete_model_registry(obj: ModelRegistry) -> OntologyEdits:
        edits = FoundryClient().ontology.edits()

        # You can delete an object by calling the MyObjectType.delete() method on the Ontology edits container.
        edits.objects.ModelRegistry.delete(obj)

        # Must return the edits so that they can be applied
        return edits.get_edits()
    ```
    """

    def __init__(
        self,
        ontology_edits: "OntologyEdits",
        _ontologies_client: OntologiesClient,
        _ontology_rid: str,
        published_at: Optional[Union[datetime, int]] = None,
        model_id: Optional[str] = None,
        accuracy: Optional[float] = None,
        description: Optional[str] = None,
        artifact_path: Optional[str] = None,
        version: Optional[str] = None,
        status: Optional[str] = None,
        model_artifact_ref: Optional[Union[Media, MediaReference]] = None,
    ) -> None:
        object.__setattr__(self, "_initialized", False)
        object.__setattr__(self, "_ontology_edits", ontology_edits)
        object.__setattr__(self, "_ontologies_client", _ontologies_client)
        object.__setattr__(self, "_ontology_rid", _ontology_rid)
        object.__setattr__(self, "_published_at", published_at)
        object.__setattr__(self, "_model_id", model_id)
        object.__setattr__(self, "_accuracy", accuracy)
        object.__setattr__(self, "_description", description)
        object.__setattr__(self, "_artifact_path", artifact_path)
        object.__setattr__(self, "_version", version)
        object.__setattr__(self, "_status", status)
        object.__setattr__(self, "_model_artifact_ref", model_artifact_ref)
        object.__setattr__(self, "_initialized", True)

    @staticmethod
    def api_name() -> str:
        return "ModelRegistry"

    @staticmethod
    def primary_key() -> str:
        return "model_id"

    def get_primary_key(self) -> str:
        return self._model_id

    @property
    def published_at(self) -> Union[datetime, int]:
        return self._published_at

    @published_at.setter
    def published_at(self, value: Union[datetime, int]) -> None:
        """
        Handle datetime setting for UNIX timestamps.

        The timestamp should be an int in milliseconds. Most granular datetime unit in the ontology is milliseconds.
        Alternatively, you can provide a Python datetime object.
        """
        self._published_at = value
        self._modify_object_edit("publishedAt", value)

    @property
    def model_id(self) -> str:
        return self._model_id

    @model_id.setter
    def model_id(self, value: str) -> None:
        self._model_id = value
        self._modify_object_edit("modelId", value)

    @property
    def accuracy(self) -> float:
        return self._accuracy

    @accuracy.setter
    def accuracy(self, value: float) -> None:
        self._accuracy = value
        self._modify_object_edit("accuracy", value)

    @property
    def description(self) -> str:
        return self._description

    @description.setter
    def description(self, value: str) -> None:
        self._description = value
        self._modify_object_edit("description", value)

    @property
    def artifact_path(self) -> str:
        return self._artifact_path

    @artifact_path.setter
    def artifact_path(self, value: str) -> None:
        self._artifact_path = value
        self._modify_object_edit("artifactPath", value)

    @property
    def version(self) -> str:
        return self._version

    @version.setter
    def version(self, value: str) -> None:
        self._version = value
        self._modify_object_edit("version", value)

    @property
    def status(self) -> str:
        return self._status

    @status.setter
    def status(self, value: str) -> None:
        self._status = value
        self._modify_object_edit("status", value)

    @beta("Properties of type Media are in beta and may change in future versions.")
    @property
    def model_artifact_ref(self) -> Union[Media, MediaReference]:
        return self._model_artifact_ref

    @beta("Properties of type Media are in beta and may change in future versions.")
    @model_artifact_ref.setter
    def model_artifact_ref(self, value: Union[Media, MediaReference]) -> None:
        self._model_artifact_ref = value
        self._modify_object_edit("modelArtifactRef", value)

    def __eq__(self, other: Any) -> bool:
        return self is other or (
            type(self) == type(other)
            and (self.published_at == other.published_at)
            and (self.model_id == other.model_id)
            and (self.accuracy == other.accuracy)
            and (self.description == other.description)
            and (self.artifact_path == other.artifact_path)
            and (self.version == other.version)
            and (self.status == other.status)
            and (self.model_artifact_ref == other.model_artifact_ref)
        )

    def __hash__(self) -> int:
        return hash(
            (
                type(self),
                sanitize_for_hashing(self.published_at),
                sanitize_for_hashing(self.model_id),
                sanitize_for_hashing(self.accuracy),
                sanitize_for_hashing(self.description),
                sanitize_for_hashing(self.artifact_path),
                sanitize_for_hashing(self.version),
                sanitize_for_hashing(self.status),
                sanitize_for_hashing(self.model_artifact_ref),
            )
        )

    def __setattr__(self, name, value):
        if self._initialized and not hasattr(self, name):
            raise AttributeError(f"'ModelRegistryEdits' object has no attribute '{name}'")
        object.__setattr__(self, name, value)

    def __repr__(self) -> str:
        return (
            f"ModelRegistryEdits("
            f"published_at={self.published_at}, "
            f"model_id={self.model_id}, "
            f"accuracy={self.accuracy}, "
            f"description={self.description}, "
            f"artifact_path={self.artifact_path}, "
            f"version={self.version}, "
            f"status={self.status}, "
            f"model_artifact_ref={self.model_artifact_ref}, "
            ")"
        )

    def _modify_object_edit(self, name, value) -> None:
        if name == self.primary_key():
            raise AttributeError("Cannot modify the primary key of an ObjectEdit")
        object_locator = ObjectLocator(object_api_name="ModelRegistry", primary_key=self.get_primary_key())
        fields = {
            name: value,
        }
        self._ontology_edits.modify(locator=object_locator, fields=serialize_json_for_ontology_edits(fields))

    def _modify_object_struct_edit(self, name, value, struct_class_type, is_list) -> None:
        """
        Converts struct field API names to struct field RIDs and sets as JSON string.

        None / null values are required to be removed from the mapping to be set to null.
        """
        if name == self.primary_key():
            raise AttributeError("Cannot modify the primary key of an ObjectEdit")
        object_locator = ObjectLocator(object_api_name="ModelRegistry", primary_key=self.get_primary_key())
        fields = serialize_json_for_ontology_edits(
            {
                name: value,
            }
        )
        serialized_fields = {}
        for property_key, struct_values in fields.items():
            if is_list:
                serialized_list_structs = []
                for struct_value in struct_values:
                    serialized_list_structs.append(
                        json.dumps(
                            {
                                struct_class_type._api_name_to_property_rid()[k]: v
                                for k, v in struct_value.items()
                                if v is not None
                            }
                        )
                    )
                serialized_fields[property_key] = serialized_list_structs
            else:
                serialized_fields[property_key] = json.dumps(
                    {
                        struct_class_type._api_name_to_property_rid()[k]: v
                        for k, v in struct_values.items()
                        if v is not None
                    }
                )
        self._ontology_edits.modify(locator=object_locator, fields=serialized_fields)
