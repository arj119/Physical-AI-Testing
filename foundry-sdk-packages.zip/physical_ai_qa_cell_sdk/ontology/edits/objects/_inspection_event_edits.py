#  (c) Copyright 2023 Palantir Technologies Inc. All rights reserved.
import json
from datetime import datetime
from typing import TYPE_CHECKING, Any, Optional, Union

from foundry_sdk.v2.core.models import MediaReference
from foundry_sdk.v2.ontologies import OntologiesClient
from foundry_sdk_runtime import ObjectLocator
from foundry_sdk_runtime.decorators import beta
from foundry_sdk_runtime.media import Media
from foundry_sdk_runtime.serialization import serialize_json_for_ontology_edits
from foundry_sdk_runtime.types import sanitize_for_hashing
from physical_ai_qa_cell_sdk.ontology.edits.links.inspection_event._grip_readings import (
    InspectionEventGripReadingsLinkEdits,
)
from physical_ai_qa_cell_sdk.ontology.edits.links.inspection_event._inspection_vision_readings import (
    InspectionEventInspectionVisionReadingsLinkEdits,
)
from physical_ai_qa_cell_sdk.ontology.edits.links.inspection_event._robot import InspectionEventRobotLinkEdits

if TYPE_CHECKING:
    from foundry_sdk_runtime import OntologyEdits


class InspectionEventEdits:
    """
    Used to track InspectionEvent ontology object edits.

    # Code Samples

    ## Create a new object
    ```
    from foundry_sdk_runtime import OntologyEdits
    from ontology_sdk import FoundryClient

    @function(edit=InspectionEvent)
    def create_new_inspection_event() -> OntologyEdits:

        # You can create new objects using the MyObjectType.create() method on the Ontology edits container.
        # When creating a new object, you must specify a value for its primary key.
        edits = FoundryClient().ontology.edits()
        new_inspection_event = edits.objects.InspectionEvent.create(inspection_id)

        # Must return the edits so that they can be applied
        return edits.get_edits()
    ```

    ## Edit an existing object
    ```
    from foundry_sdk_runtime import OntologyEdits
    from ontology_sdk import FoundryClient

    @function(edit=InspectionEvent)
    def change_name_inspection_event(obj: InspectionEvent, new_name: str) -> OntologyEdits:
        edits = FoundryClient().ontology.edits()

        # Obtain an editable view of that object
        editable_inspection_event = edits.objects.InspectionEvent.edit(obj)

        editable_inspection_event.name = new_name

        # Must return the edits so that they can be applied
        return edits.get_edits()

    ```

    ## Delete an existing object
    ```
    from foundry_sdk_runtime import OntologyEdits
    from ontology_sdk import FoundryClient

    @function(edit=InspectionEvent)
    def delete_inspection_event(obj: InspectionEvent) -> OntologyEdits:
        edits = FoundryClient().ontology.edits()

        # You can delete an object by calling the MyObjectType.delete() method on the Ontology edits container.
        edits.objects.InspectionEvent.delete(obj)

        # Must return the edits so that they can be applied
        return edits.get_edits()
    ```
    """

    def __init__(
        self,
        ontology_edits: "OntologyEdits",
        _ontologies_client: OntologiesClient,
        _ontology_rid: str,
        grip_load: Optional[float] = None,
        model_version: Optional[str] = None,
        reviewed_at: Optional[Union[datetime, int]] = None,
        final_decision: Optional[str] = None,
        reviewed_by: Optional[str] = None,
        robot_id: Optional[str] = None,
        fusion_decision: Optional[str] = None,
        inspection_id: Optional[str] = None,
        vision_agrees: Optional[bool] = None,
        operator_notes: Optional[str] = None,
        vision_confidence: Optional[float] = None,
        review_status: Optional[str] = None,
        cycle_time_ms: Optional[int] = None,
        vision_class: Optional[str] = None,
        fusion_reason: Optional[str] = None,
        timestamp: Optional[Union[datetime, int]] = None,
        captured_image_ref: Optional[Union[Media, MediaReference]] = None,
    ) -> None:
        object.__setattr__(self, "_initialized", False)
        object.__setattr__(self, "_ontology_edits", ontology_edits)
        object.__setattr__(self, "_ontologies_client", _ontologies_client)
        object.__setattr__(self, "_ontology_rid", _ontology_rid)
        object.__setattr__(self, "_grip_load", grip_load)
        object.__setattr__(self, "_model_version", model_version)
        object.__setattr__(self, "_reviewed_at", reviewed_at)
        object.__setattr__(self, "_final_decision", final_decision)
        object.__setattr__(self, "_reviewed_by", reviewed_by)
        object.__setattr__(self, "_robot_id", robot_id)
        object.__setattr__(self, "_fusion_decision", fusion_decision)
        object.__setattr__(self, "_inspection_id", inspection_id)
        object.__setattr__(self, "_vision_agrees", vision_agrees)
        object.__setattr__(self, "_operator_notes", operator_notes)
        object.__setattr__(self, "_vision_confidence", vision_confidence)
        object.__setattr__(self, "_review_status", review_status)
        object.__setattr__(self, "_cycle_time_ms", cycle_time_ms)
        object.__setattr__(self, "_vision_class", vision_class)
        object.__setattr__(self, "_fusion_reason", fusion_reason)
        object.__setattr__(self, "_timestamp", timestamp)
        object.__setattr__(self, "_captured_image_ref", captured_image_ref)
        object.__setattr__(self, "_initialized", True)

    @staticmethod
    def api_name() -> str:
        return "InspectionEvent"

    @staticmethod
    def primary_key() -> str:
        return "inspection_id"

    def get_primary_key(self) -> str:
        return self._inspection_id

    @property
    def grip_load(self) -> float:
        return self._grip_load

    @grip_load.setter
    def grip_load(self, value: float) -> None:
        self._grip_load = value
        self._modify_object_edit("gripLoad", value)

    @property
    def model_version(self) -> str:
        return self._model_version

    @model_version.setter
    def model_version(self, value: str) -> None:
        self._model_version = value
        self._modify_object_edit("modelVersion", value)

    @property
    def reviewed_at(self) -> Union[datetime, int]:
        return self._reviewed_at

    @reviewed_at.setter
    def reviewed_at(self, value: Union[datetime, int]) -> None:
        """
        Handle datetime setting for UNIX timestamps.

        The timestamp should be an int in milliseconds. Most granular datetime unit in the ontology is milliseconds.
        Alternatively, you can provide a Python datetime object.
        """
        self._reviewed_at = value
        self._modify_object_edit("reviewedAt", value)

    @property
    def final_decision(self) -> str:
        return self._final_decision

    @final_decision.setter
    def final_decision(self, value: str) -> None:
        self._final_decision = value
        self._modify_object_edit("finalDecision", value)

    @property
    def reviewed_by(self) -> str:
        return self._reviewed_by

    @reviewed_by.setter
    def reviewed_by(self, value: str) -> None:
        self._reviewed_by = value
        self._modify_object_edit("reviewedBy", value)

    @property
    def robot_id(self) -> str:
        return self._robot_id

    @robot_id.setter
    def robot_id(self, value: str) -> None:
        self._robot_id = value
        self._modify_object_edit("robotId", value)

    @property
    def fusion_decision(self) -> str:
        return self._fusion_decision

    @fusion_decision.setter
    def fusion_decision(self, value: str) -> None:
        self._fusion_decision = value
        self._modify_object_edit("fusionDecision", value)

    @property
    def inspection_id(self) -> str:
        return self._inspection_id

    @inspection_id.setter
    def inspection_id(self, value: str) -> None:
        self._inspection_id = value
        self._modify_object_edit("inspectionId", value)

    @property
    def vision_agrees(self) -> bool:
        return self._vision_agrees

    @vision_agrees.setter
    def vision_agrees(self, value: bool) -> None:
        self._vision_agrees = value
        self._modify_object_edit("visionAgrees", value)

    @property
    def operator_notes(self) -> str:
        return self._operator_notes

    @operator_notes.setter
    def operator_notes(self, value: str) -> None:
        self._operator_notes = value
        self._modify_object_edit("operatorNotes", value)

    @property
    def vision_confidence(self) -> float:
        return self._vision_confidence

    @vision_confidence.setter
    def vision_confidence(self, value: float) -> None:
        self._vision_confidence = value
        self._modify_object_edit("visionConfidence", value)

    @property
    def review_status(self) -> str:
        return self._review_status

    @review_status.setter
    def review_status(self, value: str) -> None:
        self._review_status = value
        self._modify_object_edit("reviewStatus", value)

    @property
    def cycle_time_ms(self) -> int:
        return self._cycle_time_ms

    @cycle_time_ms.setter
    def cycle_time_ms(self, value: int) -> None:
        self._cycle_time_ms = value
        self._modify_object_edit("cycleTimeMs", value)

    @property
    def vision_class(self) -> str:
        return self._vision_class

    @vision_class.setter
    def vision_class(self, value: str) -> None:
        self._vision_class = value
        self._modify_object_edit("visionClass", value)

    @property
    def fusion_reason(self) -> str:
        return self._fusion_reason

    @fusion_reason.setter
    def fusion_reason(self, value: str) -> None:
        self._fusion_reason = value
        self._modify_object_edit("fusionReason", value)

    @property
    def timestamp(self) -> Union[datetime, int]:
        return self._timestamp

    @timestamp.setter
    def timestamp(self, value: Union[datetime, int]) -> None:
        """
        Handle datetime setting for UNIX timestamps.

        The timestamp should be an int in milliseconds. Most granular datetime unit in the ontology is milliseconds.
        Alternatively, you can provide a Python datetime object.
        """
        self._timestamp = value
        self._modify_object_edit("timestamp", value)

    @beta("Properties of type Media are in beta and may change in future versions.")
    @property
    def captured_image_ref(self) -> Union[Media, MediaReference]:
        return self._captured_image_ref

    @beta("Properties of type Media are in beta and may change in future versions.")
    @captured_image_ref.setter
    def captured_image_ref(self, value: Union[Media, MediaReference]) -> None:
        self._captured_image_ref = value
        self._modify_object_edit("capturedImageRef", value)

    def __eq__(self, other: Any) -> bool:
        return self is other or (
            type(self) == type(other)
            and (self.grip_load == other.grip_load)
            and (self.model_version == other.model_version)
            and (self.reviewed_at == other.reviewed_at)
            and (self.final_decision == other.final_decision)
            and (self.reviewed_by == other.reviewed_by)
            and (self.robot_id == other.robot_id)
            and (self.fusion_decision == other.fusion_decision)
            and (self.inspection_id == other.inspection_id)
            and (self.vision_agrees == other.vision_agrees)
            and (self.operator_notes == other.operator_notes)
            and (self.vision_confidence == other.vision_confidence)
            and (self.review_status == other.review_status)
            and (self.cycle_time_ms == other.cycle_time_ms)
            and (self.vision_class == other.vision_class)
            and (self.fusion_reason == other.fusion_reason)
            and (self.timestamp == other.timestamp)
            and (self.captured_image_ref == other.captured_image_ref)
        )

    def __hash__(self) -> int:
        return hash(
            (
                type(self),
                sanitize_for_hashing(self.grip_load),
                sanitize_for_hashing(self.model_version),
                sanitize_for_hashing(self.reviewed_at),
                sanitize_for_hashing(self.final_decision),
                sanitize_for_hashing(self.reviewed_by),
                sanitize_for_hashing(self.robot_id),
                sanitize_for_hashing(self.fusion_decision),
                sanitize_for_hashing(self.inspection_id),
                sanitize_for_hashing(self.vision_agrees),
                sanitize_for_hashing(self.operator_notes),
                sanitize_for_hashing(self.vision_confidence),
                sanitize_for_hashing(self.review_status),
                sanitize_for_hashing(self.cycle_time_ms),
                sanitize_for_hashing(self.vision_class),
                sanitize_for_hashing(self.fusion_reason),
                sanitize_for_hashing(self.timestamp),
                sanitize_for_hashing(self.captured_image_ref),
            )
        )

    def __setattr__(self, name, value):
        if self._initialized and not hasattr(self, name):
            raise AttributeError(f"'InspectionEventEdits' object has no attribute '{name}'")
        object.__setattr__(self, name, value)

    def __repr__(self) -> str:
        return (
            f"InspectionEventEdits("
            f"grip_load={self.grip_load}, "
            f"model_version={self.model_version}, "
            f"reviewed_at={self.reviewed_at}, "
            f"final_decision={self.final_decision}, "
            f"reviewed_by={self.reviewed_by}, "
            f"robot_id={self.robot_id}, "
            f"fusion_decision={self.fusion_decision}, "
            f"inspection_id={self.inspection_id}, "
            f"vision_agrees={self.vision_agrees}, "
            f"operator_notes={self.operator_notes}, "
            f"vision_confidence={self.vision_confidence}, "
            f"review_status={self.review_status}, "
            f"cycle_time_ms={self.cycle_time_ms}, "
            f"vision_class={self.vision_class}, "
            f"fusion_reason={self.fusion_reason}, "
            f"timestamp={self.timestamp}, "
            f"captured_image_ref={self.captured_image_ref}, "
            ")"
        )

    def _modify_object_edit(self, name, value) -> None:
        if name == self.primary_key():
            raise AttributeError("Cannot modify the primary key of an ObjectEdit")
        object_locator = ObjectLocator(object_api_name="InspectionEvent", primary_key=self.get_primary_key())
        fields = {
            name: value,
        }
        self._ontology_edits.modify(locator=object_locator, fields=serialize_json_for_ontology_edits(fields))

    def _modify_object_struct_edit(self, name, value, struct_class_type, is_list) -> None:
        """
        Converts struct field API names to struct field RIDs and sets as JSON string.

        None / null values are required to be removed from the mapping to be set to null.
        """
        if name == self.primary_key():
            raise AttributeError("Cannot modify the primary key of an ObjectEdit")
        object_locator = ObjectLocator(object_api_name="InspectionEvent", primary_key=self.get_primary_key())
        fields = serialize_json_for_ontology_edits(
            {
                name: value,
            }
        )
        serialized_fields = {}
        for property_key, struct_values in fields.items():
            if is_list:
                serialized_list_structs = []
                for struct_value in struct_values:
                    serialized_list_structs.append(
                        json.dumps(
                            {
                                struct_class_type._api_name_to_property_rid()[k]: v
                                for k, v in struct_value.items()
                                if v is not None
                            }
                        )
                    )
                serialized_fields[property_key] = serialized_list_structs
            else:
                serialized_fields[property_key] = json.dumps(
                    {
                        struct_class_type._api_name_to_property_rid()[k]: v
                        for k, v in struct_values.items()
                        if v is not None
                    }
                )
        self._ontology_edits.modify(locator=object_locator, fields=serialized_fields)

    @property
    def grip_readings(self) -> InspectionEventGripReadingsLinkEdits:
        return InspectionEventGripReadingsLinkEdits(
            ontology_edits=self._ontology_edits,
            _ontologies_client=self._ontologies_client,
            _ontology_rid=self._ontology_rid,
            inspection_id=self.inspection_id,
        )

    @property
    def inspection_vision_readings(self) -> InspectionEventInspectionVisionReadingsLinkEdits:
        return InspectionEventInspectionVisionReadingsLinkEdits(
            ontology_edits=self._ontology_edits,
            _ontologies_client=self._ontologies_client,
            _ontology_rid=self._ontology_rid,
            inspection_id=self.inspection_id,
        )

    @property
    def robot(self) -> InspectionEventRobotLinkEdits:
        return InspectionEventRobotLinkEdits(
            ontology_edits=self._ontology_edits,
            _ontologies_client=self._ontologies_client,
            _ontology_rid=self._ontology_rid,
            inspection_id=self.inspection_id,
        )
