#  (c) Copyright 2023 Palantir Technologies Inc. All rights reserved.
import json
from typing import TYPE_CHECKING, Any, Optional

from foundry_sdk.v2.ontologies import OntologiesClient
from foundry_sdk_runtime import ObjectLocator
from foundry_sdk_runtime.serialization import serialize_json_for_ontology_edits
from foundry_sdk_runtime.timeseries import Timeseries
from foundry_sdk_runtime.types import sanitize_for_hashing
from physical_ai_qa_cell_sdk.ontology.edits.links.sensor._robot import SensorRobotLinkEdits

if TYPE_CHECKING:
    from foundry_sdk_runtime import OntologyEdits


class SensorEdits:
    """
    Used to track Sensor ontology object edits.

    # Code Samples

    ## Create a new object
    ```
    from foundry_sdk_runtime import OntologyEdits
    from ontology_sdk import FoundryClient

    @function(edit=Sensor)
    def create_new_sensor() -> OntologyEdits:

        # You can create new objects using the MyObjectType.create() method on the Ontology edits container.
        # When creating a new object, you must specify a value for its primary key.
        edits = FoundryClient().ontology.edits()
        new_sensor = edits.objects.Sensor.create(sensor_id)

        # Must return the edits so that they can be applied
        return edits.get_edits()
    ```

    ## Edit an existing object
    ```
    from foundry_sdk_runtime import OntologyEdits
    from ontology_sdk import FoundryClient

    @function(edit=Sensor)
    def change_name_sensor(obj: Sensor, new_name: str) -> OntologyEdits:
        edits = FoundryClient().ontology.edits()

        # Obtain an editable view of that object
        editable_sensor = edits.objects.Sensor.edit(obj)

        editable_sensor.name = new_name

        # Must return the edits so that they can be applied
        return edits.get_edits()

    ```

    ## Delete an existing object
    ```
    from foundry_sdk_runtime import OntologyEdits
    from ontology_sdk import FoundryClient

    @function(edit=Sensor)
    def delete_sensor(obj: Sensor) -> OntologyEdits:
        edits = FoundryClient().ontology.edits()

        # You can delete an object by calling the MyObjectType.delete() method on the Ontology edits container.
        edits.objects.Sensor.delete(obj)

        # Must return the edits so that they can be applied
        return edits.get_edits()
    ```
    """

    def __init__(
        self,
        ontology_edits: "OntologyEdits",
        _ontologies_client: OntologiesClient,
        _ontology_rid: str,
        is_categorical: Optional[bool] = None,
        internal_interpolation: Optional[str] = None,
        sensor_name1: Optional[str] = None,
        sensor_type: Optional[str] = None,
        location: Optional[str] = None,
        units: Optional[str] = None,
        robot_id: Optional[str] = None,
        sensor_type_id: Optional[str] = None,
        sensor_id: Optional[str] = None,
        status: Optional[str] = None,
        series_id: Optional[Timeseries[float]] = None,
    ) -> None:
        object.__setattr__(self, "_initialized", False)
        object.__setattr__(self, "_ontology_edits", ontology_edits)
        object.__setattr__(self, "_ontologies_client", _ontologies_client)
        object.__setattr__(self, "_ontology_rid", _ontology_rid)
        object.__setattr__(self, "_is_categorical", is_categorical)
        object.__setattr__(self, "_internal_interpolation", internal_interpolation)
        object.__setattr__(self, "_sensor_name1", sensor_name1)
        object.__setattr__(self, "_sensor_type", sensor_type)
        object.__setattr__(self, "_location", location)
        object.__setattr__(self, "_units", units)
        object.__setattr__(self, "_robot_id", robot_id)
        object.__setattr__(self, "_sensor_type_id", sensor_type_id)
        object.__setattr__(self, "_sensor_id", sensor_id)
        object.__setattr__(self, "_status", status)
        object.__setattr__(self, "_series_id", series_id)
        object.__setattr__(self, "_initialized", True)

    @staticmethod
    def api_name() -> str:
        return "Sensor"

    @staticmethod
    def primary_key() -> str:
        return "sensor_id"

    def get_primary_key(self) -> str:
        return self._sensor_id

    @property
    def is_categorical(self) -> bool:
        return self._is_categorical

    @is_categorical.setter
    def is_categorical(self, value: bool) -> None:
        self._is_categorical = value
        self._modify_object_edit("isCategorical", value)

    @property
    def internal_interpolation(self) -> str:
        return self._internal_interpolation

    @internal_interpolation.setter
    def internal_interpolation(self, value: str) -> None:
        self._internal_interpolation = value
        self._modify_object_edit("internalInterpolation", value)

    @property
    def sensor_name1(self) -> str:
        return self._sensor_name1

    @sensor_name1.setter
    def sensor_name1(self, value: str) -> None:
        self._sensor_name1 = value
        self._modify_object_edit("sensorName1", value)

    @property
    def sensor_type(self) -> str:
        return self._sensor_type

    @sensor_type.setter
    def sensor_type(self, value: str) -> None:
        self._sensor_type = value
        self._modify_object_edit("sensorType", value)

    @property
    def location(self) -> str:
        return self._location

    @location.setter
    def location(self, value: str) -> None:
        self._location = value
        self._modify_object_edit("location", value)

    @property
    def units(self) -> str:
        return self._units

    @units.setter
    def units(self, value: str) -> None:
        self._units = value
        self._modify_object_edit("units", value)

    @property
    def robot_id(self) -> str:
        return self._robot_id

    @robot_id.setter
    def robot_id(self, value: str) -> None:
        self._robot_id = value
        self._modify_object_edit("robotId", value)

    @property
    def sensor_type_id(self) -> str:
        return self._sensor_type_id

    @sensor_type_id.setter
    def sensor_type_id(self, value: str) -> None:
        self._sensor_type_id = value
        self._modify_object_edit("sensorTypeId", value)

    @property
    def sensor_id(self) -> str:
        return self._sensor_id

    @sensor_id.setter
    def sensor_id(self, value: str) -> None:
        self._sensor_id = value
        self._modify_object_edit("sensorId", value)

    @property
    def status(self) -> str:
        return self._status

    @status.setter
    def status(self, value: str) -> None:
        self._status = value
        self._modify_object_edit("status", value)

    @property
    def series_id(self) -> Timeseries[float]:
        return self._series_id

    @series_id.setter
    def series_id(self, value: Timeseries[float]) -> None:
        self._series_id = value
        self._modify_object_edit("seriesId", value)

    def __eq__(self, other: Any) -> bool:
        return self is other or (
            type(self) == type(other)
            and (self.is_categorical == other.is_categorical)
            and (self.internal_interpolation == other.internal_interpolation)
            and (self.sensor_name1 == other.sensor_name1)
            and (self.sensor_type == other.sensor_type)
            and (self.location == other.location)
            and (self.units == other.units)
            and (self.robot_id == other.robot_id)
            and (self.sensor_type_id == other.sensor_type_id)
            and (self.sensor_id == other.sensor_id)
            and (self.status == other.status)
            and (self.series_id == other.series_id)
        )

    def __hash__(self) -> int:
        return hash(
            (
                type(self),
                sanitize_for_hashing(self.is_categorical),
                sanitize_for_hashing(self.internal_interpolation),
                sanitize_for_hashing(self.sensor_name1),
                sanitize_for_hashing(self.sensor_type),
                sanitize_for_hashing(self.location),
                sanitize_for_hashing(self.units),
                sanitize_for_hashing(self.robot_id),
                sanitize_for_hashing(self.sensor_type_id),
                sanitize_for_hashing(self.sensor_id),
                sanitize_for_hashing(self.status),
                sanitize_for_hashing(self.series_id),
            )
        )

    def __setattr__(self, name, value):
        if self._initialized and not hasattr(self, name):
            raise AttributeError(f"'SensorEdits' object has no attribute '{name}'")
        object.__setattr__(self, name, value)

    def __repr__(self) -> str:
        return (
            f"SensorEdits("
            f"is_categorical={self.is_categorical}, "
            f"internal_interpolation={self.internal_interpolation}, "
            f"sensor_name1={self.sensor_name1}, "
            f"sensor_type={self.sensor_type}, "
            f"location={self.location}, "
            f"units={self.units}, "
            f"robot_id={self.robot_id}, "
            f"sensor_type_id={self.sensor_type_id}, "
            f"sensor_id={self.sensor_id}, "
            f"status={self.status}, "
            f"series_id={self.series_id}, "
            ")"
        )

    def _modify_object_edit(self, name, value) -> None:
        if name == self.primary_key():
            raise AttributeError("Cannot modify the primary key of an ObjectEdit")
        object_locator = ObjectLocator(object_api_name="Sensor", primary_key=self.get_primary_key())
        fields = {
            name: value,
        }
        self._ontology_edits.modify(locator=object_locator, fields=serialize_json_for_ontology_edits(fields))

    def _modify_object_struct_edit(self, name, value, struct_class_type, is_list) -> None:
        """
        Converts struct field API names to struct field RIDs and sets as JSON string.

        None / null values are required to be removed from the mapping to be set to null.
        """
        if name == self.primary_key():
            raise AttributeError("Cannot modify the primary key of an ObjectEdit")
        object_locator = ObjectLocator(object_api_name="Sensor", primary_key=self.get_primary_key())
        fields = serialize_json_for_ontology_edits(
            {
                name: value,
            }
        )
        serialized_fields = {}
        for property_key, struct_values in fields.items():
            if is_list:
                serialized_list_structs = []
                for struct_value in struct_values:
                    serialized_list_structs.append(
                        json.dumps(
                            {
                                struct_class_type._api_name_to_property_rid()[k]: v
                                for k, v in struct_value.items()
                                if v is not None
                            }
                        )
                    )
                serialized_fields[property_key] = serialized_list_structs
            else:
                serialized_fields[property_key] = json.dumps(
                    {
                        struct_class_type._api_name_to_property_rid()[k]: v
                        for k, v in struct_values.items()
                        if v is not None
                    }
                )
        self._ontology_edits.modify(locator=object_locator, fields=serialized_fields)

    @property
    def robot(self) -> SensorRobotLinkEdits:
        return SensorRobotLinkEdits(
            ontology_edits=self._ontology_edits,
            _ontologies_client=self._ontologies_client,
            _ontology_rid=self._ontology_rid,
            sensor_id=self.sensor_id,
        )
