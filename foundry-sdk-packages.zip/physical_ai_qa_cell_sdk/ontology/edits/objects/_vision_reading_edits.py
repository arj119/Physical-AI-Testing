#  (c) Copyright 2023 Palantir Technologies Inc. All rights reserved.
import json
from datetime import datetime
from typing import TYPE_CHECKING, Any, Optional, Union

from foundry_sdk.v2.ontologies import OntologiesClient
from foundry_sdk_runtime import ObjectLocator
from foundry_sdk_runtime.serialization import serialize_json_for_ontology_edits
from foundry_sdk_runtime.types import sanitize_for_hashing
from physical_ai_qa_cell_sdk.ontology.edits.links.vision_reading._inspection_event import (
    VisionReadingInspectionEventLinkEdits,
)
from physical_ai_qa_cell_sdk.ontology.edits.links.vision_reading._robot import VisionReadingRobotLinkEdits

if TYPE_CHECKING:
    from foundry_sdk_runtime import OntologyEdits


class VisionReadingEdits:
    """
    Used to track VisionReading ontology object edits.

    # Code Samples

    ## Create a new object
    ```
    from foundry_sdk_runtime import OntologyEdits
    from ontology_sdk import FoundryClient

    @function(edit=VisionReading)
    def create_new_vision_reading() -> OntologyEdits:

        # You can create new objects using the MyObjectType.create() method on the Ontology edits container.
        # When creating a new object, you must specify a value for its primary key.
        edits = FoundryClient().ontology.edits()
        new_vision_reading = edits.objects.VisionReading.create(reading_id)

        # Must return the edits so that they can be applied
        return edits.get_edits()
    ```

    ## Edit an existing object
    ```
    from foundry_sdk_runtime import OntologyEdits
    from ontology_sdk import FoundryClient

    @function(edit=VisionReading)
    def change_name_vision_reading(obj: VisionReading, new_name: str) -> OntologyEdits:
        edits = FoundryClient().ontology.edits()

        # Obtain an editable view of that object
        editable_vision_reading = edits.objects.VisionReading.edit(obj)

        editable_vision_reading.name = new_name

        # Must return the edits so that they can be applied
        return edits.get_edits()

    ```

    ## Delete an existing object
    ```
    from foundry_sdk_runtime import OntologyEdits
    from ontology_sdk import FoundryClient

    @function(edit=VisionReading)
    def delete_vision_reading(obj: VisionReading) -> OntologyEdits:
        edits = FoundryClient().ontology.edits()

        # You can delete an object by calling the MyObjectType.delete() method on the Ontology edits container.
        edits.objects.VisionReading.delete(obj)

        # Must return the edits so that they can be applied
        return edits.get_edits()
    ```
    """

    def __init__(
        self,
        ontology_edits: "OntologyEdits",
        _ontologies_client: OntologiesClient,
        _ontology_rid: str,
        bounding_box: Optional[list[float]] = None,
        inspection_id: Optional[str] = None,
        inference_time_ms: Optional[int] = None,
        model_version: Optional[str] = None,
        thumbnail_base64: Optional[str] = None,
        confidence: Optional[float] = None,
        reading_id: Optional[str] = None,
        robot_id: Optional[str] = None,
        detected_class: Optional[str] = None,
        timestamp: Optional[Union[datetime, int]] = None,
    ) -> None:
        object.__setattr__(self, "_initialized", False)
        object.__setattr__(self, "_ontology_edits", ontology_edits)
        object.__setattr__(self, "_ontologies_client", _ontologies_client)
        object.__setattr__(self, "_ontology_rid", _ontology_rid)
        object.__setattr__(self, "_bounding_box", bounding_box)
        object.__setattr__(self, "_inspection_id", inspection_id)
        object.__setattr__(self, "_inference_time_ms", inference_time_ms)
        object.__setattr__(self, "_model_version", model_version)
        object.__setattr__(self, "_thumbnail_base64", thumbnail_base64)
        object.__setattr__(self, "_confidence", confidence)
        object.__setattr__(self, "_reading_id", reading_id)
        object.__setattr__(self, "_robot_id", robot_id)
        object.__setattr__(self, "_detected_class", detected_class)
        object.__setattr__(self, "_timestamp", timestamp)
        object.__setattr__(self, "_initialized", True)

    @staticmethod
    def api_name() -> str:
        return "VisionReading"

    @staticmethod
    def primary_key() -> str:
        return "reading_id"

    def get_primary_key(self) -> str:
        return self._reading_id

    @property
    def bounding_box(self) -> list[float]:
        return self._bounding_box

    @bounding_box.setter
    def bounding_box(self, value: list[float]) -> None:
        self._bounding_box = value
        self._modify_object_edit("boundingBox", value)

    @property
    def inspection_id(self) -> str:
        return self._inspection_id

    @inspection_id.setter
    def inspection_id(self, value: str) -> None:
        self._inspection_id = value
        self._modify_object_edit("inspectionId", value)

    @property
    def inference_time_ms(self) -> int:
        return self._inference_time_ms

    @inference_time_ms.setter
    def inference_time_ms(self, value: int) -> None:
        self._inference_time_ms = value
        self._modify_object_edit("inferenceTimeMs", value)

    @property
    def model_version(self) -> str:
        return self._model_version

    @model_version.setter
    def model_version(self, value: str) -> None:
        self._model_version = value
        self._modify_object_edit("modelVersion", value)

    @property
    def thumbnail_base64(self) -> str:
        return self._thumbnail_base64

    @thumbnail_base64.setter
    def thumbnail_base64(self, value: str) -> None:
        self._thumbnail_base64 = value
        self._modify_object_edit("thumbnailBase64", value)

    @property
    def confidence(self) -> float:
        return self._confidence

    @confidence.setter
    def confidence(self, value: float) -> None:
        self._confidence = value
        self._modify_object_edit("confidence", value)

    @property
    def reading_id(self) -> str:
        return self._reading_id

    @reading_id.setter
    def reading_id(self, value: str) -> None:
        self._reading_id = value
        self._modify_object_edit("readingId", value)

    @property
    def robot_id(self) -> str:
        return self._robot_id

    @robot_id.setter
    def robot_id(self, value: str) -> None:
        self._robot_id = value
        self._modify_object_edit("robotId", value)

    @property
    def detected_class(self) -> str:
        return self._detected_class

    @detected_class.setter
    def detected_class(self, value: str) -> None:
        self._detected_class = value
        self._modify_object_edit("detectedClass", value)

    @property
    def timestamp(self) -> Union[datetime, int]:
        return self._timestamp

    @timestamp.setter
    def timestamp(self, value: Union[datetime, int]) -> None:
        """
        Handle datetime setting for UNIX timestamps.

        The timestamp should be an int in milliseconds. Most granular datetime unit in the ontology is milliseconds.
        Alternatively, you can provide a Python datetime object.
        """
        self._timestamp = value
        self._modify_object_edit("timestamp", value)

    def __eq__(self, other: Any) -> bool:
        return self is other or (
            type(self) == type(other)
            and (self.bounding_box == other.bounding_box)
            and (self.inspection_id == other.inspection_id)
            and (self.inference_time_ms == other.inference_time_ms)
            and (self.model_version == other.model_version)
            and (self.thumbnail_base64 == other.thumbnail_base64)
            and (self.confidence == other.confidence)
            and (self.reading_id == other.reading_id)
            and (self.robot_id == other.robot_id)
            and (self.detected_class == other.detected_class)
            and (self.timestamp == other.timestamp)
        )

    def __hash__(self) -> int:
        return hash(
            (
                type(self),
                sanitize_for_hashing(self.bounding_box),
                sanitize_for_hashing(self.inspection_id),
                sanitize_for_hashing(self.inference_time_ms),
                sanitize_for_hashing(self.model_version),
                sanitize_for_hashing(self.thumbnail_base64),
                sanitize_for_hashing(self.confidence),
                sanitize_for_hashing(self.reading_id),
                sanitize_for_hashing(self.robot_id),
                sanitize_for_hashing(self.detected_class),
                sanitize_for_hashing(self.timestamp),
            )
        )

    def __setattr__(self, name, value):
        if self._initialized and not hasattr(self, name):
            raise AttributeError(f"'VisionReadingEdits' object has no attribute '{name}'")
        object.__setattr__(self, name, value)

    def __repr__(self) -> str:
        return (
            f"VisionReadingEdits("
            f"bounding_box={self.bounding_box}, "
            f"inspection_id={self.inspection_id}, "
            f"inference_time_ms={self.inference_time_ms}, "
            f"model_version={self.model_version}, "
            f"thumbnail_base64={self.thumbnail_base64}, "
            f"confidence={self.confidence}, "
            f"reading_id={self.reading_id}, "
            f"robot_id={self.robot_id}, "
            f"detected_class={self.detected_class}, "
            f"timestamp={self.timestamp}, "
            ")"
        )

    def _modify_object_edit(self, name, value) -> None:
        if name == self.primary_key():
            raise AttributeError("Cannot modify the primary key of an ObjectEdit")
        object_locator = ObjectLocator(object_api_name="VisionReading", primary_key=self.get_primary_key())
        fields = {
            name: value,
        }
        self._ontology_edits.modify(locator=object_locator, fields=serialize_json_for_ontology_edits(fields))

    def _modify_object_struct_edit(self, name, value, struct_class_type, is_list) -> None:
        """
        Converts struct field API names to struct field RIDs and sets as JSON string.

        None / null values are required to be removed from the mapping to be set to null.
        """
        if name == self.primary_key():
            raise AttributeError("Cannot modify the primary key of an ObjectEdit")
        object_locator = ObjectLocator(object_api_name="VisionReading", primary_key=self.get_primary_key())
        fields = serialize_json_for_ontology_edits(
            {
                name: value,
            }
        )
        serialized_fields = {}
        for property_key, struct_values in fields.items():
            if is_list:
                serialized_list_structs = []
                for struct_value in struct_values:
                    serialized_list_structs.append(
                        json.dumps(
                            {
                                struct_class_type._api_name_to_property_rid()[k]: v
                                for k, v in struct_value.items()
                                if v is not None
                            }
                        )
                    )
                serialized_fields[property_key] = serialized_list_structs
            else:
                serialized_fields[property_key] = json.dumps(
                    {
                        struct_class_type._api_name_to_property_rid()[k]: v
                        for k, v in struct_values.items()
                        if v is not None
                    }
                )
        self._ontology_edits.modify(locator=object_locator, fields=serialized_fields)

    @property
    def inspection_event(self) -> VisionReadingInspectionEventLinkEdits:
        return VisionReadingInspectionEventLinkEdits(
            ontology_edits=self._ontology_edits,
            _ontologies_client=self._ontologies_client,
            _ontology_rid=self._ontology_rid,
            reading_id=self.reading_id,
        )

    @property
    def robot(self) -> VisionReadingRobotLinkEdits:
        return VisionReadingRobotLinkEdits(
            ontology_edits=self._ontology_edits,
            _ontologies_client=self._ontologies_client,
            _ontology_rid=self._ontology_rid,
            reading_id=self.reading_id,
        )
