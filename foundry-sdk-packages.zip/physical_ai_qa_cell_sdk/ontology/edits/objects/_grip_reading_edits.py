#  (c) Copyright 2023 Palantir Technologies Inc. All rights reserved.
import json
from datetime import datetime
from typing import TYPE_CHECKING, Any, Optional, Union

from foundry_sdk.v2.ontologies import OntologiesClient
from foundry_sdk_runtime import ObjectLocator
from foundry_sdk_runtime.serialization import serialize_json_for_ontology_edits
from foundry_sdk_runtime.types import sanitize_for_hashing
from physical_ai_qa_cell_sdk.ontology.edits.links.grip_reading._inspection_event import (
    GripReadingInspectionEventLinkEdits,
)
from physical_ai_qa_cell_sdk.ontology.edits.links.grip_reading._robot import GripReadingRobotLinkEdits

if TYPE_CHECKING:
    from foundry_sdk_runtime import OntologyEdits


class GripReadingEdits:
    """
    Used to track GripReading ontology object edits.

    # Code Samples

    ## Create a new object
    ```
    from foundry_sdk_runtime import OntologyEdits
    from ontology_sdk import FoundryClient

    @function(edit=GripReading)
    def create_new_grip_reading() -> OntologyEdits:

        # You can create new objects using the MyObjectType.create() method on the Ontology edits container.
        # When creating a new object, you must specify a value for its primary key.
        edits = FoundryClient().ontology.edits()
        new_grip_reading = edits.objects.GripReading.create(reading_id)

        # Must return the edits so that they can be applied
        return edits.get_edits()
    ```

    ## Edit an existing object
    ```
    from foundry_sdk_runtime import OntologyEdits
    from ontology_sdk import FoundryClient

    @function(edit=GripReading)
    def change_name_grip_reading(obj: GripReading, new_name: str) -> OntologyEdits:
        edits = FoundryClient().ontology.edits()

        # Obtain an editable view of that object
        editable_grip_reading = edits.objects.GripReading.edit(obj)

        editable_grip_reading.name = new_name

        # Must return the edits so that they can be applied
        return edits.get_edits()

    ```

    ## Delete an existing object
    ```
    from foundry_sdk_runtime import OntologyEdits
    from ontology_sdk import FoundryClient

    @function(edit=GripReading)
    def delete_grip_reading(obj: GripReading) -> OntologyEdits:
        edits = FoundryClient().ontology.edits()

        # You can delete an object by calling the MyObjectType.delete() method on the Ontology edits container.
        edits.objects.GripReading.delete(obj)

        # Must return the edits so that they can be applied
        return edits.get_edits()
    ```
    """

    def __init__(
        self,
        ontology_edits: "OntologyEdits",
        _ontologies_client: OntologiesClient,
        _ontology_rid: str,
        normalized_load: Optional[float] = None,
        inspection_id: Optional[str] = None,
        servo_load: Optional[float] = None,
        reading_id: Optional[str] = None,
        object_detected: Optional[bool] = None,
        grip_state: Optional[str] = None,
        robot_id: Optional[str] = None,
        timestamp: Optional[Union[datetime, int]] = None,
    ) -> None:
        object.__setattr__(self, "_initialized", False)
        object.__setattr__(self, "_ontology_edits", ontology_edits)
        object.__setattr__(self, "_ontologies_client", _ontologies_client)
        object.__setattr__(self, "_ontology_rid", _ontology_rid)
        object.__setattr__(self, "_normalized_load", normalized_load)
        object.__setattr__(self, "_inspection_id", inspection_id)
        object.__setattr__(self, "_servo_load", servo_load)
        object.__setattr__(self, "_reading_id", reading_id)
        object.__setattr__(self, "_object_detected", object_detected)
        object.__setattr__(self, "_grip_state", grip_state)
        object.__setattr__(self, "_robot_id", robot_id)
        object.__setattr__(self, "_timestamp", timestamp)
        object.__setattr__(self, "_initialized", True)

    @staticmethod
    def api_name() -> str:
        return "GripReading"

    @staticmethod
    def primary_key() -> str:
        return "reading_id"

    def get_primary_key(self) -> str:
        return self._reading_id

    @property
    def normalized_load(self) -> float:
        return self._normalized_load

    @normalized_load.setter
    def normalized_load(self, value: float) -> None:
        self._normalized_load = value
        self._modify_object_edit("normalizedLoad", value)

    @property
    def inspection_id(self) -> str:
        return self._inspection_id

    @inspection_id.setter
    def inspection_id(self, value: str) -> None:
        self._inspection_id = value
        self._modify_object_edit("inspectionId", value)

    @property
    def servo_load(self) -> float:
        return self._servo_load

    @servo_load.setter
    def servo_load(self, value: float) -> None:
        self._servo_load = value
        self._modify_object_edit("servoLoad", value)

    @property
    def reading_id(self) -> str:
        return self._reading_id

    @reading_id.setter
    def reading_id(self, value: str) -> None:
        self._reading_id = value
        self._modify_object_edit("readingId", value)

    @property
    def object_detected(self) -> bool:
        return self._object_detected

    @object_detected.setter
    def object_detected(self, value: bool) -> None:
        self._object_detected = value
        self._modify_object_edit("objectDetected", value)

    @property
    def grip_state(self) -> str:
        return self._grip_state

    @grip_state.setter
    def grip_state(self, value: str) -> None:
        self._grip_state = value
        self._modify_object_edit("gripState", value)

    @property
    def robot_id(self) -> str:
        return self._robot_id

    @robot_id.setter
    def robot_id(self, value: str) -> None:
        self._robot_id = value
        self._modify_object_edit("robotId", value)

    @property
    def timestamp(self) -> Union[datetime, int]:
        return self._timestamp

    @timestamp.setter
    def timestamp(self, value: Union[datetime, int]) -> None:
        """
        Handle datetime setting for UNIX timestamps.

        The timestamp should be an int in milliseconds. Most granular datetime unit in the ontology is milliseconds.
        Alternatively, you can provide a Python datetime object.
        """
        self._timestamp = value
        self._modify_object_edit("timestamp", value)

    def __eq__(self, other: Any) -> bool:
        return self is other or (
            type(self) == type(other)
            and (self.normalized_load == other.normalized_load)
            and (self.inspection_id == other.inspection_id)
            and (self.servo_load == other.servo_load)
            and (self.reading_id == other.reading_id)
            and (self.object_detected == other.object_detected)
            and (self.grip_state == other.grip_state)
            and (self.robot_id == other.robot_id)
            and (self.timestamp == other.timestamp)
        )

    def __hash__(self) -> int:
        return hash(
            (
                type(self),
                sanitize_for_hashing(self.normalized_load),
                sanitize_for_hashing(self.inspection_id),
                sanitize_for_hashing(self.servo_load),
                sanitize_for_hashing(self.reading_id),
                sanitize_for_hashing(self.object_detected),
                sanitize_for_hashing(self.grip_state),
                sanitize_for_hashing(self.robot_id),
                sanitize_for_hashing(self.timestamp),
            )
        )

    def __setattr__(self, name, value):
        if self._initialized and not hasattr(self, name):
            raise AttributeError(f"'GripReadingEdits' object has no attribute '{name}'")
        object.__setattr__(self, name, value)

    def __repr__(self) -> str:
        return (
            f"GripReadingEdits("
            f"normalized_load={self.normalized_load}, "
            f"inspection_id={self.inspection_id}, "
            f"servo_load={self.servo_load}, "
            f"reading_id={self.reading_id}, "
            f"object_detected={self.object_detected}, "
            f"grip_state={self.grip_state}, "
            f"robot_id={self.robot_id}, "
            f"timestamp={self.timestamp}, "
            ")"
        )

    def _modify_object_edit(self, name, value) -> None:
        if name == self.primary_key():
            raise AttributeError("Cannot modify the primary key of an ObjectEdit")
        object_locator = ObjectLocator(object_api_name="GripReading", primary_key=self.get_primary_key())
        fields = {
            name: value,
        }
        self._ontology_edits.modify(locator=object_locator, fields=serialize_json_for_ontology_edits(fields))

    def _modify_object_struct_edit(self, name, value, struct_class_type, is_list) -> None:
        """
        Converts struct field API names to struct field RIDs and sets as JSON string.

        None / null values are required to be removed from the mapping to be set to null.
        """
        if name == self.primary_key():
            raise AttributeError("Cannot modify the primary key of an ObjectEdit")
        object_locator = ObjectLocator(object_api_name="GripReading", primary_key=self.get_primary_key())
        fields = serialize_json_for_ontology_edits(
            {
                name: value,
            }
        )
        serialized_fields = {}
        for property_key, struct_values in fields.items():
            if is_list:
                serialized_list_structs = []
                for struct_value in struct_values:
                    serialized_list_structs.append(
                        json.dumps(
                            {
                                struct_class_type._api_name_to_property_rid()[k]: v
                                for k, v in struct_value.items()
                                if v is not None
                            }
                        )
                    )
                serialized_fields[property_key] = serialized_list_structs
            else:
                serialized_fields[property_key] = json.dumps(
                    {
                        struct_class_type._api_name_to_property_rid()[k]: v
                        for k, v in struct_values.items()
                        if v is not None
                    }
                )
        self._ontology_edits.modify(locator=object_locator, fields=serialized_fields)

    @property
    def inspection_event(self) -> GripReadingInspectionEventLinkEdits:
        return GripReadingInspectionEventLinkEdits(
            ontology_edits=self._ontology_edits,
            _ontologies_client=self._ontologies_client,
            _ontology_rid=self._ontology_rid,
            reading_id=self.reading_id,
        )

    @property
    def robot(self) -> GripReadingRobotLinkEdits:
        return GripReadingRobotLinkEdits(
            ontology_edits=self._ontology_edits,
            _ontologies_client=self._ontologies_client,
            _ontology_rid=self._ontology_rid,
            reading_id=self.reading_id,
        )
