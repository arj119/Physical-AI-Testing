#  (c) Copyright 2023 Palantir Technologies Inc. All rights reserved.
import json
from datetime import datetime
from typing import TYPE_CHECKING, Any, Optional, Union

from foundry_sdk.v2.ontologies import OntologiesClient
from foundry_sdk_runtime import ObjectLocator
from foundry_sdk_runtime.serialization import serialize_json_for_ontology_edits
from foundry_sdk_runtime.types import sanitize_for_hashing
from physical_ai_qa_cell_sdk.ontology.edits.links.robot._grip_readings import RobotGripReadingsLinkEdits
from physical_ai_qa_cell_sdk.ontology.edits.links.robot._inspection_events import RobotInspectionEventsLinkEdits
from physical_ai_qa_cell_sdk.ontology.edits.links.robot._operator_commands import RobotOperatorCommandsLinkEdits
from physical_ai_qa_cell_sdk.ontology.edits.links.robot._sensors import RobotSensorsLinkEdits
from physical_ai_qa_cell_sdk.ontology.edits.links.robot._vision_readings import RobotVisionReadingsLinkEdits

if TYPE_CHECKING:
    from foundry_sdk_runtime import OntologyEdits


class RobotEdits:
    """
    Used to track Robot ontology object edits.

    # Code Samples

    ## Create a new object
    ```
    from foundry_sdk_runtime import OntologyEdits
    from ontology_sdk import FoundryClient

    @function(edit=Robot)
    def create_new_robot() -> OntologyEdits:

        # You can create new objects using the MyObjectType.create() method on the Ontology edits container.
        # When creating a new object, you must specify a value for its primary key.
        edits = FoundryClient().ontology.edits()
        new_robot = edits.objects.Robot.create(robot_id)

        # Must return the edits so that they can be applied
        return edits.get_edits()
    ```

    ## Edit an existing object
    ```
    from foundry_sdk_runtime import OntologyEdits
    from ontology_sdk import FoundryClient

    @function(edit=Robot)
    def change_name_robot(obj: Robot, new_name: str) -> OntologyEdits:
        edits = FoundryClient().ontology.edits()

        # Obtain an editable view of that object
        editable_robot = edits.objects.Robot.edit(obj)

        editable_robot.name = new_name

        # Must return the edits so that they can be applied
        return edits.get_edits()

    ```

    ## Delete an existing object
    ```
    from foundry_sdk_runtime import OntologyEdits
    from ontology_sdk import FoundryClient

    @function(edit=Robot)
    def delete_robot(obj: Robot) -> OntologyEdits:
        edits = FoundryClient().ontology.edits()

        # You can delete an object by calling the MyObjectType.delete() method on the Ontology edits container.
        edits.objects.Robot.delete(obj)

        # Must return the edits so that they can be applied
        return edits.get_edits()
    ```
    """

    def __init__(
        self,
        ontology_edits: "OntologyEdits",
        _ontologies_client: OntologiesClient,
        _ontology_rid: str,
        last_heartbeat: Optional[Union[datetime, int]] = None,
        current_model_version: Optional[str] = None,
        name: Optional[str] = None,
        total_inspections: Optional[int] = None,
        robot_id: Optional[str] = None,
        grip_tolerance: Optional[float] = None,
        status: Optional[str] = None,
    ) -> None:
        object.__setattr__(self, "_initialized", False)
        object.__setattr__(self, "_ontology_edits", ontology_edits)
        object.__setattr__(self, "_ontologies_client", _ontologies_client)
        object.__setattr__(self, "_ontology_rid", _ontology_rid)
        object.__setattr__(self, "_last_heartbeat", last_heartbeat)
        object.__setattr__(self, "_current_model_version", current_model_version)
        object.__setattr__(self, "_name", name)
        object.__setattr__(self, "_total_inspections", total_inspections)
        object.__setattr__(self, "_robot_id", robot_id)
        object.__setattr__(self, "_grip_tolerance", grip_tolerance)
        object.__setattr__(self, "_status", status)
        object.__setattr__(self, "_initialized", True)

    @staticmethod
    def api_name() -> str:
        return "Robot"

    @staticmethod
    def primary_key() -> str:
        return "robot_id"

    def get_primary_key(self) -> str:
        return self._robot_id

    @property
    def last_heartbeat(self) -> Union[datetime, int]:
        return self._last_heartbeat

    @last_heartbeat.setter
    def last_heartbeat(self, value: Union[datetime, int]) -> None:
        """
        Handle datetime setting for UNIX timestamps.

        The timestamp should be an int in milliseconds. Most granular datetime unit in the ontology is milliseconds.
        Alternatively, you can provide a Python datetime object.
        """
        self._last_heartbeat = value
        self._modify_object_edit("lastHeartbeat", value)

    @property
    def current_model_version(self) -> str:
        return self._current_model_version

    @current_model_version.setter
    def current_model_version(self, value: str) -> None:
        self._current_model_version = value
        self._modify_object_edit("currentModelVersion", value)

    @property
    def name(self) -> str:
        return self._name

    @name.setter
    def name(self, value: str) -> None:
        self._name = value
        self._modify_object_edit("name", value)

    @property
    def total_inspections(self) -> int:
        return self._total_inspections

    @total_inspections.setter
    def total_inspections(self, value: int) -> None:
        self._total_inspections = value
        self._modify_object_edit("totalInspections", value)

    @property
    def robot_id(self) -> str:
        return self._robot_id

    @robot_id.setter
    def robot_id(self, value: str) -> None:
        self._robot_id = value
        self._modify_object_edit("robotId", value)

    @property
    def grip_tolerance(self) -> float:
        return self._grip_tolerance

    @grip_tolerance.setter
    def grip_tolerance(self, value: float) -> None:
        self._grip_tolerance = value
        self._modify_object_edit("gripTolerance", value)

    @property
    def status(self) -> str:
        return self._status

    @status.setter
    def status(self, value: str) -> None:
        self._status = value
        self._modify_object_edit("status", value)

    def __eq__(self, other: Any) -> bool:
        return self is other or (
            type(self) == type(other)
            and (self.last_heartbeat == other.last_heartbeat)
            and (self.current_model_version == other.current_model_version)
            and (self.name == other.name)
            and (self.total_inspections == other.total_inspections)
            and (self.robot_id == other.robot_id)
            and (self.grip_tolerance == other.grip_tolerance)
            and (self.status == other.status)
        )

    def __hash__(self) -> int:
        return hash(
            (
                type(self),
                sanitize_for_hashing(self.last_heartbeat),
                sanitize_for_hashing(self.current_model_version),
                sanitize_for_hashing(self.name),
                sanitize_for_hashing(self.total_inspections),
                sanitize_for_hashing(self.robot_id),
                sanitize_for_hashing(self.grip_tolerance),
                sanitize_for_hashing(self.status),
            )
        )

    def __setattr__(self, name, value):
        if self._initialized and not hasattr(self, name):
            raise AttributeError(f"'RobotEdits' object has no attribute '{name}'")
        object.__setattr__(self, name, value)

    def __repr__(self) -> str:
        return (
            f"RobotEdits("
            f"last_heartbeat={self.last_heartbeat}, "
            f"current_model_version={self.current_model_version}, "
            f"name={self.name}, "
            f"total_inspections={self.total_inspections}, "
            f"robot_id={self.robot_id}, "
            f"grip_tolerance={self.grip_tolerance}, "
            f"status={self.status}, "
            ")"
        )

    def _modify_object_edit(self, name, value) -> None:
        if name == self.primary_key():
            raise AttributeError("Cannot modify the primary key of an ObjectEdit")
        object_locator = ObjectLocator(object_api_name="Robot", primary_key=self.get_primary_key())
        fields = {
            name: value,
        }
        self._ontology_edits.modify(locator=object_locator, fields=serialize_json_for_ontology_edits(fields))

    def _modify_object_struct_edit(self, name, value, struct_class_type, is_list) -> None:
        """
        Converts struct field API names to struct field RIDs and sets as JSON string.

        None / null values are required to be removed from the mapping to be set to null.
        """
        if name == self.primary_key():
            raise AttributeError("Cannot modify the primary key of an ObjectEdit")
        object_locator = ObjectLocator(object_api_name="Robot", primary_key=self.get_primary_key())
        fields = serialize_json_for_ontology_edits(
            {
                name: value,
            }
        )
        serialized_fields = {}
        for property_key, struct_values in fields.items():
            if is_list:
                serialized_list_structs = []
                for struct_value in struct_values:
                    serialized_list_structs.append(
                        json.dumps(
                            {
                                struct_class_type._api_name_to_property_rid()[k]: v
                                for k, v in struct_value.items()
                                if v is not None
                            }
                        )
                    )
                serialized_fields[property_key] = serialized_list_structs
            else:
                serialized_fields[property_key] = json.dumps(
                    {
                        struct_class_type._api_name_to_property_rid()[k]: v
                        for k, v in struct_values.items()
                        if v is not None
                    }
                )
        self._ontology_edits.modify(locator=object_locator, fields=serialized_fields)

    @property
    def grip_readings(self) -> RobotGripReadingsLinkEdits:
        return RobotGripReadingsLinkEdits(
            ontology_edits=self._ontology_edits,
            _ontologies_client=self._ontologies_client,
            _ontology_rid=self._ontology_rid,
            robot_id=self.robot_id,
        )

    @property
    def inspection_events(self) -> RobotInspectionEventsLinkEdits:
        return RobotInspectionEventsLinkEdits(
            ontology_edits=self._ontology_edits,
            _ontologies_client=self._ontologies_client,
            _ontology_rid=self._ontology_rid,
            robot_id=self.robot_id,
        )

    @property
    def operator_commands(self) -> RobotOperatorCommandsLinkEdits:
        return RobotOperatorCommandsLinkEdits(
            ontology_edits=self._ontology_edits,
            _ontologies_client=self._ontologies_client,
            _ontology_rid=self._ontology_rid,
            robot_id=self.robot_id,
        )

    @property
    def sensors(self) -> RobotSensorsLinkEdits:
        return RobotSensorsLinkEdits(
            ontology_edits=self._ontology_edits,
            _ontologies_client=self._ontologies_client,
            _ontology_rid=self._ontology_rid,
            robot_id=self.robot_id,
        )

    @property
    def vision_readings(self) -> RobotVisionReadingsLinkEdits:
        return RobotVisionReadingsLinkEdits(
            ontology_edits=self._ontology_edits,
            _ontologies_client=self._ontologies_client,
            _ontology_rid=self._ontology_rid,
            robot_id=self.robot_id,
        )
