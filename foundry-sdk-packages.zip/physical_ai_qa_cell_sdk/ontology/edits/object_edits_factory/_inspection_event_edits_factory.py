from datetime import datetime
from typing import TYPE_CHECKING, Callable, Optional, Union

from foundry_sdk.v2.core.models import MediaReference
from foundry_sdk.v2.ontologies import OntologiesClient
from foundry_sdk_runtime import ObjectLocator
from foundry_sdk_runtime.media import Media
from foundry_sdk_runtime.serialization import serialize_json_for_ontology_edits
from physical_ai_qa_cell_sdk.ontology.objects import InspectionEvent

from ..objects import InspectionEventEdits

if TYPE_CHECKING:
    from foundry_sdk_runtime import OntologyEdits


class InspectionEventEditsFactory:
    def __init__(
        self,
        ontology_edits: "OntologyEdits",
        _ontologies_client: OntologiesClient,
        _ontology_rid: str,
        object_loader: Callable[[str], InspectionEvent],
    ):
        self._ontology_edits = ontology_edits
        self._ontologies_client = _ontologies_client
        self._ontology_rid = _ontology_rid
        self._object_loader = object_loader

    def delete(
        self,
        object_or_primary_key: Union[str, "InspectionEvent", "InspectionEventEdits"],
    ) -> None:
        if not isinstance(object_or_primary_key, (str, InspectionEvent, InspectionEventEdits)):
            raise ValueError("object_or_primary_key must be of type str, InspectionEvent, or InspectionEventEdits")
        else:
            primary_key = (
                object_or_primary_key
                if isinstance(object_or_primary_key, str)
                else object_or_primary_key.get_primary_key()
            )

        object_locator = ObjectLocator(object_api_name="InspectionEvent", primary_key=primary_key)

        self._ontology_edits.delete(locator=object_locator)

    def edit(
        self,
        object_or_primary_key: Union[str, "InspectionEvent"],
    ) -> InspectionEventEdits:
        if not isinstance(object_or_primary_key, (str, InspectionEvent)):
            raise ValueError("object_or_primary_key must be of type str or InspectionEvent")

        object = (
            object_or_primary_key
            if isinstance(object_or_primary_key, InspectionEvent)
            else self._object_loader(object_or_primary_key)
        )

        return InspectionEventEdits(
            ontology_edits=self._ontology_edits,
            _ontologies_client=self._ontologies_client,
            _ontology_rid=self._ontology_rid,
            grip_load=object.grip_load,
            model_version=object.model_version,
            reviewed_at=object.reviewed_at,
            final_decision=object.final_decision,
            reviewed_by=object.reviewed_by,
            robot_id=object.robot_id,
            fusion_decision=object.fusion_decision,
            inspection_id=object.inspection_id,
            vision_agrees=object.vision_agrees,
            operator_notes=object.operator_notes,
            vision_confidence=object.vision_confidence,
            review_status=object.review_status,
            cycle_time_ms=object.cycle_time_ms,
            vision_class=object.vision_class,
            fusion_reason=object.fusion_reason,
            timestamp=object.timestamp,
            captured_image_ref=object.captured_image_ref,
        )

    def create(
        self,
        inspection_id: str,
        grip_load: Optional[float] = None,
        model_version: Optional[str] = None,
        reviewed_at: Optional[Union[datetime, int]] = None,
        final_decision: Optional[str] = None,
        reviewed_by: Optional[str] = None,
        robot_id: Optional[str] = None,
        fusion_decision: Optional[str] = None,
        vision_agrees: Optional[bool] = None,
        operator_notes: Optional[str] = None,
        vision_confidence: Optional[float] = None,
        review_status: Optional[str] = None,
        cycle_time_ms: Optional[int] = None,
        vision_class: Optional[str] = None,
        fusion_reason: Optional[str] = None,
        timestamp: Optional[Union[datetime, int]] = None,
        captured_image_ref: Optional[Union[Media, MediaReference]] = None,
    ) -> InspectionEventEdits:
        object_locator = ObjectLocator(object_api_name="InspectionEvent", primary_key=inspection_id)
        fields = {
            "gripLoad": grip_load,
            "modelVersion": model_version,
            "reviewedAt": reviewed_at,
            "finalDecision": final_decision,
            "reviewedBy": reviewed_by,
            "robotId": robot_id,
            "fusionDecision": fusion_decision,
            "visionAgrees": vision_agrees,
            "operatorNotes": operator_notes,
            "visionConfidence": vision_confidence,
            "reviewStatus": review_status,
            "cycleTimeMs": cycle_time_ms,
            "visionClass": vision_class,
            "fusionReason": fusion_reason,
            "timestamp": timestamp,
            "capturedImageRef": captured_image_ref,
        }

        fields = {k: v for k, v in fields.items() if v is not None}

        self._ontology_edits.add(locator=object_locator, fields=serialize_json_for_ontology_edits(fields))

        return InspectionEventEdits(
            ontology_edits=self._ontology_edits,
            _ontologies_client=self._ontologies_client,
            _ontology_rid=self._ontology_rid,
            grip_load=grip_load,
            model_version=model_version,
            reviewed_at=reviewed_at,
            final_decision=final_decision,
            reviewed_by=reviewed_by,
            robot_id=robot_id,
            fusion_decision=fusion_decision,
            inspection_id=inspection_id,
            vision_agrees=vision_agrees,
            operator_notes=operator_notes,
            vision_confidence=vision_confidence,
            review_status=review_status,
            cycle_time_ms=cycle_time_ms,
            vision_class=vision_class,
            fusion_reason=fusion_reason,
            timestamp=timestamp,
            captured_image_ref=captured_image_ref,
        )
