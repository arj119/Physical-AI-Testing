from datetime import datetime
from typing import TYPE_CHECKING, Callable, Optional, Union

from foundry_sdk.v2.ontologies import OntologiesClient
from foundry_sdk_runtime import ObjectLocator
from foundry_sdk_runtime.serialization import serialize_json_for_ontology_edits
from physical_ai_qa_cell_sdk.ontology.objects import OperatorCommand

from ..objects import OperatorCommandEdits

if TYPE_CHECKING:
    from foundry_sdk_runtime import OntologyEdits


class OperatorCommandEditsFactory:
    def __init__(
        self,
        ontology_edits: "OntologyEdits",
        _ontologies_client: OntologiesClient,
        _ontology_rid: str,
        object_loader: Callable[[str], OperatorCommand],
    ):
        self._ontology_edits = ontology_edits
        self._ontologies_client = _ontologies_client
        self._ontology_rid = _ontology_rid
        self._object_loader = object_loader

    def delete(
        self,
        object_or_primary_key: Union[str, "OperatorCommand", "OperatorCommandEdits"],
    ) -> None:
        if not isinstance(object_or_primary_key, (str, OperatorCommand, OperatorCommandEdits)):
            raise ValueError("object_or_primary_key must be of type str, OperatorCommand, or OperatorCommandEdits")
        else:
            primary_key = (
                object_or_primary_key
                if isinstance(object_or_primary_key, str)
                else object_or_primary_key.get_primary_key()
            )

        object_locator = ObjectLocator(object_api_name="OperatorCommand", primary_key=primary_key)

        self._ontology_edits.delete(locator=object_locator)

    def edit(
        self,
        object_or_primary_key: Union[str, "OperatorCommand"],
    ) -> OperatorCommandEdits:
        if not isinstance(object_or_primary_key, (str, OperatorCommand)):
            raise ValueError("object_or_primary_key must be of type str or OperatorCommand")

        object = (
            object_or_primary_key
            if isinstance(object_or_primary_key, OperatorCommand)
            else self._object_loader(object_or_primary_key)
        )

        return OperatorCommandEdits(
            ontology_edits=self._ontology_edits,
            _ontologies_client=self._ontologies_client,
            _ontology_rid=self._ontology_rid,
            created_at=object.created_at,
            command_type=object.command_type,
            executed_at=object.executed_at,
            payload=object.payload,
            robot_id=object.robot_id,
            command_id=object.command_id,
            status=object.status,
        )

    def create(
        self,
        command_id: str,
        created_at: Optional[Union[datetime, int]] = None,
        command_type: Optional[str] = None,
        executed_at: Optional[Union[datetime, int]] = None,
        payload: Optional[str] = None,
        robot_id: Optional[str] = None,
        status: Optional[str] = None,
    ) -> OperatorCommandEdits:
        object_locator = ObjectLocator(object_api_name="OperatorCommand", primary_key=command_id)
        fields = {
            "createdAt": created_at,
            "commandType": command_type,
            "executedAt": executed_at,
            "payload": payload,
            "robotId": robot_id,
            "status": status,
        }

        fields = {k: v for k, v in fields.items() if v is not None}

        self._ontology_edits.add(locator=object_locator, fields=serialize_json_for_ontology_edits(fields))

        return OperatorCommandEdits(
            ontology_edits=self._ontology_edits,
            _ontologies_client=self._ontologies_client,
            _ontology_rid=self._ontology_rid,
            created_at=created_at,
            command_type=command_type,
            executed_at=executed_at,
            payload=payload,
            robot_id=robot_id,
            command_id=command_id,
            status=status,
        )
