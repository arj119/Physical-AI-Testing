from datetime import datetime
from typing import TYPE_CHECKING, Callable, Optional, Union

from foundry_sdk.v2.ontologies import OntologiesClient
from foundry_sdk_runtime import ObjectLocator
from foundry_sdk_runtime.serialization import serialize_json_for_ontology_edits
from physical_ai_qa_cell_sdk.ontology.objects import Robot

from ..objects import RobotEdits

if TYPE_CHECKING:
    from foundry_sdk_runtime import OntologyEdits


class RobotEditsFactory:
    def __init__(
        self,
        ontology_edits: "OntologyEdits",
        _ontologies_client: OntologiesClient,
        _ontology_rid: str,
        object_loader: Callable[[str], Robot],
    ):
        self._ontology_edits = ontology_edits
        self._ontologies_client = _ontologies_client
        self._ontology_rid = _ontology_rid
        self._object_loader = object_loader

    def delete(
        self,
        object_or_primary_key: Union[str, "Robot", "RobotEdits"],
    ) -> None:
        if not isinstance(object_or_primary_key, (str, Robot, RobotEdits)):
            raise ValueError("object_or_primary_key must be of type str, Robot, or RobotEdits")
        else:
            primary_key = (
                object_or_primary_key
                if isinstance(object_or_primary_key, str)
                else object_or_primary_key.get_primary_key()
            )

        object_locator = ObjectLocator(object_api_name="Robot", primary_key=primary_key)

        self._ontology_edits.delete(locator=object_locator)

    def edit(
        self,
        object_or_primary_key: Union[str, "Robot"],
    ) -> RobotEdits:
        if not isinstance(object_or_primary_key, (str, Robot)):
            raise ValueError("object_or_primary_key must be of type str or Robot")

        object = (
            object_or_primary_key
            if isinstance(object_or_primary_key, Robot)
            else self._object_loader(object_or_primary_key)
        )

        return RobotEdits(
            ontology_edits=self._ontology_edits,
            _ontologies_client=self._ontologies_client,
            _ontology_rid=self._ontology_rid,
            last_heartbeat=object.last_heartbeat,
            current_model_version=object.current_model_version,
            name=object.name,
            total_inspections=object.total_inspections,
            robot_id=object.robot_id,
            grip_tolerance=object.grip_tolerance,
            status=object.status,
        )

    def create(
        self,
        robot_id: str,
        last_heartbeat: Optional[Union[datetime, int]] = None,
        current_model_version: Optional[str] = None,
        name: Optional[str] = None,
        total_inspections: Optional[int] = None,
        grip_tolerance: Optional[float] = None,
        status: Optional[str] = None,
    ) -> RobotEdits:
        object_locator = ObjectLocator(object_api_name="Robot", primary_key=robot_id)
        fields = {
            "lastHeartbeat": last_heartbeat,
            "currentModelVersion": current_model_version,
            "name": name,
            "totalInspections": total_inspections,
            "gripTolerance": grip_tolerance,
            "status": status,
        }

        fields = {k: v for k, v in fields.items() if v is not None}

        self._ontology_edits.add(locator=object_locator, fields=serialize_json_for_ontology_edits(fields))

        return RobotEdits(
            ontology_edits=self._ontology_edits,
            _ontologies_client=self._ontologies_client,
            _ontology_rid=self._ontology_rid,
            last_heartbeat=last_heartbeat,
            current_model_version=current_model_version,
            name=name,
            total_inspections=total_inspections,
            robot_id=robot_id,
            grip_tolerance=grip_tolerance,
            status=status,
        )
