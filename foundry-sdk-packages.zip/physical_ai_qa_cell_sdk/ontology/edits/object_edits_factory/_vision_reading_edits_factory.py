from datetime import datetime
from typing import TYPE_CHECKING, Callable, Optional, Union

from foundry_sdk.v2.ontologies import OntologiesClient
from foundry_sdk_runtime import ObjectLocator
from foundry_sdk_runtime.serialization import serialize_json_for_ontology_edits
from physical_ai_qa_cell_sdk.ontology.objects import VisionReading

from ..objects import VisionReadingEdits

if TYPE_CHECKING:
    from foundry_sdk_runtime import OntologyEdits


class VisionReadingEditsFactory:
    def __init__(
        self,
        ontology_edits: "OntologyEdits",
        _ontologies_client: OntologiesClient,
        _ontology_rid: str,
        object_loader: Callable[[str], VisionReading],
    ):
        self._ontology_edits = ontology_edits
        self._ontologies_client = _ontologies_client
        self._ontology_rid = _ontology_rid
        self._object_loader = object_loader

    def delete(
        self,
        object_or_primary_key: Union[str, "VisionReading", "VisionReadingEdits"],
    ) -> None:
        if not isinstance(object_or_primary_key, (str, VisionReading, VisionReadingEdits)):
            raise ValueError("object_or_primary_key must be of type str, VisionReading, or VisionReadingEdits")
        else:
            primary_key = (
                object_or_primary_key
                if isinstance(object_or_primary_key, str)
                else object_or_primary_key.get_primary_key()
            )

        object_locator = ObjectLocator(object_api_name="VisionReading", primary_key=primary_key)

        self._ontology_edits.delete(locator=object_locator)

    def edit(
        self,
        object_or_primary_key: Union[str, "VisionReading"],
    ) -> VisionReadingEdits:
        if not isinstance(object_or_primary_key, (str, VisionReading)):
            raise ValueError("object_or_primary_key must be of type str or VisionReading")

        object = (
            object_or_primary_key
            if isinstance(object_or_primary_key, VisionReading)
            else self._object_loader(object_or_primary_key)
        )

        return VisionReadingEdits(
            ontology_edits=self._ontology_edits,
            _ontologies_client=self._ontologies_client,
            _ontology_rid=self._ontology_rid,
            bounding_box=object.bounding_box,
            inspection_id=object.inspection_id,
            inference_time_ms=object.inference_time_ms,
            model_version=object.model_version,
            thumbnail_base64=object.thumbnail_base64,
            confidence=object.confidence,
            reading_id=object.reading_id,
            robot_id=object.robot_id,
            detected_class=object.detected_class,
            timestamp=object.timestamp,
        )

    def create(
        self,
        reading_id: str,
        bounding_box: Optional[list[float]] = None,
        inspection_id: Optional[str] = None,
        inference_time_ms: Optional[int] = None,
        model_version: Optional[str] = None,
        thumbnail_base64: Optional[str] = None,
        confidence: Optional[float] = None,
        robot_id: Optional[str] = None,
        detected_class: Optional[str] = None,
        timestamp: Optional[Union[datetime, int]] = None,
    ) -> VisionReadingEdits:
        object_locator = ObjectLocator(object_api_name="VisionReading", primary_key=reading_id)
        fields = {
            "boundingBox": bounding_box,
            "inspectionId": inspection_id,
            "inferenceTimeMs": inference_time_ms,
            "modelVersion": model_version,
            "thumbnailBase64": thumbnail_base64,
            "confidence": confidence,
            "robotId": robot_id,
            "detectedClass": detected_class,
            "timestamp": timestamp,
        }

        fields = {k: v for k, v in fields.items() if v is not None}

        self._ontology_edits.add(locator=object_locator, fields=serialize_json_for_ontology_edits(fields))

        return VisionReadingEdits(
            ontology_edits=self._ontology_edits,
            _ontologies_client=self._ontologies_client,
            _ontology_rid=self._ontology_rid,
            bounding_box=bounding_box,
            inspection_id=inspection_id,
            inference_time_ms=inference_time_ms,
            model_version=model_version,
            thumbnail_base64=thumbnail_base64,
            confidence=confidence,
            reading_id=reading_id,
            robot_id=robot_id,
            detected_class=detected_class,
            timestamp=timestamp,
        )
