from datetime import datetime
from typing import TYPE_CHECKING, Callable, Optional, Union

from foundry_sdk.v2.core.models import MediaReference
from foundry_sdk.v2.ontologies import OntologiesClient
from foundry_sdk_runtime import ObjectLocator
from foundry_sdk_runtime.media import Media
from foundry_sdk_runtime.serialization import serialize_json_for_ontology_edits
from physical_ai_qa_cell_sdk.ontology.objects import ModelRegistry

from ..objects import ModelRegistryEdits

if TYPE_CHECKING:
    from foundry_sdk_runtime import OntologyEdits


class ModelRegistryEditsFactory:
    def __init__(
        self,
        ontology_edits: "OntologyEdits",
        _ontologies_client: OntologiesClient,
        _ontology_rid: str,
        object_loader: Callable[[str], ModelRegistry],
    ):
        self._ontology_edits = ontology_edits
        self._ontologies_client = _ontologies_client
        self._ontology_rid = _ontology_rid
        self._object_loader = object_loader

    def delete(
        self,
        object_or_primary_key: Union[str, "ModelRegistry", "ModelRegistryEdits"],
    ) -> None:
        if not isinstance(object_or_primary_key, (str, ModelRegistry, ModelRegistryEdits)):
            raise ValueError("object_or_primary_key must be of type str, ModelRegistry, or ModelRegistryEdits")
        else:
            primary_key = (
                object_or_primary_key
                if isinstance(object_or_primary_key, str)
                else object_or_primary_key.get_primary_key()
            )

        object_locator = ObjectLocator(object_api_name="ModelRegistry", primary_key=primary_key)

        self._ontology_edits.delete(locator=object_locator)

    def edit(
        self,
        object_or_primary_key: Union[str, "ModelRegistry"],
    ) -> ModelRegistryEdits:
        if not isinstance(object_or_primary_key, (str, ModelRegistry)):
            raise ValueError("object_or_primary_key must be of type str or ModelRegistry")

        object = (
            object_or_primary_key
            if isinstance(object_or_primary_key, ModelRegistry)
            else self._object_loader(object_or_primary_key)
        )

        return ModelRegistryEdits(
            ontology_edits=self._ontology_edits,
            _ontologies_client=self._ontologies_client,
            _ontology_rid=self._ontology_rid,
            published_at=object.published_at,
            model_id=object.model_id,
            accuracy=object.accuracy,
            description=object.description,
            artifact_path=object.artifact_path,
            version=object.version,
            status=object.status,
            model_artifact_ref=object.model_artifact_ref,
        )

    def create(
        self,
        model_id: str,
        published_at: Optional[Union[datetime, int]] = None,
        accuracy: Optional[float] = None,
        description: Optional[str] = None,
        artifact_path: Optional[str] = None,
        version: Optional[str] = None,
        status: Optional[str] = None,
        model_artifact_ref: Optional[Union[Media, MediaReference]] = None,
    ) -> ModelRegistryEdits:
        object_locator = ObjectLocator(object_api_name="ModelRegistry", primary_key=model_id)
        fields = {
            "publishedAt": published_at,
            "accuracy": accuracy,
            "description": description,
            "artifactPath": artifact_path,
            "version": version,
            "status": status,
            "modelArtifactRef": model_artifact_ref,
        }

        fields = {k: v for k, v in fields.items() if v is not None}

        self._ontology_edits.add(locator=object_locator, fields=serialize_json_for_ontology_edits(fields))

        return ModelRegistryEdits(
            ontology_edits=self._ontology_edits,
            _ontologies_client=self._ontologies_client,
            _ontology_rid=self._ontology_rid,
            published_at=published_at,
            model_id=model_id,
            accuracy=accuracy,
            description=description,
            artifact_path=artifact_path,
            version=version,
            status=status,
            model_artifact_ref=model_artifact_ref,
        )
