from typing import TYPE_CHECKING, Callable, Optional, Union

from foundry_sdk.v2.ontologies import OntologiesClient
from foundry_sdk_runtime import ObjectLocator
from foundry_sdk_runtime.serialization import serialize_json_for_ontology_edits
from foundry_sdk_runtime.timeseries import Timeseries
from physical_ai_qa_cell_sdk.ontology.objects import Sensor

from ..objects import SensorEdits

if TYPE_CHECKING:
    from foundry_sdk_runtime import OntologyEdits


class SensorEditsFactory:
    def __init__(
        self,
        ontology_edits: "OntologyEdits",
        _ontologies_client: OntologiesClient,
        _ontology_rid: str,
        object_loader: Callable[[str], Sensor],
    ):
        self._ontology_edits = ontology_edits
        self._ontologies_client = _ontologies_client
        self._ontology_rid = _ontology_rid
        self._object_loader = object_loader

    def delete(
        self,
        object_or_primary_key: Union[str, "Sensor", "SensorEdits"],
    ) -> None:
        if not isinstance(object_or_primary_key, (str, Sensor, SensorEdits)):
            raise ValueError("object_or_primary_key must be of type str, Sensor, or SensorEdits")
        else:
            primary_key = (
                object_or_primary_key
                if isinstance(object_or_primary_key, str)
                else object_or_primary_key.get_primary_key()
            )

        object_locator = ObjectLocator(object_api_name="Sensor", primary_key=primary_key)

        self._ontology_edits.delete(locator=object_locator)

    def edit(
        self,
        object_or_primary_key: Union[str, "Sensor"],
    ) -> SensorEdits:
        if not isinstance(object_or_primary_key, (str, Sensor)):
            raise ValueError("object_or_primary_key must be of type str or Sensor")

        object = (
            object_or_primary_key
            if isinstance(object_or_primary_key, Sensor)
            else self._object_loader(object_or_primary_key)
        )

        return SensorEdits(
            ontology_edits=self._ontology_edits,
            _ontologies_client=self._ontologies_client,
            _ontology_rid=self._ontology_rid,
            is_categorical=object.is_categorical,
            internal_interpolation=object.internal_interpolation,
            sensor_name1=object.sensor_name1,
            sensor_type=object.sensor_type,
            location=object.location,
            units=object.units,
            robot_id=object.robot_id,
            sensor_type_id=object.sensor_type_id,
            sensor_id=object.sensor_id,
            status=object.status,
            series_id=object.series_id,
        )

    def create(
        self,
        sensor_id: str,
        is_categorical: Optional[bool] = None,
        internal_interpolation: Optional[str] = None,
        sensor_name1: Optional[str] = None,
        sensor_type: Optional[str] = None,
        location: Optional[str] = None,
        units: Optional[str] = None,
        robot_id: Optional[str] = None,
        sensor_type_id: Optional[str] = None,
        status: Optional[str] = None,
        series_id: Optional[Timeseries[float]] = None,
    ) -> SensorEdits:
        object_locator = ObjectLocator(object_api_name="Sensor", primary_key=sensor_id)
        fields = {
            "isCategorical": is_categorical,
            "internalInterpolation": internal_interpolation,
            "sensorName1": sensor_name1,
            "sensorType": sensor_type,
            "location": location,
            "units": units,
            "robotId": robot_id,
            "sensorTypeId": sensor_type_id,
            "status": status,
            "seriesId": series_id,
        }

        fields = {k: v for k, v in fields.items() if v is not None}

        self._ontology_edits.add(locator=object_locator, fields=serialize_json_for_ontology_edits(fields))

        return SensorEdits(
            ontology_edits=self._ontology_edits,
            _ontologies_client=self._ontologies_client,
            _ontology_rid=self._ontology_rid,
            is_categorical=is_categorical,
            internal_interpolation=internal_interpolation,
            sensor_name1=sensor_name1,
            sensor_type=sensor_type,
            location=location,
            units=units,
            robot_id=robot_id,
            sensor_type_id=sensor_type_id,
            sensor_id=sensor_id,
            status=status,
            series_id=series_id,
        )
