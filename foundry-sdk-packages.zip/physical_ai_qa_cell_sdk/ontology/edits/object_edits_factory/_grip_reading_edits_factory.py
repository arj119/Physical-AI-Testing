from datetime import datetime
from typing import TYPE_CHECKING, Callable, Optional, Union

from foundry_sdk.v2.ontologies import OntologiesClient
from foundry_sdk_runtime import ObjectLocator
from foundry_sdk_runtime.serialization import serialize_json_for_ontology_edits
from physical_ai_qa_cell_sdk.ontology.objects import GripReading

from ..objects import GripReadingEdits

if TYPE_CHECKING:
    from foundry_sdk_runtime import OntologyEdits


class GripReadingEditsFactory:
    def __init__(
        self,
        ontology_edits: "OntologyEdits",
        _ontologies_client: OntologiesClient,
        _ontology_rid: str,
        object_loader: Callable[[str], GripReading],
    ):
        self._ontology_edits = ontology_edits
        self._ontologies_client = _ontologies_client
        self._ontology_rid = _ontology_rid
        self._object_loader = object_loader

    def delete(
        self,
        object_or_primary_key: Union[str, "GripReading", "GripReadingEdits"],
    ) -> None:
        if not isinstance(object_or_primary_key, (str, GripReading, GripReadingEdits)):
            raise ValueError("object_or_primary_key must be of type str, GripReading, or GripReadingEdits")
        else:
            primary_key = (
                object_or_primary_key
                if isinstance(object_or_primary_key, str)
                else object_or_primary_key.get_primary_key()
            )

        object_locator = ObjectLocator(object_api_name="GripReading", primary_key=primary_key)

        self._ontology_edits.delete(locator=object_locator)

    def edit(
        self,
        object_or_primary_key: Union[str, "GripReading"],
    ) -> GripReadingEdits:
        if not isinstance(object_or_primary_key, (str, GripReading)):
            raise ValueError("object_or_primary_key must be of type str or GripReading")

        object = (
            object_or_primary_key
            if isinstance(object_or_primary_key, GripReading)
            else self._object_loader(object_or_primary_key)
        )

        return GripReadingEdits(
            ontology_edits=self._ontology_edits,
            _ontologies_client=self._ontologies_client,
            _ontology_rid=self._ontology_rid,
            normalized_load=object.normalized_load,
            inspection_id=object.inspection_id,
            servo_load=object.servo_load,
            reading_id=object.reading_id,
            object_detected=object.object_detected,
            grip_state=object.grip_state,
            robot_id=object.robot_id,
            timestamp=object.timestamp,
        )

    def create(
        self,
        reading_id: str,
        normalized_load: Optional[float] = None,
        inspection_id: Optional[str] = None,
        servo_load: Optional[float] = None,
        object_detected: Optional[bool] = None,
        grip_state: Optional[str] = None,
        robot_id: Optional[str] = None,
        timestamp: Optional[Union[datetime, int]] = None,
    ) -> GripReadingEdits:
        object_locator = ObjectLocator(object_api_name="GripReading", primary_key=reading_id)
        fields = {
            "normalizedLoad": normalized_load,
            "inspectionId": inspection_id,
            "servoLoad": servo_load,
            "objectDetected": object_detected,
            "gripState": grip_state,
            "robotId": robot_id,
            "timestamp": timestamp,
        }

        fields = {k: v for k, v in fields.items() if v is not None}

        self._ontology_edits.add(locator=object_locator, fields=serialize_json_for_ontology_edits(fields))

        return GripReadingEdits(
            ontology_edits=self._ontology_edits,
            _ontologies_client=self._ontologies_client,
            _ontology_rid=self._ontology_rid,
            normalized_load=normalized_load,
            inspection_id=inspection_id,
            servo_load=servo_load,
            reading_id=reading_id,
            object_detected=object_detected,
            grip_state=grip_state,
            robot_id=robot_id,
            timestamp=timestamp,
        )
