#  (c) Copyright 2025 Palantir Technologies Inc. All rights reserved.
from typing import TYPE_CHECKING, ClassVar

from foundry_sdk_runtime.properties import Properties
from physical_ai_qa_cell_sdk.ontology._derived_properties._base_derived_property_builders import (
    BaseSensorDerivedPropertyBuilder,
)

if TYPE_CHECKING:
    from foundry_sdk_runtime.properties.property_types import BooleanObjectTypeProperty, StringObjectTypeProperty


class SensorObjectType:
    """Class used for filtering on Sensor ontology objects."""

    is_categorical: ClassVar["BooleanObjectTypeProperty"] = Properties.boolean("isCategorical")
    internal_interpolation: ClassVar["StringObjectTypeProperty"] = Properties.string("internalInterpolation")
    sensor_name1: ClassVar["StringObjectTypeProperty"] = Properties.string("sensorName1")
    sensor_type: ClassVar["StringObjectTypeProperty"] = Properties.string("sensorType")
    location: ClassVar["StringObjectTypeProperty"] = Properties.string("location")
    units: ClassVar["StringObjectTypeProperty"] = Properties.string("units")
    robot_id: ClassVar["StringObjectTypeProperty"] = Properties.string("robotId")
    sensor_type_id: ClassVar["StringObjectTypeProperty"] = Properties.string("sensorTypeId")
    sensor_id: ClassVar["StringObjectTypeProperty"] = Properties.string("sensorId")
    status: ClassVar["StringObjectTypeProperty"] = Properties.string("status")

    @property
    def derived(self) -> BaseSensorDerivedPropertyBuilder:
        return BaseSensorDerivedPropertyBuilder()
