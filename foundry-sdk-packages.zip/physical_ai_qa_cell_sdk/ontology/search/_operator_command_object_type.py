#  (c) Copyright 2025 Palantir Technologies Inc. All rights reserved.
from typing import TYPE_CHECKING, ClassVar

from foundry_sdk_runtime.properties import Properties
from physical_ai_qa_cell_sdk.ontology._derived_properties._base_derived_property_builders import (
    BaseOperatorCommandDerivedPropertyBuilder,
)

if TYPE_CHECKING:
    from foundry_sdk_runtime.properties.property_types import DateTimeObjectTypeProperty, StringObjectTypeProperty


class OperatorCommandObjectType:
    """Class used for filtering on OperatorCommand ontology objects."""

    created_at: ClassVar["DateTimeObjectTypeProperty"] = Properties.datetime("createdAt")
    command_type: ClassVar["StringObjectTypeProperty"] = Properties.string("commandType")
    executed_at: ClassVar["DateTimeObjectTypeProperty"] = Properties.datetime("executedAt")
    payload: ClassVar["StringObjectTypeProperty"] = Properties.string("payload")
    robot_id: ClassVar["StringObjectTypeProperty"] = Properties.string("robotId")
    command_id: ClassVar["StringObjectTypeProperty"] = Properties.string("commandId")
    status: ClassVar["StringObjectTypeProperty"] = Properties.string("status")

    @property
    def derived(self) -> BaseOperatorCommandDerivedPropertyBuilder:
        return BaseOperatorCommandDerivedPropertyBuilder()
