#  (c) Copyright 2025 Palantir Technologies Inc. All rights reserved.
from typing import TYPE_CHECKING, ClassVar

from foundry_sdk_runtime.properties import Properties
from physical_ai_qa_cell_sdk.ontology._derived_properties._base_derived_property_builders import (
    BaseRobotDerivedPropertyBuilder,
)

if TYPE_CHECKING:
    from foundry_sdk_runtime.properties.property_types import (
        DateTimeObjectTypeProperty,
        FloatObjectTypeProperty,
        IntegerObjectTypeProperty,
        StringObjectTypeProperty,
    )


class RobotObjectType:
    """Class used for filtering on Robot ontology objects."""

    last_heartbeat: ClassVar["DateTimeObjectTypeProperty"] = Properties.datetime("lastHeartbeat")
    current_model_version: ClassVar["StringObjectTypeProperty"] = Properties.string("currentModelVersion")
    name: ClassVar["StringObjectTypeProperty"] = Properties.string("name")
    total_inspections: ClassVar["IntegerObjectTypeProperty"] = Properties.integer("totalInspections")
    robot_id: ClassVar["StringObjectTypeProperty"] = Properties.string("robotId")
    grip_tolerance: ClassVar["FloatObjectTypeProperty"] = Properties.float("gripTolerance")
    status: ClassVar["StringObjectTypeProperty"] = Properties.string("status")

    @property
    def derived(self) -> BaseRobotDerivedPropertyBuilder:
        return BaseRobotDerivedPropertyBuilder()
