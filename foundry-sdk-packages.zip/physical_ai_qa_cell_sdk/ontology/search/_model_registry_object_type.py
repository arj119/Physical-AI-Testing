#  (c) Copyright 2025 Palantir Technologies Inc. All rights reserved.
from typing import TYPE_CHECKING, ClassVar

from foundry_sdk_runtime.properties import Properties
from physical_ai_qa_cell_sdk.ontology._derived_properties._base_derived_property_builders import (
    BaseModelRegistryDerivedPropertyBuilder,
)

if TYPE_CHECKING:
    from foundry_sdk_runtime.properties.property_types import (
        DateTimeObjectTypeProperty,
        FloatObjectTypeProperty,
        StringObjectTypeProperty,
    )


class ModelRegistryObjectType:
    """Class used for filtering on ModelRegistry ontology objects."""

    published_at: ClassVar["DateTimeObjectTypeProperty"] = Properties.datetime("publishedAt")
    model_id: ClassVar["StringObjectTypeProperty"] = Properties.string("modelId")
    accuracy: ClassVar["FloatObjectTypeProperty"] = Properties.float("accuracy")
    description: ClassVar["StringObjectTypeProperty"] = Properties.string("description")
    artifact_path: ClassVar["StringObjectTypeProperty"] = Properties.string("artifactPath")
    version: ClassVar["StringObjectTypeProperty"] = Properties.string("version")
    status: ClassVar["StringObjectTypeProperty"] = Properties.string("status")

    @property
    def derived(self) -> BaseModelRegistryDerivedPropertyBuilder:
        return BaseModelRegistryDerivedPropertyBuilder()
