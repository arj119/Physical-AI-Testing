#  (c) Copyright 2025 Palantir Technologies Inc. All rights reserved.
from typing import TYPE_CHECKING, ClassVar

from foundry_sdk_runtime.properties import Properties
from physical_ai_qa_cell_sdk.ontology._derived_properties._base_derived_property_builders import (
    BaseInspectionEventDerivedPropertyBuilder,
)

if TYPE_CHECKING:
    from foundry_sdk_runtime.properties.property_types import (
        BooleanObjectTypeProperty,
        DateTimeObjectTypeProperty,
        FloatObjectTypeProperty,
        IntegerObjectTypeProperty,
        StringObjectTypeProperty,
    )


class InspectionEventObjectType:
    """Class used for filtering on InspectionEvent ontology objects."""

    grip_load: ClassVar["FloatObjectTypeProperty"] = Properties.float("gripLoad")
    model_version: ClassVar["StringObjectTypeProperty"] = Properties.string("modelVersion")
    reviewed_at: ClassVar["DateTimeObjectTypeProperty"] = Properties.datetime("reviewedAt")
    final_decision: ClassVar["StringObjectTypeProperty"] = Properties.string("finalDecision")
    reviewed_by: ClassVar["StringObjectTypeProperty"] = Properties.string("reviewedBy")
    robot_id: ClassVar["StringObjectTypeProperty"] = Properties.string("robotId")
    fusion_decision: ClassVar["StringObjectTypeProperty"] = Properties.string("fusionDecision")
    inspection_id: ClassVar["StringObjectTypeProperty"] = Properties.string("inspectionId")
    vision_agrees: ClassVar["BooleanObjectTypeProperty"] = Properties.boolean("visionAgrees")
    operator_notes: ClassVar["StringObjectTypeProperty"] = Properties.string("operatorNotes")
    vision_confidence: ClassVar["FloatObjectTypeProperty"] = Properties.float("visionConfidence")
    review_status: ClassVar["StringObjectTypeProperty"] = Properties.string("reviewStatus")
    cycle_time_ms: ClassVar["IntegerObjectTypeProperty"] = Properties.integer("cycleTimeMs")
    vision_class: ClassVar["StringObjectTypeProperty"] = Properties.string("visionClass")
    fusion_reason: ClassVar["StringObjectTypeProperty"] = Properties.string("fusionReason")
    timestamp: ClassVar["DateTimeObjectTypeProperty"] = Properties.datetime("timestamp")

    @property
    def derived(self) -> BaseInspectionEventDerivedPropertyBuilder:
        return BaseInspectionEventDerivedPropertyBuilder()
