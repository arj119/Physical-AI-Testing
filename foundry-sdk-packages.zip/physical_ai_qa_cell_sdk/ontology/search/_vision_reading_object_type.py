#  (c) Copyright 2025 Palantir Technologies Inc. All rights reserved.
from typing import TYPE_CHECKING, ClassVar

from foundry_sdk_runtime.properties import Properties
from physical_ai_qa_cell_sdk.ontology._derived_properties._base_derived_property_builders import (
    BaseVisionReadingDerivedPropertyBuilder,
)

if TYPE_CHECKING:
    from foundry_sdk_runtime.properties.property_types import (
        ArrayObjectTypeProperty,
        DateTimeObjectTypeProperty,
        FloatObjectTypeProperty,
        IntegerObjectTypeProperty,
        StringObjectTypeProperty,
    )


class VisionReadingObjectType:
    """Class used for filtering on VisionReading ontology objects."""

    bounding_box: ClassVar["ArrayObjectTypeProperty"] = Properties.array(Properties.float("boundingBox"))
    inspection_id: ClassVar["StringObjectTypeProperty"] = Properties.string("inspectionId")
    inference_time_ms: ClassVar["IntegerObjectTypeProperty"] = Properties.integer("inferenceTimeMs")
    model_version: ClassVar["StringObjectTypeProperty"] = Properties.string("modelVersion")
    thumbnail_base64: ClassVar["StringObjectTypeProperty"] = Properties.string("thumbnailBase64")
    confidence: ClassVar["FloatObjectTypeProperty"] = Properties.float("confidence")
    reading_id: ClassVar["StringObjectTypeProperty"] = Properties.string("readingId")
    robot_id: ClassVar["StringObjectTypeProperty"] = Properties.string("robotId")
    detected_class: ClassVar["StringObjectTypeProperty"] = Properties.string("detectedClass")
    timestamp: ClassVar["DateTimeObjectTypeProperty"] = Properties.datetime("timestamp")

    @property
    def derived(self) -> BaseVisionReadingDerivedPropertyBuilder:
        return BaseVisionReadingDerivedPropertyBuilder()
