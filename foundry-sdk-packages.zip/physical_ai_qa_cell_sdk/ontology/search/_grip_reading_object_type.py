#  (c) Copyright 2025 Palantir Technologies Inc. All rights reserved.
from typing import TYPE_CHECKING, ClassVar

from foundry_sdk_runtime.properties import Properties
from physical_ai_qa_cell_sdk.ontology._derived_properties._base_derived_property_builders import (
    BaseGripReadingDerivedPropertyBuilder,
)

if TYPE_CHECKING:
    from foundry_sdk_runtime.properties.property_types import (
        BooleanObjectTypeProperty,
        DateTimeObjectTypeProperty,
        FloatObjectTypeProperty,
        StringObjectTypeProperty,
    )


class GripReadingObjectType:
    """Class used for filtering on GripReading ontology objects."""

    normalized_load: ClassVar["FloatObjectTypeProperty"] = Properties.float("normalizedLoad")
    inspection_id: ClassVar["StringObjectTypeProperty"] = Properties.string("inspectionId")
    servo_load: ClassVar["FloatObjectTypeProperty"] = Properties.float("servoLoad")
    reading_id: ClassVar["StringObjectTypeProperty"] = Properties.string("readingId")
    object_detected: ClassVar["BooleanObjectTypeProperty"] = Properties.boolean("objectDetected")
    grip_state: ClassVar["StringObjectTypeProperty"] = Properties.string("gripState")
    robot_id: ClassVar["StringObjectTypeProperty"] = Properties.string("robotId")
    timestamp: ClassVar["DateTimeObjectTypeProperty"] = Properties.datetime("timestamp")

    @property
    def derived(self) -> BaseGripReadingDerivedPropertyBuilder:
        return BaseGripReadingDerivedPropertyBuilder()
