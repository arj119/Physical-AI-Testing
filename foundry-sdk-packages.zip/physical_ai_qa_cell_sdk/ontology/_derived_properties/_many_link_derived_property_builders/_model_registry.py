#  (c) Copyright 2025 Palantir Technologies Inc. All rights reserved.
from typing import Optional

from foundry_sdk.v2.ontologies.models import (
    MethodObjectSet,
    ObjectSetFilterType,
    ObjectSetMethodInputType,
    SelectedPropertyCountAggregation,
    SelectedPropertyExpression,
)
from foundry_sdk_runtime.derived_properties import (
    ManyLinkDatetimeDerivedPropertyBuilder,
    ManyLinkFloatDerivedPropertyBuilder,
    ManyLinkGenericDerivedPropertyBuilder,
)
from foundry_sdk_runtime.properties import ObjectTypePropertyWithExpression
from foundry_sdk_runtime.search import SearchExpressionParser
from physical_ai_qa_cell_sdk.ontology._derived_properties._base_derived_property_builders import (
    BaseModelRegistryDerivedPropertyBuilder,
)


class ManyLinkModelRegistryDerivedPropertyBuilder(BaseModelRegistryDerivedPropertyBuilder):
    def __init__(self, object_set_type: Optional[MethodObjectSet] = None, property_name: Optional[str] = None):
        self._object_set_type = object_set_type or ObjectSetMethodInputType(type="methodInput")
        self._property_name = property_name

    @property
    def published_at(self) -> ManyLinkDatetimeDerivedPropertyBuilder:
        return ManyLinkDatetimeDerivedPropertyBuilder(
            object_set_type=self._object_set_type, property_name="publishedAt"
        )

    @property
    def model_id(self) -> ManyLinkGenericDerivedPropertyBuilder:
        return ManyLinkGenericDerivedPropertyBuilder(object_set_type=self._object_set_type, property_name="modelId")

    @property
    def accuracy(self) -> ManyLinkFloatDerivedPropertyBuilder:
        return ManyLinkFloatDerivedPropertyBuilder(object_set_type=self._object_set_type, property_name="accuracy")

    @property
    def description(self) -> ManyLinkGenericDerivedPropertyBuilder:
        return ManyLinkGenericDerivedPropertyBuilder(object_set_type=self._object_set_type, property_name="description")

    @property
    def model_artifact_ref(self) -> ManyLinkGenericDerivedPropertyBuilder:
        return ManyLinkGenericDerivedPropertyBuilder(
            object_set_type=self._object_set_type, property_name="modelArtifactRef"
        )

    @property
    def artifact_path(self) -> ManyLinkGenericDerivedPropertyBuilder:
        return ManyLinkGenericDerivedPropertyBuilder(
            object_set_type=self._object_set_type, property_name="artifactPath"
        )

    @property
    def version(self) -> ManyLinkGenericDerivedPropertyBuilder:
        return ManyLinkGenericDerivedPropertyBuilder(object_set_type=self._object_set_type, property_name="version")

    @property
    def status(self) -> ManyLinkGenericDerivedPropertyBuilder:
        return ManyLinkGenericDerivedPropertyBuilder(object_set_type=self._object_set_type, property_name="status")

    def count(self) -> SelectedPropertyExpression:
        return SelectedPropertyExpression(
            objectSet=self._object_set_type,
            operation=SelectedPropertyCountAggregation(type="count"),
            type="selection",
        )

    def where(self, expression: ObjectTypePropertyWithExpression) -> "ManyLinkModelRegistryDerivedPropertyBuilder":
        if not isinstance(expression, ObjectTypePropertyWithExpression):
            raise TypeError(
                "The provided expression isn't valid. Example of a valid expression: Object.object_type.<property> == 1"
            )
        query = SearchExpressionParser.visit(expression)
        return ManyLinkModelRegistryDerivedPropertyBuilder(
            object_set_type=ObjectSetFilterType(objectSet=self._object_set_type, where=query, type="filter"),
        )
