#  (c) Copyright 2025 Palantir Technologies Inc. All rights reserved.
from typing import TYPE_CHECKING, Optional

from foundry_sdk.v2.ontologies.models import (
    MethodObjectSet,
    ObjectSetFilterType,
    ObjectSetMethodInputType,
    ObjectSetSearchAroundType,
    SelectedPropertyCountAggregation,
    SelectedPropertyExpression,
)
from foundry_sdk_runtime.derived_properties import (
    ManyLinkDatetimeDerivedPropertyBuilder,
    ManyLinkFloatDerivedPropertyBuilder,
    ManyLinkGenericDerivedPropertyBuilder,
    ManyLinkIntegerDerivedPropertyBuilder,
)
from foundry_sdk_runtime.properties import ObjectTypePropertyWithExpression
from foundry_sdk_runtime.search import SearchExpressionParser
from physical_ai_qa_cell_sdk.ontology._derived_properties._base_derived_property_builders import (
    BaseRobotDerivedPropertyBuilder,
)

if TYPE_CHECKING:
    from physical_ai_qa_cell_sdk.ontology._derived_properties._many_link_derived_property_builders._grip_reading import (
        ManyLinkGripReadingDerivedPropertyBuilder,
    )
    from physical_ai_qa_cell_sdk.ontology._derived_properties._many_link_derived_property_builders._inspection_event import (
        ManyLinkInspectionEventDerivedPropertyBuilder,
    )
    from physical_ai_qa_cell_sdk.ontology._derived_properties._many_link_derived_property_builders._operator_command import (
        ManyLinkOperatorCommandDerivedPropertyBuilder,
    )
    from physical_ai_qa_cell_sdk.ontology._derived_properties._many_link_derived_property_builders._sensor import (
        ManyLinkSensorDerivedPropertyBuilder,
    )
    from physical_ai_qa_cell_sdk.ontology._derived_properties._many_link_derived_property_builders._vision_reading import (
        ManyLinkVisionReadingDerivedPropertyBuilder,
    )


class ManyLinkRobotDerivedPropertyBuilder(BaseRobotDerivedPropertyBuilder):
    def __init__(self, object_set_type: Optional[MethodObjectSet] = None, property_name: Optional[str] = None):
        self._object_set_type = object_set_type or ObjectSetMethodInputType(type="methodInput")
        self._property_name = property_name

    @property
    def last_heartbeat(self) -> ManyLinkDatetimeDerivedPropertyBuilder:
        return ManyLinkDatetimeDerivedPropertyBuilder(
            object_set_type=self._object_set_type, property_name="lastHeartbeat"
        )

    @property
    def current_model_version(self) -> ManyLinkGenericDerivedPropertyBuilder:
        return ManyLinkGenericDerivedPropertyBuilder(
            object_set_type=self._object_set_type, property_name="currentModelVersion"
        )

    @property
    def name(self) -> ManyLinkGenericDerivedPropertyBuilder:
        return ManyLinkGenericDerivedPropertyBuilder(object_set_type=self._object_set_type, property_name="name")

    @property
    def total_inspections(self) -> ManyLinkIntegerDerivedPropertyBuilder:
        return ManyLinkIntegerDerivedPropertyBuilder(
            object_set_type=self._object_set_type, property_name="totalInspections"
        )

    @property
    def robot_id(self) -> ManyLinkGenericDerivedPropertyBuilder:
        return ManyLinkGenericDerivedPropertyBuilder(object_set_type=self._object_set_type, property_name="robotId")

    @property
    def grip_tolerance(self) -> ManyLinkFloatDerivedPropertyBuilder:
        return ManyLinkFloatDerivedPropertyBuilder(object_set_type=self._object_set_type, property_name="gripTolerance")

    @property
    def status(self) -> ManyLinkGenericDerivedPropertyBuilder:
        return ManyLinkGenericDerivedPropertyBuilder(object_set_type=self._object_set_type, property_name="status")

    def count(self) -> SelectedPropertyExpression:
        return SelectedPropertyExpression(
            objectSet=self._object_set_type,
            operation=SelectedPropertyCountAggregation(type="count"),
            type="selection",
        )

    def where(self, expression: ObjectTypePropertyWithExpression) -> "ManyLinkRobotDerivedPropertyBuilder":
        if not isinstance(expression, ObjectTypePropertyWithExpression):
            raise TypeError(
                "The provided expression isn't valid. Example of a valid expression: Object.object_type.<property> == 1"
            )
        query = SearchExpressionParser.visit(expression)
        return ManyLinkRobotDerivedPropertyBuilder(
            object_set_type=ObjectSetFilterType(objectSet=self._object_set_type, where=query, type="filter"),
        )

    def grip_readings(self) -> "ManyLinkGripReadingDerivedPropertyBuilder":
        from physical_ai_qa_cell_sdk.ontology._derived_properties._many_link_derived_property_builders._grip_reading import (
            ManyLinkGripReadingDerivedPropertyBuilder,
        )

        return ManyLinkGripReadingDerivedPropertyBuilder(
            object_set_type=ObjectSetSearchAroundType(
                objectSet=self._object_set_type, link="gripReadings", type="searchAround"
            ),
        )

    def inspection_events(self) -> "ManyLinkInspectionEventDerivedPropertyBuilder":
        from physical_ai_qa_cell_sdk.ontology._derived_properties._many_link_derived_property_builders._inspection_event import (
            ManyLinkInspectionEventDerivedPropertyBuilder,
        )

        return ManyLinkInspectionEventDerivedPropertyBuilder(
            object_set_type=ObjectSetSearchAroundType(
                objectSet=self._object_set_type, link="inspectionEvents", type="searchAround"
            ),
        )

    def operator_commands(self) -> "ManyLinkOperatorCommandDerivedPropertyBuilder":
        from physical_ai_qa_cell_sdk.ontology._derived_properties._many_link_derived_property_builders._operator_command import (
            ManyLinkOperatorCommandDerivedPropertyBuilder,
        )

        return ManyLinkOperatorCommandDerivedPropertyBuilder(
            object_set_type=ObjectSetSearchAroundType(
                objectSet=self._object_set_type, link="operatorCommands", type="searchAround"
            ),
        )

    def sensors(self) -> "ManyLinkSensorDerivedPropertyBuilder":
        from physical_ai_qa_cell_sdk.ontology._derived_properties._many_link_derived_property_builders._sensor import (
            ManyLinkSensorDerivedPropertyBuilder,
        )

        return ManyLinkSensorDerivedPropertyBuilder(
            object_set_type=ObjectSetSearchAroundType(
                objectSet=self._object_set_type, link="sensors", type="searchAround"
            ),
        )

    def vision_readings(self) -> "ManyLinkVisionReadingDerivedPropertyBuilder":
        from physical_ai_qa_cell_sdk.ontology._derived_properties._many_link_derived_property_builders._vision_reading import (
            ManyLinkVisionReadingDerivedPropertyBuilder,
        )

        return ManyLinkVisionReadingDerivedPropertyBuilder(
            object_set_type=ObjectSetSearchAroundType(
                objectSet=self._object_set_type, link="visionReadings", type="searchAround"
            ),
        )
