#  (c) Copyright 2025 Palantir Technologies Inc. All rights reserved.
from typing import TYPE_CHECKING, Optional

from foundry_sdk.v2.ontologies.models import (
    MethodObjectSet,
    ObjectSetFilterType,
    ObjectSetMethodInputType,
    ObjectSetSearchAroundType,
    SelectedPropertyCountAggregation,
    SelectedPropertyExpression,
)
from foundry_sdk_runtime.derived_properties import (
    ManyLinkDatetimeDerivedPropertyBuilder,
    ManyLinkFloatDerivedPropertyBuilder,
    ManyLinkGenericDerivedPropertyBuilder,
)
from foundry_sdk_runtime.properties import ObjectTypePropertyWithExpression
from foundry_sdk_runtime.search import SearchExpressionParser
from physical_ai_qa_cell_sdk.ontology._derived_properties._base_derived_property_builders import (
    BaseGripReadingDerivedPropertyBuilder,
)

if TYPE_CHECKING:
    from physical_ai_qa_cell_sdk.ontology._derived_properties._many_link_derived_property_builders._inspection_event import (
        ManyLinkInspectionEventDerivedPropertyBuilder,
    )
    from physical_ai_qa_cell_sdk.ontology._derived_properties._many_link_derived_property_builders._robot import (
        ManyLinkRobotDerivedPropertyBuilder,
    )


class ManyLinkGripReadingDerivedPropertyBuilder(BaseGripReadingDerivedPropertyBuilder):
    def __init__(self, object_set_type: Optional[MethodObjectSet] = None, property_name: Optional[str] = None):
        self._object_set_type = object_set_type or ObjectSetMethodInputType(type="methodInput")
        self._property_name = property_name

    @property
    def normalized_load(self) -> ManyLinkFloatDerivedPropertyBuilder:
        return ManyLinkFloatDerivedPropertyBuilder(
            object_set_type=self._object_set_type, property_name="normalizedLoad"
        )

    @property
    def inspection_id(self) -> ManyLinkGenericDerivedPropertyBuilder:
        return ManyLinkGenericDerivedPropertyBuilder(
            object_set_type=self._object_set_type, property_name="inspectionId"
        )

    @property
    def servo_load(self) -> ManyLinkFloatDerivedPropertyBuilder:
        return ManyLinkFloatDerivedPropertyBuilder(object_set_type=self._object_set_type, property_name="servoLoad")

    @property
    def reading_id(self) -> ManyLinkGenericDerivedPropertyBuilder:
        return ManyLinkGenericDerivedPropertyBuilder(object_set_type=self._object_set_type, property_name="readingId")

    @property
    def object_detected(self) -> ManyLinkGenericDerivedPropertyBuilder:
        return ManyLinkGenericDerivedPropertyBuilder(
            object_set_type=self._object_set_type, property_name="objectDetected"
        )

    @property
    def grip_state(self) -> ManyLinkGenericDerivedPropertyBuilder:
        return ManyLinkGenericDerivedPropertyBuilder(object_set_type=self._object_set_type, property_name="gripState")

    @property
    def robot_id(self) -> ManyLinkGenericDerivedPropertyBuilder:
        return ManyLinkGenericDerivedPropertyBuilder(object_set_type=self._object_set_type, property_name="robotId")

    @property
    def timestamp(self) -> ManyLinkDatetimeDerivedPropertyBuilder:
        return ManyLinkDatetimeDerivedPropertyBuilder(object_set_type=self._object_set_type, property_name="timestamp")

    def count(self) -> SelectedPropertyExpression:
        return SelectedPropertyExpression(
            objectSet=self._object_set_type,
            operation=SelectedPropertyCountAggregation(type="count"),
            type="selection",
        )

    def where(self, expression: ObjectTypePropertyWithExpression) -> "ManyLinkGripReadingDerivedPropertyBuilder":
        if not isinstance(expression, ObjectTypePropertyWithExpression):
            raise TypeError(
                "The provided expression isn't valid. Example of a valid expression: Object.object_type.<property> == 1"
            )
        query = SearchExpressionParser.visit(expression)
        return ManyLinkGripReadingDerivedPropertyBuilder(
            object_set_type=ObjectSetFilterType(objectSet=self._object_set_type, where=query, type="filter"),
        )

    def inspection_event(self) -> "ManyLinkInspectionEventDerivedPropertyBuilder":
        from physical_ai_qa_cell_sdk.ontology._derived_properties._many_link_derived_property_builders._inspection_event import (
            ManyLinkInspectionEventDerivedPropertyBuilder,
        )

        return ManyLinkInspectionEventDerivedPropertyBuilder(
            object_set_type=ObjectSetSearchAroundType(
                objectSet=self._object_set_type, link="inspectionEvent", type="searchAround"
            ),
        )

    def robot(self) -> "ManyLinkRobotDerivedPropertyBuilder":
        from physical_ai_qa_cell_sdk.ontology._derived_properties._many_link_derived_property_builders._robot import (
            ManyLinkRobotDerivedPropertyBuilder,
        )

        return ManyLinkRobotDerivedPropertyBuilder(
            object_set_type=ObjectSetSearchAroundType(
                objectSet=self._object_set_type, link="robot", type="searchAround"
            ),
        )
