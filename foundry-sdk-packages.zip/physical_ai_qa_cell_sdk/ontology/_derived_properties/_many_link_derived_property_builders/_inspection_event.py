#  (c) Copyright 2025 Palantir Technologies Inc. All rights reserved.
from typing import TYPE_CHECKING, Optional

from foundry_sdk.v2.ontologies.models import (
    MethodObjectSet,
    ObjectSetFilterType,
    ObjectSetMethodInputType,
    ObjectSetSearchAroundType,
    SelectedPropertyCountAggregation,
    SelectedPropertyExpression,
)
from foundry_sdk_runtime.derived_properties import (
    ManyLinkDatetimeDerivedPropertyBuilder,
    ManyLinkFloatDerivedPropertyBuilder,
    ManyLinkGenericDerivedPropertyBuilder,
    ManyLinkIntegerDerivedPropertyBuilder,
)
from foundry_sdk_runtime.properties import ObjectTypePropertyWithExpression
from foundry_sdk_runtime.search import SearchExpressionParser
from physical_ai_qa_cell_sdk.ontology._derived_properties._base_derived_property_builders import (
    BaseInspectionEventDerivedPropertyBuilder,
)

if TYPE_CHECKING:
    from physical_ai_qa_cell_sdk.ontology._derived_properties._many_link_derived_property_builders._grip_reading import (
        ManyLinkGripReadingDerivedPropertyBuilder,
    )
    from physical_ai_qa_cell_sdk.ontology._derived_properties._many_link_derived_property_builders._robot import (
        ManyLinkRobotDerivedPropertyBuilder,
    )
    from physical_ai_qa_cell_sdk.ontology._derived_properties._many_link_derived_property_builders._vision_reading import (
        ManyLinkVisionReadingDerivedPropertyBuilder,
    )


class ManyLinkInspectionEventDerivedPropertyBuilder(BaseInspectionEventDerivedPropertyBuilder):
    def __init__(self, object_set_type: Optional[MethodObjectSet] = None, property_name: Optional[str] = None):
        self._object_set_type = object_set_type or ObjectSetMethodInputType(type="methodInput")
        self._property_name = property_name

    @property
    def grip_load(self) -> ManyLinkFloatDerivedPropertyBuilder:
        return ManyLinkFloatDerivedPropertyBuilder(object_set_type=self._object_set_type, property_name="gripLoad")

    @property
    def model_version(self) -> ManyLinkGenericDerivedPropertyBuilder:
        return ManyLinkGenericDerivedPropertyBuilder(
            object_set_type=self._object_set_type, property_name="modelVersion"
        )

    @property
    def reviewed_at(self) -> ManyLinkDatetimeDerivedPropertyBuilder:
        return ManyLinkDatetimeDerivedPropertyBuilder(object_set_type=self._object_set_type, property_name="reviewedAt")

    @property
    def final_decision(self) -> ManyLinkGenericDerivedPropertyBuilder:
        return ManyLinkGenericDerivedPropertyBuilder(
            object_set_type=self._object_set_type, property_name="finalDecision"
        )

    @property
    def reviewed_by(self) -> ManyLinkGenericDerivedPropertyBuilder:
        return ManyLinkGenericDerivedPropertyBuilder(object_set_type=self._object_set_type, property_name="reviewedBy")

    @property
    def robot_id(self) -> ManyLinkGenericDerivedPropertyBuilder:
        return ManyLinkGenericDerivedPropertyBuilder(object_set_type=self._object_set_type, property_name="robotId")

    @property
    def fusion_decision(self) -> ManyLinkGenericDerivedPropertyBuilder:
        return ManyLinkGenericDerivedPropertyBuilder(
            object_set_type=self._object_set_type, property_name="fusionDecision"
        )

    @property
    def inspection_id(self) -> ManyLinkGenericDerivedPropertyBuilder:
        return ManyLinkGenericDerivedPropertyBuilder(
            object_set_type=self._object_set_type, property_name="inspectionId"
        )

    @property
    def vision_agrees(self) -> ManyLinkGenericDerivedPropertyBuilder:
        return ManyLinkGenericDerivedPropertyBuilder(
            object_set_type=self._object_set_type, property_name="visionAgrees"
        )

    @property
    def operator_notes(self) -> ManyLinkGenericDerivedPropertyBuilder:
        return ManyLinkGenericDerivedPropertyBuilder(
            object_set_type=self._object_set_type, property_name="operatorNotes"
        )

    @property
    def vision_confidence(self) -> ManyLinkFloatDerivedPropertyBuilder:
        return ManyLinkFloatDerivedPropertyBuilder(
            object_set_type=self._object_set_type, property_name="visionConfidence"
        )

    @property
    def captured_image_ref(self) -> ManyLinkGenericDerivedPropertyBuilder:
        return ManyLinkGenericDerivedPropertyBuilder(
            object_set_type=self._object_set_type, property_name="capturedImageRef"
        )

    @property
    def review_status(self) -> ManyLinkGenericDerivedPropertyBuilder:
        return ManyLinkGenericDerivedPropertyBuilder(
            object_set_type=self._object_set_type, property_name="reviewStatus"
        )

    @property
    def cycle_time_ms(self) -> ManyLinkIntegerDerivedPropertyBuilder:
        return ManyLinkIntegerDerivedPropertyBuilder(object_set_type=self._object_set_type, property_name="cycleTimeMs")

    @property
    def vision_class(self) -> ManyLinkGenericDerivedPropertyBuilder:
        return ManyLinkGenericDerivedPropertyBuilder(object_set_type=self._object_set_type, property_name="visionClass")

    @property
    def fusion_reason(self) -> ManyLinkGenericDerivedPropertyBuilder:
        return ManyLinkGenericDerivedPropertyBuilder(
            object_set_type=self._object_set_type, property_name="fusionReason"
        )

    @property
    def timestamp(self) -> ManyLinkDatetimeDerivedPropertyBuilder:
        return ManyLinkDatetimeDerivedPropertyBuilder(object_set_type=self._object_set_type, property_name="timestamp")

    def count(self) -> SelectedPropertyExpression:
        return SelectedPropertyExpression(
            objectSet=self._object_set_type,
            operation=SelectedPropertyCountAggregation(type="count"),
            type="selection",
        )

    def where(self, expression: ObjectTypePropertyWithExpression) -> "ManyLinkInspectionEventDerivedPropertyBuilder":
        if not isinstance(expression, ObjectTypePropertyWithExpression):
            raise TypeError(
                "The provided expression isn't valid. Example of a valid expression: Object.object_type.<property> == 1"
            )
        query = SearchExpressionParser.visit(expression)
        return ManyLinkInspectionEventDerivedPropertyBuilder(
            object_set_type=ObjectSetFilterType(objectSet=self._object_set_type, where=query, type="filter"),
        )

    def grip_readings(self) -> "ManyLinkGripReadingDerivedPropertyBuilder":
        from physical_ai_qa_cell_sdk.ontology._derived_properties._many_link_derived_property_builders._grip_reading import (
            ManyLinkGripReadingDerivedPropertyBuilder,
        )

        return ManyLinkGripReadingDerivedPropertyBuilder(
            object_set_type=ObjectSetSearchAroundType(
                objectSet=self._object_set_type, link="gripReadings", type="searchAround"
            ),
        )

    def inspection_vision_readings(self) -> "ManyLinkVisionReadingDerivedPropertyBuilder":
        from physical_ai_qa_cell_sdk.ontology._derived_properties._many_link_derived_property_builders._vision_reading import (
            ManyLinkVisionReadingDerivedPropertyBuilder,
        )

        return ManyLinkVisionReadingDerivedPropertyBuilder(
            object_set_type=ObjectSetSearchAroundType(
                objectSet=self._object_set_type, link="inspectionVisionReadings", type="searchAround"
            ),
        )

    def robot(self) -> "ManyLinkRobotDerivedPropertyBuilder":
        from physical_ai_qa_cell_sdk.ontology._derived_properties._many_link_derived_property_builders._robot import (
            ManyLinkRobotDerivedPropertyBuilder,
        )

        return ManyLinkRobotDerivedPropertyBuilder(
            object_set_type=ObjectSetSearchAroundType(
                objectSet=self._object_set_type, link="robot", type="searchAround"
            ),
        )
