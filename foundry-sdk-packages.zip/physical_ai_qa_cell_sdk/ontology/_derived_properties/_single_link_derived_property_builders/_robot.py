#  (c) Copyright 2025 Palantir Technologies Inc. All rights reserved.
from typing import TYPE_CHECKING, Optional

from foundry_sdk.v2.ontologies.models import (
    MethodObjectSet,
    ObjectSetFilterType,
    ObjectSetMethodInputType,
    ObjectSetSearchAroundType,
    SelectedPropertyCountAggregation,
    SelectedPropertyExpression,
)
from foundry_sdk_runtime.derived_properties import (
    SingleLinkDatetimeDerivedPropertyBuilder,
    SingleLinkFloatDerivedPropertyBuilder,
    SingleLinkGenericDerivedPropertyBuilder,
    SingleLinkIntegerDerivedPropertyBuilder,
)
from foundry_sdk_runtime.properties import ObjectTypePropertyWithExpression
from foundry_sdk_runtime.search import SearchExpressionParser

if TYPE_CHECKING:
    pass


class SingleLinkRobotDerivedPropertyBuilder:
    def __init__(
        self,
        object_set_type: Optional[MethodObjectSet] = None,
    ):
        self._object_set_type = object_set_type or ObjectSetMethodInputType(type="methodInput")

    @property
    def last_heartbeat(self) -> SingleLinkDatetimeDerivedPropertyBuilder:
        return SingleLinkDatetimeDerivedPropertyBuilder(
            object_set_type=self._object_set_type, property_name="lastHeartbeat"
        )

    @property
    def current_model_version(self) -> SingleLinkGenericDerivedPropertyBuilder:
        return SingleLinkGenericDerivedPropertyBuilder(
            object_set_type=self._object_set_type, property_name="currentModelVersion"
        )

    @property
    def name(self) -> SingleLinkGenericDerivedPropertyBuilder:
        return SingleLinkGenericDerivedPropertyBuilder(object_set_type=self._object_set_type, property_name="name")

    @property
    def total_inspections(self) -> SingleLinkIntegerDerivedPropertyBuilder:
        return SingleLinkIntegerDerivedPropertyBuilder(
            object_set_type=self._object_set_type, property_name="totalInspections"
        )

    @property
    def robot_id(self) -> SingleLinkGenericDerivedPropertyBuilder:
        return SingleLinkGenericDerivedPropertyBuilder(object_set_type=self._object_set_type, property_name="robotId")

    @property
    def grip_tolerance(self) -> SingleLinkFloatDerivedPropertyBuilder:
        return SingleLinkFloatDerivedPropertyBuilder(
            object_set_type=self._object_set_type, property_name="gripTolerance"
        )

    @property
    def status(self) -> SingleLinkGenericDerivedPropertyBuilder:
        return SingleLinkGenericDerivedPropertyBuilder(object_set_type=self._object_set_type, property_name="status")

    def grip_readings(self) -> "GripReadingDerivedPropertyBuilder":
        from physical_ai_qa_cell_sdk.ontology._derived_properties._many_link_derived_property_builders._grip_reading import (
            ManyLinkGripReadingDerivedPropertyBuilder,
        )

        return ManyLinkGripReadingDerivedPropertyBuilder(
            object_set_type=ObjectSetSearchAroundType(
                objectSet=self._object_set_type, link="gripReadings", type="searchAround"
            ),
        )

    def inspection_events(self) -> "InspectionEventDerivedPropertyBuilder":
        from physical_ai_qa_cell_sdk.ontology._derived_properties._many_link_derived_property_builders._inspection_event import (
            ManyLinkInspectionEventDerivedPropertyBuilder,
        )

        return ManyLinkInspectionEventDerivedPropertyBuilder(
            object_set_type=ObjectSetSearchAroundType(
                objectSet=self._object_set_type, link="inspectionEvents", type="searchAround"
            ),
        )

    def operator_commands(self) -> "OperatorCommandDerivedPropertyBuilder":
        from physical_ai_qa_cell_sdk.ontology._derived_properties._many_link_derived_property_builders._operator_command import (
            ManyLinkOperatorCommandDerivedPropertyBuilder,
        )

        return ManyLinkOperatorCommandDerivedPropertyBuilder(
            object_set_type=ObjectSetSearchAroundType(
                objectSet=self._object_set_type, link="operatorCommands", type="searchAround"
            ),
        )

    def sensors(self) -> "SensorDerivedPropertyBuilder":
        from physical_ai_qa_cell_sdk.ontology._derived_properties._many_link_derived_property_builders._sensor import (
            ManyLinkSensorDerivedPropertyBuilder,
        )

        return ManyLinkSensorDerivedPropertyBuilder(
            object_set_type=ObjectSetSearchAroundType(
                objectSet=self._object_set_type, link="sensors", type="searchAround"
            ),
        )

    def vision_readings(self) -> "VisionReadingDerivedPropertyBuilder":
        from physical_ai_qa_cell_sdk.ontology._derived_properties._many_link_derived_property_builders._vision_reading import (
            ManyLinkVisionReadingDerivedPropertyBuilder,
        )

        return ManyLinkVisionReadingDerivedPropertyBuilder(
            object_set_type=ObjectSetSearchAroundType(
                objectSet=self._object_set_type, link="visionReadings", type="searchAround"
            ),
        )

    def count(self) -> SelectedPropertyExpression:
        return SelectedPropertyExpression(
            objectSet=self._object_set_type,
            operation=SelectedPropertyCountAggregation(type="count"),
            type="selection",
        )

    def where(self, expression: ObjectTypePropertyWithExpression) -> "SingleLinkRobotDerivedPropertyBuilder":
        if not isinstance(expression, ObjectTypePropertyWithExpression):
            raise TypeError(
                "The provided expression isn't valid. Example of a valid expression: Object.object_type.<property> == 1"
            )
        query = SearchExpressionParser.visit(expression)
        return SingleLinkRobotDerivedPropertyBuilder(
            object_set_type=ObjectSetFilterType(objectSet=self._object_set_type, where=query, type="filter"),
        )
