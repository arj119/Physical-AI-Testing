#  (c) Copyright 2025 Palantir Technologies Inc. All rights reserved.
from typing import TYPE_CHECKING, Optional

from foundry_sdk.v2.ontologies.models import (
    MethodObjectSet,
    ObjectSetFilterType,
    ObjectSetMethodInputType,
    ObjectSetSearchAroundType,
    SelectedPropertyCountAggregation,
    SelectedPropertyExpression,
)
from foundry_sdk_runtime.derived_properties import (
    SingleLinkDatetimeDerivedPropertyBuilder,
    SingleLinkFloatDerivedPropertyBuilder,
    SingleLinkGenericDerivedPropertyBuilder,
    SingleLinkIntegerDerivedPropertyBuilder,
)
from foundry_sdk_runtime.properties import ObjectTypePropertyWithExpression
from foundry_sdk_runtime.search import SearchExpressionParser

if TYPE_CHECKING:
    from physical_ai_qa_cell_sdk.ontology._derived_properties._single_link_derived_property_builders._inspection_event import (
        SingleLinkInspectionEventDerivedPropertyBuilder,
    )
    from physical_ai_qa_cell_sdk.ontology._derived_properties._single_link_derived_property_builders._robot import (
        SingleLinkRobotDerivedPropertyBuilder,
    )


class SingleLinkVisionReadingDerivedPropertyBuilder:
    def __init__(
        self,
        object_set_type: Optional[MethodObjectSet] = None,
    ):
        self._object_set_type = object_set_type or ObjectSetMethodInputType(type="methodInput")

    @property
    def bounding_box(self) -> SingleLinkGenericDerivedPropertyBuilder:
        return SingleLinkGenericDerivedPropertyBuilder(
            object_set_type=self._object_set_type, property_name="boundingBox"
        )

    @property
    def inspection_id(self) -> SingleLinkGenericDerivedPropertyBuilder:
        return SingleLinkGenericDerivedPropertyBuilder(
            object_set_type=self._object_set_type, property_name="inspectionId"
        )

    @property
    def inference_time_ms(self) -> SingleLinkIntegerDerivedPropertyBuilder:
        return SingleLinkIntegerDerivedPropertyBuilder(
            object_set_type=self._object_set_type, property_name="inferenceTimeMs"
        )

    @property
    def model_version(self) -> SingleLinkGenericDerivedPropertyBuilder:
        return SingleLinkGenericDerivedPropertyBuilder(
            object_set_type=self._object_set_type, property_name="modelVersion"
        )

    @property
    def thumbnail_base64(self) -> SingleLinkGenericDerivedPropertyBuilder:
        return SingleLinkGenericDerivedPropertyBuilder(
            object_set_type=self._object_set_type, property_name="thumbnailBase64"
        )

    @property
    def confidence(self) -> SingleLinkFloatDerivedPropertyBuilder:
        return SingleLinkFloatDerivedPropertyBuilder(object_set_type=self._object_set_type, property_name="confidence")

    @property
    def reading_id(self) -> SingleLinkGenericDerivedPropertyBuilder:
        return SingleLinkGenericDerivedPropertyBuilder(object_set_type=self._object_set_type, property_name="readingId")

    @property
    def robot_id(self) -> SingleLinkGenericDerivedPropertyBuilder:
        return SingleLinkGenericDerivedPropertyBuilder(object_set_type=self._object_set_type, property_name="robotId")

    @property
    def detected_class(self) -> SingleLinkGenericDerivedPropertyBuilder:
        return SingleLinkGenericDerivedPropertyBuilder(
            object_set_type=self._object_set_type, property_name="detectedClass"
        )

    @property
    def timestamp(self) -> SingleLinkDatetimeDerivedPropertyBuilder:
        return SingleLinkDatetimeDerivedPropertyBuilder(
            object_set_type=self._object_set_type, property_name="timestamp"
        )

    def inspection_event(self) -> "SingleLinkInspectionEventDerivedPropertyBuilder":
        from physical_ai_qa_cell_sdk.ontology._derived_properties._single_link_derived_property_builders._inspection_event import (
            SingleLinkInspectionEventDerivedPropertyBuilder,
        )

        return SingleLinkInspectionEventDerivedPropertyBuilder(
            object_set_type=ObjectSetSearchAroundType(
                objectSet=self._object_set_type, link="inspectionEvent", type="searchAround"
            ),
        )

    def robot(self) -> "SingleLinkRobotDerivedPropertyBuilder":
        from physical_ai_qa_cell_sdk.ontology._derived_properties._single_link_derived_property_builders._robot import (
            SingleLinkRobotDerivedPropertyBuilder,
        )

        return SingleLinkRobotDerivedPropertyBuilder(
            object_set_type=ObjectSetSearchAroundType(
                objectSet=self._object_set_type, link="robot", type="searchAround"
            ),
        )

    def count(self) -> SelectedPropertyExpression:
        return SelectedPropertyExpression(
            objectSet=self._object_set_type,
            operation=SelectedPropertyCountAggregation(type="count"),
            type="selection",
        )

    def where(self, expression: ObjectTypePropertyWithExpression) -> "SingleLinkVisionReadingDerivedPropertyBuilder":
        if not isinstance(expression, ObjectTypePropertyWithExpression):
            raise TypeError(
                "The provided expression isn't valid. Example of a valid expression: Object.object_type.<property> == 1"
            )
        query = SearchExpressionParser.visit(expression)
        return SingleLinkVisionReadingDerivedPropertyBuilder(
            object_set_type=ObjectSetFilterType(objectSet=self._object_set_type, where=query, type="filter"),
        )
