#  (c) Copyright 2025 Palantir Technologies Inc. All rights reserved.
from typing import TYPE_CHECKING, Optional

from foundry_sdk.v2.ontologies.models import (
    MethodObjectSet,
    ObjectSetFilterType,
    ObjectSetMethodInputType,
    ObjectSetSearchAroundType,
    SelectedPropertyCountAggregation,
    SelectedPropertyExpression,
)
from foundry_sdk_runtime.derived_properties import (
    SingleLinkDatetimeDerivedPropertyBuilder,
    SingleLinkFloatDerivedPropertyBuilder,
    SingleLinkGenericDerivedPropertyBuilder,
)
from foundry_sdk_runtime.properties import ObjectTypePropertyWithExpression
from foundry_sdk_runtime.search import SearchExpressionParser

if TYPE_CHECKING:
    from physical_ai_qa_cell_sdk.ontology._derived_properties._single_link_derived_property_builders._inspection_event import (
        SingleLinkInspectionEventDerivedPropertyBuilder,
    )
    from physical_ai_qa_cell_sdk.ontology._derived_properties._single_link_derived_property_builders._robot import (
        SingleLinkRobotDerivedPropertyBuilder,
    )


class SingleLinkGripReadingDerivedPropertyBuilder:
    def __init__(
        self,
        object_set_type: Optional[MethodObjectSet] = None,
    ):
        self._object_set_type = object_set_type or ObjectSetMethodInputType(type="methodInput")

    @property
    def normalized_load(self) -> SingleLinkFloatDerivedPropertyBuilder:
        return SingleLinkFloatDerivedPropertyBuilder(
            object_set_type=self._object_set_type, property_name="normalizedLoad"
        )

    @property
    def inspection_id(self) -> SingleLinkGenericDerivedPropertyBuilder:
        return SingleLinkGenericDerivedPropertyBuilder(
            object_set_type=self._object_set_type, property_name="inspectionId"
        )

    @property
    def servo_load(self) -> SingleLinkFloatDerivedPropertyBuilder:
        return SingleLinkFloatDerivedPropertyBuilder(object_set_type=self._object_set_type, property_name="servoLoad")

    @property
    def reading_id(self) -> SingleLinkGenericDerivedPropertyBuilder:
        return SingleLinkGenericDerivedPropertyBuilder(object_set_type=self._object_set_type, property_name="readingId")

    @property
    def object_detected(self) -> SingleLinkGenericDerivedPropertyBuilder:
        return SingleLinkGenericDerivedPropertyBuilder(
            object_set_type=self._object_set_type, property_name="objectDetected"
        )

    @property
    def grip_state(self) -> SingleLinkGenericDerivedPropertyBuilder:
        return SingleLinkGenericDerivedPropertyBuilder(object_set_type=self._object_set_type, property_name="gripState")

    @property
    def robot_id(self) -> SingleLinkGenericDerivedPropertyBuilder:
        return SingleLinkGenericDerivedPropertyBuilder(object_set_type=self._object_set_type, property_name="robotId")

    @property
    def timestamp(self) -> SingleLinkDatetimeDerivedPropertyBuilder:
        return SingleLinkDatetimeDerivedPropertyBuilder(
            object_set_type=self._object_set_type, property_name="timestamp"
        )

    def inspection_event(self) -> "SingleLinkInspectionEventDerivedPropertyBuilder":
        from physical_ai_qa_cell_sdk.ontology._derived_properties._single_link_derived_property_builders._inspection_event import (
            SingleLinkInspectionEventDerivedPropertyBuilder,
        )

        return SingleLinkInspectionEventDerivedPropertyBuilder(
            object_set_type=ObjectSetSearchAroundType(
                objectSet=self._object_set_type, link="inspectionEvent", type="searchAround"
            ),
        )

    def robot(self) -> "SingleLinkRobotDerivedPropertyBuilder":
        from physical_ai_qa_cell_sdk.ontology._derived_properties._single_link_derived_property_builders._robot import (
            SingleLinkRobotDerivedPropertyBuilder,
        )

        return SingleLinkRobotDerivedPropertyBuilder(
            object_set_type=ObjectSetSearchAroundType(
                objectSet=self._object_set_type, link="robot", type="searchAround"
            ),
        )

    def count(self) -> SelectedPropertyExpression:
        return SelectedPropertyExpression(
            objectSet=self._object_set_type,
            operation=SelectedPropertyCountAggregation(type="count"),
            type="selection",
        )

    def where(self, expression: ObjectTypePropertyWithExpression) -> "SingleLinkGripReadingDerivedPropertyBuilder":
        if not isinstance(expression, ObjectTypePropertyWithExpression):
            raise TypeError(
                "The provided expression isn't valid. Example of a valid expression: Object.object_type.<property> == 1"
            )
        query = SearchExpressionParser.visit(expression)
        return SingleLinkGripReadingDerivedPropertyBuilder(
            object_set_type=ObjectSetFilterType(objectSet=self._object_set_type, where=query, type="filter"),
        )
