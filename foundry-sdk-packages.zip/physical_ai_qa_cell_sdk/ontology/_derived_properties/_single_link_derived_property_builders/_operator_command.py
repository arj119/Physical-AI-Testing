#  (c) Copyright 2025 Palantir Technologies Inc. All rights reserved.
from typing import TYPE_CHECKING, Optional

from foundry_sdk.v2.ontologies.models import (
    MethodObjectSet,
    ObjectSetFilterType,
    ObjectSetMethodInputType,
    ObjectSetSearchAroundType,
    SelectedPropertyCountAggregation,
    SelectedPropertyExpression,
)
from foundry_sdk_runtime.derived_properties import (
    SingleLinkDatetimeDerivedPropertyBuilder,
    SingleLinkGenericDerivedPropertyBuilder,
)
from foundry_sdk_runtime.properties import ObjectTypePropertyWithExpression
from foundry_sdk_runtime.search import SearchExpressionParser

if TYPE_CHECKING:
    from physical_ai_qa_cell_sdk.ontology._derived_properties._single_link_derived_property_builders._robot import (
        SingleLinkRobotDerivedPropertyBuilder,
    )


class SingleLinkOperatorCommandDerivedPropertyBuilder:
    def __init__(
        self,
        object_set_type: Optional[MethodObjectSet] = None,
    ):
        self._object_set_type = object_set_type or ObjectSetMethodInputType(type="methodInput")

    @property
    def created_at(self) -> SingleLinkDatetimeDerivedPropertyBuilder:
        return SingleLinkDatetimeDerivedPropertyBuilder(
            object_set_type=self._object_set_type, property_name="createdAt"
        )

    @property
    def command_type(self) -> SingleLinkGenericDerivedPropertyBuilder:
        return SingleLinkGenericDerivedPropertyBuilder(
            object_set_type=self._object_set_type, property_name="commandType"
        )

    @property
    def executed_at(self) -> SingleLinkDatetimeDerivedPropertyBuilder:
        return SingleLinkDatetimeDerivedPropertyBuilder(
            object_set_type=self._object_set_type, property_name="executedAt"
        )

    @property
    def payload(self) -> SingleLinkGenericDerivedPropertyBuilder:
        return SingleLinkGenericDerivedPropertyBuilder(object_set_type=self._object_set_type, property_name="payload")

    @property
    def robot_id(self) -> SingleLinkGenericDerivedPropertyBuilder:
        return SingleLinkGenericDerivedPropertyBuilder(object_set_type=self._object_set_type, property_name="robotId")

    @property
    def command_id(self) -> SingleLinkGenericDerivedPropertyBuilder:
        return SingleLinkGenericDerivedPropertyBuilder(object_set_type=self._object_set_type, property_name="commandId")

    @property
    def status(self) -> SingleLinkGenericDerivedPropertyBuilder:
        return SingleLinkGenericDerivedPropertyBuilder(object_set_type=self._object_set_type, property_name="status")

    def target_robot(self) -> "SingleLinkRobotDerivedPropertyBuilder":
        from physical_ai_qa_cell_sdk.ontology._derived_properties._single_link_derived_property_builders._robot import (
            SingleLinkRobotDerivedPropertyBuilder,
        )

        return SingleLinkRobotDerivedPropertyBuilder(
            object_set_type=ObjectSetSearchAroundType(
                objectSet=self._object_set_type, link="targetRobot", type="searchAround"
            ),
        )

    def count(self) -> SelectedPropertyExpression:
        return SelectedPropertyExpression(
            objectSet=self._object_set_type,
            operation=SelectedPropertyCountAggregation(type="count"),
            type="selection",
        )

    def where(self, expression: ObjectTypePropertyWithExpression) -> "SingleLinkOperatorCommandDerivedPropertyBuilder":
        if not isinstance(expression, ObjectTypePropertyWithExpression):
            raise TypeError(
                "The provided expression isn't valid. Example of a valid expression: Object.object_type.<property> == 1"
            )
        query = SearchExpressionParser.visit(expression)
        return SingleLinkOperatorCommandDerivedPropertyBuilder(
            object_set_type=ObjectSetFilterType(objectSet=self._object_set_type, where=query, type="filter"),
        )
