#  (c) Copyright 2025 Palantir Technologies Inc. All rights reserved.
from typing import TYPE_CHECKING, Optional

from foundry_sdk.v2.ontologies.models import (
    MethodObjectSet,
    ObjectSetFilterType,
    ObjectSetMethodInputType,
    ObjectSetSearchAroundType,
    SelectedPropertyCountAggregation,
    SelectedPropertyExpression,
)
from foundry_sdk_runtime.derived_properties import (
    SingleLinkDatetimeDerivedPropertyBuilder,
    SingleLinkFloatDerivedPropertyBuilder,
    SingleLinkGenericDerivedPropertyBuilder,
    SingleLinkIntegerDerivedPropertyBuilder,
)
from foundry_sdk_runtime.properties import ObjectTypePropertyWithExpression
from foundry_sdk_runtime.search import SearchExpressionParser

if TYPE_CHECKING:
    from physical_ai_qa_cell_sdk.ontology._derived_properties._single_link_derived_property_builders._robot import (
        SingleLinkRobotDerivedPropertyBuilder,
    )


class SingleLinkInspectionEventDerivedPropertyBuilder:
    def __init__(
        self,
        object_set_type: Optional[MethodObjectSet] = None,
    ):
        self._object_set_type = object_set_type or ObjectSetMethodInputType(type="methodInput")

    @property
    def grip_load(self) -> SingleLinkFloatDerivedPropertyBuilder:
        return SingleLinkFloatDerivedPropertyBuilder(object_set_type=self._object_set_type, property_name="gripLoad")

    @property
    def model_version(self) -> SingleLinkGenericDerivedPropertyBuilder:
        return SingleLinkGenericDerivedPropertyBuilder(
            object_set_type=self._object_set_type, property_name="modelVersion"
        )

    @property
    def reviewed_at(self) -> SingleLinkDatetimeDerivedPropertyBuilder:
        return SingleLinkDatetimeDerivedPropertyBuilder(
            object_set_type=self._object_set_type, property_name="reviewedAt"
        )

    @property
    def final_decision(self) -> SingleLinkGenericDerivedPropertyBuilder:
        return SingleLinkGenericDerivedPropertyBuilder(
            object_set_type=self._object_set_type, property_name="finalDecision"
        )

    @property
    def reviewed_by(self) -> SingleLinkGenericDerivedPropertyBuilder:
        return SingleLinkGenericDerivedPropertyBuilder(
            object_set_type=self._object_set_type, property_name="reviewedBy"
        )

    @property
    def robot_id(self) -> SingleLinkGenericDerivedPropertyBuilder:
        return SingleLinkGenericDerivedPropertyBuilder(object_set_type=self._object_set_type, property_name="robotId")

    @property
    def fusion_decision(self) -> SingleLinkGenericDerivedPropertyBuilder:
        return SingleLinkGenericDerivedPropertyBuilder(
            object_set_type=self._object_set_type, property_name="fusionDecision"
        )

    @property
    def inspection_id(self) -> SingleLinkGenericDerivedPropertyBuilder:
        return SingleLinkGenericDerivedPropertyBuilder(
            object_set_type=self._object_set_type, property_name="inspectionId"
        )

    @property
    def vision_agrees(self) -> SingleLinkGenericDerivedPropertyBuilder:
        return SingleLinkGenericDerivedPropertyBuilder(
            object_set_type=self._object_set_type, property_name="visionAgrees"
        )

    @property
    def operator_notes(self) -> SingleLinkGenericDerivedPropertyBuilder:
        return SingleLinkGenericDerivedPropertyBuilder(
            object_set_type=self._object_set_type, property_name="operatorNotes"
        )

    @property
    def vision_confidence(self) -> SingleLinkFloatDerivedPropertyBuilder:
        return SingleLinkFloatDerivedPropertyBuilder(
            object_set_type=self._object_set_type, property_name="visionConfidence"
        )

    @property
    def captured_image_ref(self) -> SingleLinkGenericDerivedPropertyBuilder:
        return SingleLinkGenericDerivedPropertyBuilder(
            object_set_type=self._object_set_type, property_name="capturedImageRef"
        )

    @property
    def review_status(self) -> SingleLinkGenericDerivedPropertyBuilder:
        return SingleLinkGenericDerivedPropertyBuilder(
            object_set_type=self._object_set_type, property_name="reviewStatus"
        )

    @property
    def cycle_time_ms(self) -> SingleLinkIntegerDerivedPropertyBuilder:
        return SingleLinkIntegerDerivedPropertyBuilder(
            object_set_type=self._object_set_type, property_name="cycleTimeMs"
        )

    @property
    def vision_class(self) -> SingleLinkGenericDerivedPropertyBuilder:
        return SingleLinkGenericDerivedPropertyBuilder(
            object_set_type=self._object_set_type, property_name="visionClass"
        )

    @property
    def fusion_reason(self) -> SingleLinkGenericDerivedPropertyBuilder:
        return SingleLinkGenericDerivedPropertyBuilder(
            object_set_type=self._object_set_type, property_name="fusionReason"
        )

    @property
    def timestamp(self) -> SingleLinkDatetimeDerivedPropertyBuilder:
        return SingleLinkDatetimeDerivedPropertyBuilder(
            object_set_type=self._object_set_type, property_name="timestamp"
        )

    def grip_readings(self) -> "GripReadingDerivedPropertyBuilder":
        from physical_ai_qa_cell_sdk.ontology._derived_properties._many_link_derived_property_builders._grip_reading import (
            ManyLinkGripReadingDerivedPropertyBuilder,
        )

        return ManyLinkGripReadingDerivedPropertyBuilder(
            object_set_type=ObjectSetSearchAroundType(
                objectSet=self._object_set_type, link="gripReadings", type="searchAround"
            ),
        )

    def inspection_vision_readings(self) -> "VisionReadingDerivedPropertyBuilder":
        from physical_ai_qa_cell_sdk.ontology._derived_properties._many_link_derived_property_builders._vision_reading import (
            ManyLinkVisionReadingDerivedPropertyBuilder,
        )

        return ManyLinkVisionReadingDerivedPropertyBuilder(
            object_set_type=ObjectSetSearchAroundType(
                objectSet=self._object_set_type, link="inspectionVisionReadings", type="searchAround"
            ),
        )

    def robot(self) -> "SingleLinkRobotDerivedPropertyBuilder":
        from physical_ai_qa_cell_sdk.ontology._derived_properties._single_link_derived_property_builders._robot import (
            SingleLinkRobotDerivedPropertyBuilder,
        )

        return SingleLinkRobotDerivedPropertyBuilder(
            object_set_type=ObjectSetSearchAroundType(
                objectSet=self._object_set_type, link="robot", type="searchAround"
            ),
        )

    def count(self) -> SelectedPropertyExpression:
        return SelectedPropertyExpression(
            objectSet=self._object_set_type,
            operation=SelectedPropertyCountAggregation(type="count"),
            type="selection",
        )

    def where(self, expression: ObjectTypePropertyWithExpression) -> "SingleLinkInspectionEventDerivedPropertyBuilder":
        if not isinstance(expression, ObjectTypePropertyWithExpression):
            raise TypeError(
                "The provided expression isn't valid. Example of a valid expression: Object.object_type.<property> == 1"
            )
        query = SearchExpressionParser.visit(expression)
        return SingleLinkInspectionEventDerivedPropertyBuilder(
            object_set_type=ObjectSetFilterType(objectSet=self._object_set_type, where=query, type="filter"),
        )
