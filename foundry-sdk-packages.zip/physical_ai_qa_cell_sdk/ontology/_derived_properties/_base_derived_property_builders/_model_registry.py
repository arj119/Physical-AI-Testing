#  (c) Copyright 2025 Palantir Technologies Inc. All rights reserved.
from typing import Optional

from foundry_sdk.v2.ontologies.models import MethodObjectSet, ObjectSetMethodInputType
from foundry_sdk_runtime.derived_properties import BaseDatetimeDerivedPropertyBuilder, BaseFloatDerivedPropertyBuilder
from foundry_sdk_runtime.properties.property_types import DerivedObjectTypeProperty


class BaseModelRegistryDerivedPropertyBuilder:
    def __init__(
        self,
        object_set_type: Optional[MethodObjectSet] = None,
    ):
        self._object_set_type = object_set_type or ObjectSetMethodInputType(type="methodInput")

    @property
    def published_at(self) -> BaseDatetimeDerivedPropertyBuilder:
        return BaseDatetimeDerivedPropertyBuilder(object_set_type=self._object_set_type, property_name="publishedAt")

    @property
    def accuracy(self) -> BaseFloatDerivedPropertyBuilder:
        return BaseFloatDerivedPropertyBuilder(object_set_type=self._object_set_type, property_name="accuracy")

    @staticmethod
    def property(property_name: str) -> DerivedObjectTypeProperty:
        """Returns a property class for the selected property."""
        return DerivedObjectTypeProperty(name=property_name)
