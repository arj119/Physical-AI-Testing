#  (c) Copyright 2025 Palantir Technologies Inc. All rights reserved.
from typing import TYPE_CHECKING, Optional

from foundry_sdk.v2.ontologies.models import MethodObjectSet, ObjectSetMethodInputType, ObjectSetSearchAroundType
from foundry_sdk_runtime.derived_properties import BaseDatetimeDerivedPropertyBuilder, BaseFloatDerivedPropertyBuilder
from foundry_sdk_runtime.properties.property_types import DerivedObjectTypeProperty

if TYPE_CHECKING:
    from physical_ai_qa_cell_sdk.ontology._derived_properties._single_link_derived_property_builders._inspection_event import (
        SingleLinkInspectionEventDerivedPropertyBuilder,
    )
    from physical_ai_qa_cell_sdk.ontology._derived_properties._single_link_derived_property_builders._robot import (
        SingleLinkRobotDerivedPropertyBuilder,
    )


class BaseGripReadingDerivedPropertyBuilder:
    def __init__(
        self,
        object_set_type: Optional[MethodObjectSet] = None,
    ):
        self._object_set_type = object_set_type or ObjectSetMethodInputType(type="methodInput")

    @property
    def normalized_load(self) -> BaseFloatDerivedPropertyBuilder:
        return BaseFloatDerivedPropertyBuilder(object_set_type=self._object_set_type, property_name="normalizedLoad")

    @property
    def servo_load(self) -> BaseFloatDerivedPropertyBuilder:
        return BaseFloatDerivedPropertyBuilder(object_set_type=self._object_set_type, property_name="servoLoad")

    @property
    def timestamp(self) -> BaseDatetimeDerivedPropertyBuilder:
        return BaseDatetimeDerivedPropertyBuilder(object_set_type=self._object_set_type, property_name="timestamp")

    def inspection_event(self) -> "SingleLinkInspectionEventDerivedPropertyBuilder":
        from physical_ai_qa_cell_sdk.ontology._derived_properties._single_link_derived_property_builders._inspection_event import (
            SingleLinkInspectionEventDerivedPropertyBuilder,
        )

        return SingleLinkInspectionEventDerivedPropertyBuilder(
            object_set_type=ObjectSetSearchAroundType(
                objectSet=self._object_set_type, link="inspectionEvent", type="searchAround"
            ),
        )

    def robot(self) -> "SingleLinkRobotDerivedPropertyBuilder":
        from physical_ai_qa_cell_sdk.ontology._derived_properties._single_link_derived_property_builders._robot import (
            SingleLinkRobotDerivedPropertyBuilder,
        )

        return SingleLinkRobotDerivedPropertyBuilder(
            object_set_type=ObjectSetSearchAroundType(
                objectSet=self._object_set_type, link="robot", type="searchAround"
            ),
        )

    @staticmethod
    def property(property_name: str) -> DerivedObjectTypeProperty:
        """Returns a property class for the selected property."""
        return DerivedObjectTypeProperty(name=property_name)
