#  (c) Copyright 2025 Palantir Technologies Inc. All rights reserved.
from typing import TYPE_CHECKING, Optional

from foundry_sdk.v2.ontologies.models import MethodObjectSet, ObjectSetMethodInputType, ObjectSetSearchAroundType
from foundry_sdk_runtime.derived_properties import (
    BaseDatetimeDerivedPropertyBuilder,
    BaseFloatDerivedPropertyBuilder,
    BaseIntegerDerivedPropertyBuilder,
)
from foundry_sdk_runtime.properties.property_types import DerivedObjectTypeProperty

if TYPE_CHECKING:
    from physical_ai_qa_cell_sdk.ontology._derived_properties._many_link_derived_property_builders._grip_reading import (
        ManyLinkGripReadingDerivedPropertyBuilder,
    )
    from physical_ai_qa_cell_sdk.ontology._derived_properties._many_link_derived_property_builders._vision_reading import (
        ManyLinkVisionReadingDerivedPropertyBuilder,
    )
    from physical_ai_qa_cell_sdk.ontology._derived_properties._single_link_derived_property_builders._robot import (
        SingleLinkRobotDerivedPropertyBuilder,
    )


class BaseInspectionEventDerivedPropertyBuilder:
    def __init__(
        self,
        object_set_type: Optional[MethodObjectSet] = None,
    ):
        self._object_set_type = object_set_type or ObjectSetMethodInputType(type="methodInput")

    @property
    def grip_load(self) -> BaseFloatDerivedPropertyBuilder:
        return BaseFloatDerivedPropertyBuilder(object_set_type=self._object_set_type, property_name="gripLoad")

    @property
    def reviewed_at(self) -> BaseDatetimeDerivedPropertyBuilder:
        return BaseDatetimeDerivedPropertyBuilder(object_set_type=self._object_set_type, property_name="reviewedAt")

    @property
    def vision_confidence(self) -> BaseFloatDerivedPropertyBuilder:
        return BaseFloatDerivedPropertyBuilder(object_set_type=self._object_set_type, property_name="visionConfidence")

    @property
    def cycle_time_ms(self) -> BaseIntegerDerivedPropertyBuilder:
        return BaseIntegerDerivedPropertyBuilder(object_set_type=self._object_set_type, property_name="cycleTimeMs")

    @property
    def timestamp(self) -> BaseDatetimeDerivedPropertyBuilder:
        return BaseDatetimeDerivedPropertyBuilder(object_set_type=self._object_set_type, property_name="timestamp")

    def grip_readings(self) -> "ManyLinkGripReadingDerivedPropertyBuilder":
        from physical_ai_qa_cell_sdk.ontology._derived_properties._many_link_derived_property_builders._grip_reading import (
            ManyLinkGripReadingDerivedPropertyBuilder,
        )

        return ManyLinkGripReadingDerivedPropertyBuilder(
            object_set_type=ObjectSetSearchAroundType(
                objectSet=self._object_set_type, link="gripReadings", type="searchAround"
            ),
        )

    def inspection_vision_readings(self) -> "ManyLinkVisionReadingDerivedPropertyBuilder":
        from physical_ai_qa_cell_sdk.ontology._derived_properties._many_link_derived_property_builders._vision_reading import (
            ManyLinkVisionReadingDerivedPropertyBuilder,
        )

        return ManyLinkVisionReadingDerivedPropertyBuilder(
            object_set_type=ObjectSetSearchAroundType(
                objectSet=self._object_set_type, link="inspectionVisionReadings", type="searchAround"
            ),
        )

    def robot(self) -> "SingleLinkRobotDerivedPropertyBuilder":
        from physical_ai_qa_cell_sdk.ontology._derived_properties._single_link_derived_property_builders._robot import (
            SingleLinkRobotDerivedPropertyBuilder,
        )

        return SingleLinkRobotDerivedPropertyBuilder(
            object_set_type=ObjectSetSearchAroundType(
                objectSet=self._object_set_type, link="robot", type="searchAround"
            ),
        )

    @staticmethod
    def property(property_name: str) -> DerivedObjectTypeProperty:
        """Returns a property class for the selected property."""
        return DerivedObjectTypeProperty(name=property_name)
