#  (c) Copyright 2025 Palantir Technologies Inc. All rights reserved.
from typing import TYPE_CHECKING, Optional

from foundry_sdk.v2.ontologies.models import MethodObjectSet, ObjectSetMethodInputType, ObjectSetSearchAroundType
from foundry_sdk_runtime.derived_properties import (
    BaseDatetimeDerivedPropertyBuilder,
    BaseFloatDerivedPropertyBuilder,
    BaseIntegerDerivedPropertyBuilder,
)
from foundry_sdk_runtime.properties.property_types import DerivedObjectTypeProperty

if TYPE_CHECKING:
    from physical_ai_qa_cell_sdk.ontology._derived_properties._many_link_derived_property_builders._grip_reading import (
        ManyLinkGripReadingDerivedPropertyBuilder,
    )
    from physical_ai_qa_cell_sdk.ontology._derived_properties._many_link_derived_property_builders._inspection_event import (
        ManyLinkInspectionEventDerivedPropertyBuilder,
    )
    from physical_ai_qa_cell_sdk.ontology._derived_properties._many_link_derived_property_builders._operator_command import (
        ManyLinkOperatorCommandDerivedPropertyBuilder,
    )
    from physical_ai_qa_cell_sdk.ontology._derived_properties._many_link_derived_property_builders._sensor import (
        ManyLinkSensorDerivedPropertyBuilder,
    )
    from physical_ai_qa_cell_sdk.ontology._derived_properties._many_link_derived_property_builders._vision_reading import (
        ManyLinkVisionReadingDerivedPropertyBuilder,
    )


class BaseRobotDerivedPropertyBuilder:
    def __init__(
        self,
        object_set_type: Optional[MethodObjectSet] = None,
    ):
        self._object_set_type = object_set_type or ObjectSetMethodInputType(type="methodInput")

    @property
    def last_heartbeat(self) -> BaseDatetimeDerivedPropertyBuilder:
        return BaseDatetimeDerivedPropertyBuilder(object_set_type=self._object_set_type, property_name="lastHeartbeat")

    @property
    def total_inspections(self) -> BaseIntegerDerivedPropertyBuilder:
        return BaseIntegerDerivedPropertyBuilder(
            object_set_type=self._object_set_type, property_name="totalInspections"
        )

    @property
    def grip_tolerance(self) -> BaseFloatDerivedPropertyBuilder:
        return BaseFloatDerivedPropertyBuilder(object_set_type=self._object_set_type, property_name="gripTolerance")

    def grip_readings(self) -> "ManyLinkGripReadingDerivedPropertyBuilder":
        from physical_ai_qa_cell_sdk.ontology._derived_properties._many_link_derived_property_builders._grip_reading import (
            ManyLinkGripReadingDerivedPropertyBuilder,
        )

        return ManyLinkGripReadingDerivedPropertyBuilder(
            object_set_type=ObjectSetSearchAroundType(
                objectSet=self._object_set_type, link="gripReadings", type="searchAround"
            ),
        )

    def inspection_events(self) -> "ManyLinkInspectionEventDerivedPropertyBuilder":
        from physical_ai_qa_cell_sdk.ontology._derived_properties._many_link_derived_property_builders._inspection_event import (
            ManyLinkInspectionEventDerivedPropertyBuilder,
        )

        return ManyLinkInspectionEventDerivedPropertyBuilder(
            object_set_type=ObjectSetSearchAroundType(
                objectSet=self._object_set_type, link="inspectionEvents", type="searchAround"
            ),
        )

    def operator_commands(self) -> "ManyLinkOperatorCommandDerivedPropertyBuilder":
        from physical_ai_qa_cell_sdk.ontology._derived_properties._many_link_derived_property_builders._operator_command import (
            ManyLinkOperatorCommandDerivedPropertyBuilder,
        )

        return ManyLinkOperatorCommandDerivedPropertyBuilder(
            object_set_type=ObjectSetSearchAroundType(
                objectSet=self._object_set_type, link="operatorCommands", type="searchAround"
            ),
        )

    def sensors(self) -> "ManyLinkSensorDerivedPropertyBuilder":
        from physical_ai_qa_cell_sdk.ontology._derived_properties._many_link_derived_property_builders._sensor import (
            ManyLinkSensorDerivedPropertyBuilder,
        )

        return ManyLinkSensorDerivedPropertyBuilder(
            object_set_type=ObjectSetSearchAroundType(
                objectSet=self._object_set_type, link="sensors", type="searchAround"
            ),
        )

    def vision_readings(self) -> "ManyLinkVisionReadingDerivedPropertyBuilder":
        from physical_ai_qa_cell_sdk.ontology._derived_properties._many_link_derived_property_builders._vision_reading import (
            ManyLinkVisionReadingDerivedPropertyBuilder,
        )

        return ManyLinkVisionReadingDerivedPropertyBuilder(
            object_set_type=ObjectSetSearchAroundType(
                objectSet=self._object_set_type, link="visionReadings", type="searchAround"
            ),
        )

    @staticmethod
    def property(property_name: str) -> DerivedObjectTypeProperty:
        """Returns a property class for the selected property."""
        return DerivedObjectTypeProperty(name=property_name)
