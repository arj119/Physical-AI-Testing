#  (c) Copyright 2025 Palantir Technologies Inc. All rights reserved.
from typing import TYPE_CHECKING, Optional

from foundry_sdk.v2.ontologies.models import MethodObjectSet, ObjectSetMethodInputType, ObjectSetSearchAroundType
from foundry_sdk_runtime.derived_properties import BaseDatetimeDerivedPropertyBuilder
from foundry_sdk_runtime.properties.property_types import DerivedObjectTypeProperty

if TYPE_CHECKING:
    from physical_ai_qa_cell_sdk.ontology._derived_properties._single_link_derived_property_builders._robot import (
        SingleLinkRobotDerivedPropertyBuilder,
    )


class BaseOperatorCommandDerivedPropertyBuilder:
    def __init__(
        self,
        object_set_type: Optional[MethodObjectSet] = None,
    ):
        self._object_set_type = object_set_type or ObjectSetMethodInputType(type="methodInput")

    @property
    def created_at(self) -> BaseDatetimeDerivedPropertyBuilder:
        return BaseDatetimeDerivedPropertyBuilder(object_set_type=self._object_set_type, property_name="createdAt")

    @property
    def executed_at(self) -> BaseDatetimeDerivedPropertyBuilder:
        return BaseDatetimeDerivedPropertyBuilder(object_set_type=self._object_set_type, property_name="executedAt")

    def target_robot(self) -> "SingleLinkRobotDerivedPropertyBuilder":
        from physical_ai_qa_cell_sdk.ontology._derived_properties._single_link_derived_property_builders._robot import (
            SingleLinkRobotDerivedPropertyBuilder,
        )

        return SingleLinkRobotDerivedPropertyBuilder(
            object_set_type=ObjectSetSearchAroundType(
                objectSet=self._object_set_type, link="targetRobot", type="searchAround"
            ),
        )

    @staticmethod
    def property(property_name: str) -> DerivedObjectTypeProperty:
        """Returns a property class for the selected property."""
        return DerivedObjectTypeProperty(name=property_name)
