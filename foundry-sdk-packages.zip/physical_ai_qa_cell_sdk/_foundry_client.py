#  (c) Copyright 2025 Palantir Technologies Inc. All rights reserved.
from typing import Optional

from foundry_sdk import Auth, Config
from foundry_sdk import FoundryClient as PlatformFoundryClient
from foundry_sdk._core.context_and_environment_vars import maybe_get_value_from_context_or_environment_vars
from foundry_sdk.v2.ontologies import OntologiesClient
from foundry_sdk_runtime import FOUNDRY_ONTOLOGY_RID_CONTEXT_VARS, FOUNDRY_ONTOLOGY_RID_ENV_VARS
from foundry_sdk_runtime.client.foundry_client_base_class import FoundryClientBaseClass

from ._client_config import get_or_create_config


class FoundryClient(FoundryClientBaseClass):

    def __init__(
        self,
        auth: Optional[Auth] = None,
        hostname: Optional[str] = None,
        rid: Optional[str] = None,
        branch: Optional[str] = None,
        config: Optional[Config] = None,
    ):
        """
        FoundryClient is the client provided by the osdk to make requests to api gateway
        The priority by which auth and hostname for FoundryClient is set is
        1. User input
        2. If there is no user input, then check context variables in foundry_sdk_runtime
        3. If no context variables are set, then check environment variables
        :rid: An optional rid the user can provide. This rid will be used instead of the default one to make requests.
        :branch: An optional branch rid the user can provide. This branch will be used instead of the generated or context-set one to make requests.
        """
        self._config = get_or_create_config(config)
        if branch:
            self._config.default_params["branch"] = branch
        super().__init__(auth=auth, hostname=hostname, config=self._config)
        self._rid = (
            rid
            or maybe_get_value_from_context_or_environment_vars(
                FOUNDRY_ONTOLOGY_RID_CONTEXT_VARS, FOUNDRY_ONTOLOGY_RID_ENV_VARS
            )
            or "ri.ontology.main.ontology.8d41bc1c-890d-4702-972b-98035f877b96"
        )
        self.foundry_sdk = PlatformFoundryClient(auth=self._auth, hostname=self._hostname, config=self._config)

    @staticmethod
    def _init_from_ontologies_client(ontologies_client: OntologiesClient, rid: Optional[str] = None) -> "FoundryClient":
        return FoundryClient(auth=ontologies_client._auth, hostname=ontologies_client._hostname, rid=rid)

    @property
    def ontology(self):
        from physical_ai_qa_cell_sdk.ontology import OntologyE88aa807Ba2c43e1A20d63b932de405f

        return OntologyE88aa807Ba2c43e1A20d63b932de405f(
            _ontologies_client=self.foundry_sdk.ontologies,
            _functions_client=self.foundry_sdk.functions,
            _ontology_rid=self._rid,
        )
