#  (c) Copyright 2023 Palantir Technologies Inc. All rights reserved.
__version__ = "0.7.0"

__codegen_version__ = "2.193.0"
