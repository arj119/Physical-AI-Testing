#  (c) Copyright 2023 Palantir Technologies Inc. All rights reserved.
import warnings

from foundry_sdk import Config, UserTokenAuth
from foundry_sdk_runtime import BetaWarning
from foundry_sdk_runtime._auth import ConfidentialClientAuth, PublicClientAuth
from foundry_sdk_runtime.types import *

from . import _sdk_metadata as sdk_metadata
from . import _version as version
from ._foundry_client import FoundryClient
from .ontology import OntologyE88aa807Ba2c43e1A20d63b932de405f

__codegen_version__ = version.__codegen_version__

__version__ = version.__version__

__package_rid__ = sdk_metadata.__package_rid__

__all__ = [
    "ConfidentialClientAuth",
    "Config",
    "FoundryClient",
    "PublicClientAuth",
    "UserTokenAuth",
    "OntologyE88aa807Ba2c43e1A20d63b932de405f",
]

warnings.filterwarnings(action="error", category=BetaWarning)
