import sys
from typing import Any, Optional

from foundry_sdk import Config
from foundry_sdk_runtime.client_config_helpers import maybe_get_value_from_context, maybe_get_value_from_context_or_env
from foundry_sdk_runtime.context_vars import (
    ATTRIBUTION_RESOURCES,
    FOUNDRY_BRANCH_RID_CONTEXT_VARS,
    FOUNDRY_DEFAULT_HEADERS_PREPEND,
    FOUNDRY_SAMPLED_CONTEXT_VARS,
    FOUNDRY_SPAN_ID_CONTEXT_VARS,
    FOUNDRY_TRACE_ID_CONTEXT_VARS,
    FOUNDRY_TRANSACTION_ID_CONTEXT_VARS,
    SDK_IDENTIFIER_MAPPING,
    SdkIdentifier,
)

from ._sdk_metadata import __package_rid__
from ._version import __codegen_version__, __version__


def get_or_create_config(config: Optional[Config]) -> Config:
    if config is None:
        return Config(default_headers=_default_headers(), default_params=_default_params())
    # combine the default headers with the user provided headers preferring user provided headers
    config_headers = config.default_headers if config.default_headers else {}
    config.default_headers = {**_default_headers(), **config_headers}
    # combine the default params with the user provided params preferring user provided params
    config_params = config.default_params if config.default_params else {}
    config.default_params = {**_default_params(), **config_params}
    return config


def _default_headers() -> dict[str, str]:
    headers = {
        "User-Agent": "python-osdk/{} python-osdk-generator/{} python/{}".format(
            __version__,
            __codegen_version__,
            f"{sys.version_info.major}.{sys.version_info.minor}",
        )
    }

    if (
        prepend_headers_dict := maybe_get_value_from_context(context_vars=[FOUNDRY_DEFAULT_HEADERS_PREPEND])
    ) is not None:
        for header_key, header_value in prepend_headers_dict.items():
            headers[header_key] = header_value + headers.get(header_key, "")
    if (
        trace_id := maybe_get_value_from_context_or_env(context_vars=FOUNDRY_TRACE_ID_CONTEXT_VARS, env_vars=[])
    ) is not None:
        headers["X-B3-TraceId"] = trace_id
    if (
        span_id := maybe_get_value_from_context_or_env(context_vars=FOUNDRY_SPAN_ID_CONTEXT_VARS, env_vars=[])
    ) is not None:
        headers["X-B3-SpanId"] = span_id
    if (
        sampled := maybe_get_value_from_context_or_env(context_vars=FOUNDRY_SAMPLED_CONTEXT_VARS, env_vars=[])
    ) is not None:
        headers["X-B3-Sampled"] = sampled
    if (attribution := maybe_get_value_from_context(context_vars=[ATTRIBUTION_RESOURCES])) is not None:
        # When sending multiple values in a header, should be sent as a comma separated list per
        # https://www.w3.org/Protocols/rfc2616/rfc2616-sec4.html#sec4.2
        headers["attribution"] = ", ".join(attribution)

    return headers


def _default_params() -> dict[str, Any]:
    default_params = {}

    sdk_identifier_mapping = maybe_get_value_from_context(context_vars=[SDK_IDENTIFIER_MAPPING])
    original_identifier = SdkIdentifier(rid=__package_rid__, version=__version__) if sdk_identifier_mapping else None
    remapped_identifier = sdk_identifier_mapping.get(original_identifier) if original_identifier else None
    if remapped_identifier:
        default_params["sdkPackageRid"] = remapped_identifier.rid
        default_params["sdkVersion"] = remapped_identifier.version

    if branch_rid := maybe_get_value_from_context(context_vars=FOUNDRY_BRANCH_RID_CONTEXT_VARS) or None:
        default_params["branch"] = branch_rid

    if transaction_id := maybe_get_value_from_context(context_vars=FOUNDRY_TRANSACTION_ID_CONTEXT_VARS):
        default_params["transactionId"] = transaction_id

    return default_params
