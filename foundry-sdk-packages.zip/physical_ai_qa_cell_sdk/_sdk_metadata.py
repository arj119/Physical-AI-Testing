#  (c) Copyright 2025 Palantir Technologies Inc. All rights reserved.
__package_rid__ = "None"
