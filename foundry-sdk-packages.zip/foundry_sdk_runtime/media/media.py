#  (c) Copyright 2025 Palantir Technologies Inc. All rights reserved.
from io import BytesIO
from typing import TYPE_CHECKING, Any, Optional, Union

from foundry_sdk.v2.media_sets import AsyncMediaSetsClient, MediaSetsClient
from foundry_sdk.v2.media_sets.models import (
    Transformation,
)
from foundry_sdk.v2.ontologies import OntologiesClient

from foundry_sdk_runtime.decorators import beta
from foundry_sdk_runtime.helpers import PRIMARY_KEY_UNION_TYPE
from foundry_sdk_runtime.media._transforms import (
    async_transform_and_wait as _async_transform_and_wait,
)
from foundry_sdk_runtime.media._transforms import (
    transform_and_wait as _transform_and_wait,
)
from foundry_sdk_runtime.types import sanitize_for_hashing

if TYPE_CHECKING:
    # Remove lazy imports once Media is out of beta
    from foundry_sdk.v2.core.models import MediaReference
    from foundry_sdk.v2.media_sets.models import MediaItemMetadata
    from foundry_sdk.v2.ontologies.models import MediaMetadata


@beta("Media types are in beta and may change in future versions.")
class Media:
    """Represents a media item in a Foundry Media Set.

    A Media instance can be constructed in two ways:

    1. With full Ontology context (ontology RID, object type, primary key, and property name),
       in which case content and metadata are retrieved via the Ontologies API. This is because
       the media item is a property of an Ontology Object.
    2. With only a :class:`MediaReference` (e.g. obtained from :meth:`MediaSet.upload_media`
       or :meth:`MediaSet.create_media_from_reference`), in which case content and metadata
       are retrieved directly via the Media Sets API. This is because the media item is on
       a Media Set in Foundry.
    """

    def __init__(
        self,
        _ontologies_client: OntologiesClient,
        _media_sets_client: Optional[MediaSetsClient] = None,
        _async_media_sets_client: Optional[AsyncMediaSetsClient] = None,
        _ontology_rid: Optional[str] = None,
        object_type: Optional[str] = None,
        object_primary_key: Optional[PRIMARY_KEY_UNION_TYPE] = None,
        property_name: Optional[str] = None,
        media_reference: Optional["MediaReference"] = None,
    ) -> None:
        self._ontologies_client = _ontologies_client
        self._ontology_rid = _ontology_rid
        self._object_type = object_type
        self._object_primary_key = object_primary_key
        self._property_name = property_name
        self._media_reference = media_reference

        self._media_sets_client = _media_sets_client or MediaSetsClient(
            auth=_ontologies_client._auth,
            hostname=_ontologies_client._hostname,
            config=_ontologies_client._config,
        )
        self._async_media_sets_client = _async_media_sets_client or AsyncMediaSetsClient(
            auth=self._media_sets_client._auth,
            hostname=self._media_sets_client._hostname,
            config=self._media_sets_client._config,
        )

    def get_media_content(self) -> BytesIO:
        """Returns the binary content of this media item as a :class:`~io.BytesIO` stream.

        When ontology context is available, retrieves content via the Ontologies API.
        Otherwise, reads content directly from the Media Sets API using the stored
        :class:`MediaReference`.
        """
        if self._use_ontologies_client():
            response = self._ontologies_client.MediaReferenceProperty.get_media_content(
                ontology=self._ontology_rid,
                object_type=self._object_type,
                primary_key=str(self._object_primary_key),
                property=self._property_name,
                preview=True,
                request_timeout=None,
            )
        else:
            media_reference = self.get_media_reference()
            response = self._media_sets_client.MediaSet.read(
                media_set_rid=media_reference.reference.media_set_view_item.media_set_rid,
                media_item_rid=media_reference.reference.media_set_view_item.media_item_rid,
                preview=True,
                read_token=media_reference.reference.media_set_view_item.token,
            )
        return BytesIO(response)

    def get_media_metadata(self) -> Union["MediaMetadata", "MediaItemMetadata"]:
        """Returns metadata for this media item.

        When ontology context is available, retrieves metadata via the Ontologies API and
        returns a :class:`MediaMetadata` instance. Otherwise, retrieves metadata directly
        from the Media Sets API using the stored :class:`MediaReference` and returns a
        :class:`MediaItemMetadata` instance.
        """
        if self._use_ontologies_client():
            media_metadata: "MediaMetadata" = self._ontologies_client.MediaReferenceProperty.get_media_metadata(
                ontology=self._ontology_rid,
                object_type=self._object_type,
                primary_key=str(self._object_primary_key),
                property=self._property_name,
                preview=True,
                request_timeout=None,
            )
            return media_metadata
        media_reference = self.get_media_reference()
        media_item_metadata: "MediaItemMetadata" = self._media_sets_client.MediaSet.metadata(
            media_set_rid=media_reference.reference.media_set_view_item.media_set_rid,
            media_item_rid=media_reference.reference.media_set_view_item.media_item_rid,
            preview=True,
            read_token=media_reference.reference.media_set_view_item.token,
        )
        return media_item_metadata

    def get_media_reference(self) -> "MediaReference":
        if not self._media_reference:
            raise AttributeError("Media media_reference must be set.")
        return self._media_reference

    def __repr__(self) -> str:
        return f"Media({self._property_name})" if self._use_ontologies_client() else "Media"

    def __hash__(self) -> int:
        return hash(
            (
                type(self),
                sanitize_for_hashing(self._object_type),
                sanitize_for_hashing(self._object_primary_key),
                sanitize_for_hashing(self._property_name),
            )
        )

    def __eq__(self, other: Any) -> bool:
        return self is other or (
            type(self) is type(other)
            and self._object_type == other._object_type
            and self._object_primary_key == other._object_primary_key
            and self._media_reference == other._media_reference
        )

    def _asdict(self) -> dict[str, Optional[str]]:
        return {"property_name": self._property_name} if self._use_ontologies_client() else {}

    @staticmethod
    def _fields() -> dict[str, Any]:
        from foundry_sdk.v2.core.models import MediaReference

        return {
            "ontology_rid": Optional[str],
            "object_type": Optional[str],
            "object_primary_key": Optional[str],
            "property_name": Optional[str],
            "media_reference": Optional[MediaReference],
        }

    @staticmethod
    def _api_name_to_property_name() -> dict[str, str]:
        return {
            "ontology_rid": "ontology_rid",
            "object_type": "object_type",
            "object_primary_key": "object_primary_key",
            "property_name": "property_name",
        }

    def _use_ontologies_client(self) -> bool:
        return all((self._ontology_rid, self._object_type, self._object_primary_key, self._property_name))

    @beta("Transforming media is in beta and may change in future versions.")
    def transform_and_wait(
        self, transformation: Transformation, poll_interval_seconds: float = 3.0, poll_timeout_seconds: float = 30.0
    ) -> bytes:
        """Starts a transformation job and polls every poll_interval_seconds until poll_timeout_seconds, then returns result bytes."""
        return _transform_and_wait(
            self._media_sets_client,
            self.get_media_reference(),
            transformation,
            poll_interval_seconds,
            poll_timeout_seconds,
        )

    @beta("Transforming media is in beta and may change in future versions.")
    async def async_transform_and_wait(
        self,
        transformation: Transformation,
        poll_interval_seconds: float = 3.0,
        poll_timeout_seconds: float = 30.0,
    ) -> bytes:
        """Starts a transformation job and polls every poll_interval_seconds until poll_timeout_seconds, then returns result bytes."""
        return await _async_transform_and_wait(
            self._async_media_sets_client,
            self.get_media_reference(),
            transformation,
            poll_interval_seconds,
            poll_timeout_seconds,
        )
