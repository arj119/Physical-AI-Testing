#  (c) Copyright 2026 Palantir Technologies Inc. All rights reserved.
import asyncio
import time

from foundry_sdk.v2.core.models import MediaReference
from foundry_sdk.v2.media_sets import AsyncMediaSetsClient, MediaSetsClient
from foundry_sdk.v2.media_sets.models import (
    GetTransformationJobStatusResponse,
    Transformation,
    TransformationJobId,
    TransformMediaItemResponse,
)

from foundry_sdk_runtime.errors.invalid_media_transformation_errors import (
    MediaTransformationFailedError,
    MediaTransformationTimeoutError,
)


def _transform(
    client: MediaSetsClient, media_reference: MediaReference, transformation: Transformation
) -> TransformMediaItemResponse:
    response: TransformMediaItemResponse = client.MediaSet.transform(
        media_set_rid=media_reference.reference.media_set_view_item.media_set_rid,
        media_item_rid=media_reference.reference.media_set_view_item.media_item_rid,
        transformation=transformation,
        preview=True,
        token=media_reference.reference.media_set_view_item.token,
    )
    return response


async def _async_transform(
    client: AsyncMediaSetsClient, media_reference: MediaReference, transformation: Transformation
) -> TransformMediaItemResponse:
    return await client.MediaSet.transform(
        media_set_rid=media_reference.reference.media_set_view_item.media_set_rid,
        media_item_rid=media_reference.reference.media_set_view_item.media_item_rid,
        transformation=transformation,
        preview=True,
        token=media_reference.reference.media_set_view_item.token,
    )


def _get_transform_status(
    client: MediaSetsClient, media_reference: MediaReference, transformation_job_id: TransformationJobId
) -> GetTransformationJobStatusResponse:
    response: GetTransformationJobStatusResponse = client.MediaSet.get_status(
        media_set_rid=media_reference.reference.media_set_view_item.media_set_rid,
        media_item_rid=media_reference.reference.media_set_view_item.media_item_rid,
        transformation_job_id=transformation_job_id,
        preview=True,
        token=media_reference.reference.media_set_view_item.token,
    )
    return response


async def _async_get_transform_status(
    client: AsyncMediaSetsClient, media_reference: MediaReference, transformation_job_id: TransformationJobId
) -> GetTransformationJobStatusResponse:
    return await client.MediaSet.get_status(
        media_set_rid=media_reference.reference.media_set_view_item.media_set_rid,
        media_item_rid=media_reference.reference.media_set_view_item.media_item_rid,
        transformation_job_id=transformation_job_id,
        preview=True,
        token=media_reference.reference.media_set_view_item.token,
    )


def _get_transform_result(
    client: MediaSetsClient, media_reference: MediaReference, transformation_job_id: TransformationJobId
) -> bytes:
    result: bytes = client.MediaSet.get_result(
        media_set_rid=media_reference.reference.media_set_view_item.media_set_rid,
        media_item_rid=media_reference.reference.media_set_view_item.media_item_rid,
        transformation_job_id=transformation_job_id,
        preview=True,
        token=media_reference.reference.media_set_view_item.token,
    )
    return result


async def _async_get_transform_result(
    client: AsyncMediaSetsClient, media_reference: MediaReference, transformation_job_id: TransformationJobId
) -> bytes:
    return await client.MediaSet.get_result(
        media_set_rid=media_reference.reference.media_set_view_item.media_set_rid,
        media_item_rid=media_reference.reference.media_set_view_item.media_item_rid,
        transformation_job_id=transformation_job_id,
        preview=True,
        token=media_reference.reference.media_set_view_item.token,
    )


def transform_and_wait(
    client: MediaSetsClient,
    media_reference: MediaReference,
    transformation: Transformation,
    poll_interval_seconds: float,
    poll_timeout_seconds: float,
) -> bytes:
    job: TransformMediaItemResponse = _transform(client, media_reference, transformation)
    status, job_id = job.status, job.job_id
    deadline = time.monotonic() + poll_timeout_seconds
    while status != "SUCCESSFUL":
        if time.monotonic() >= deadline:
            raise MediaTransformationTimeoutError(f"Transformation job {job_id} timed out polling status")
        response = _get_transform_status(client, media_reference, job_id)
        status = response.status
        if status == "FAILED":
            raise MediaTransformationFailedError(f"Transformation job {job_id} failed")
        if status != "SUCCESSFUL":
            time.sleep(poll_interval_seconds)
    return _get_transform_result(client, media_reference, job_id)


async def async_transform_and_wait(
    client: AsyncMediaSetsClient,
    media_reference: MediaReference,
    transformation: Transformation,
    poll_interval_seconds: float,
    poll_timeout_seconds: float,
) -> bytes:
    job: TransformMediaItemResponse = await _async_transform(client, media_reference, transformation)
    status, job_id = job.status, job.job_id
    deadline = time.monotonic() + poll_timeout_seconds
    while status != "SUCCESSFUL":
        if time.monotonic() >= deadline:
            raise MediaTransformationTimeoutError(f"Transformation job {job_id} timed out polling status")
        response = await _async_get_transform_status(client, media_reference, job_id)
        status = response.status
        if status == "FAILED":
            raise MediaTransformationFailedError(f"Transformation job {job_id} failed")
        if status != "SUCCESSFUL":
            await asyncio.sleep(poll_interval_seconds)
    return await _async_get_transform_result(client, media_reference, job_id)
