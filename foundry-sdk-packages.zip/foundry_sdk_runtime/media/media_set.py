#  (c) Copyright 2026 Palantir Technologies Inc. All rights reserved.
from foundry_sdk.v2.core.models import MediaReference
from foundry_sdk.v2.media_sets import AsyncMediaSetsClient, MediaSetsClient
from foundry_sdk.v2.media_sets.models import (
    Transformation,
)
from foundry_sdk.v2.ontologies import OntologiesClient

from foundry_sdk_runtime.context_vars import ATTRIBUTION_RESOURCES
from foundry_sdk_runtime.decorators import beta
from foundry_sdk_runtime.media._transforms import (
    async_transform_and_wait as _async_transform_and_wait,
)
from foundry_sdk_runtime.media._transforms import (
    transform_and_wait as _transform_and_wait,
)
from foundry_sdk_runtime.media.media import Media


@beta("MediaSet types are in beta and may change in future versions.")
class MediaSet:
    def __init__(self, ontologies_client: OntologiesClient):
        self._media_sets_client = MediaSetsClient(
            auth=ontologies_client._auth, hostname=ontologies_client._hostname, config=ontologies_client._config
        )
        self._async_media_sets_client = AsyncMediaSetsClient(
            auth=ontologies_client._auth, hostname=ontologies_client._hostname, config=ontologies_client._config
        )
        self._ontologies_client = ontologies_client

    def create_media_from_reference(self, media_reference: MediaReference) -> Media:
        return Media(
            _ontologies_client=self._ontologies_client,
            _ontology_rid=None,
            object_type=None,
            object_primary_key=None,
            property_name=None,
            media_reference=media_reference,
            _media_sets_client=self._media_sets_client,
            _async_media_sets_client=self._async_media_sets_client,
        )

    def upload_media(self, body: bytes, filename: str) -> MediaReference:
        """Uploads a temporary media item. If the media item isn't persisted within 1 hour, the item will be deleted.

        :param body: The media item to be uploaded.
        :param filename: The name of the media item.
        """
        media_ref: MediaReference = self._media_sets_client.MediaSet.upload_media(
            body=body, filename=filename, attribution=",".join(ATTRIBUTION_RESOURCES.get() or []) or None, preview=True
        )
        return media_ref

    async def async_upload_media(self, body: bytes, filename: str) -> MediaReference:
        """Uploads a temporary media item. If the media item isn't persisted within 1 hour, the item will be deleted.

        :param body: The media item to be uploaded.
        :param filename: The name of the media item.
        """
        return await self._async_media_sets_client.MediaSet.upload_media(
            body=body, filename=filename, attribution=",".join(ATTRIBUTION_RESOURCES.get() or []) or None, preview=True
        )

    @beta("Transforming media is in beta and may change in future versions.")
    def transform_and_wait(
        self,
        media_reference: MediaReference,
        transformation: Transformation,
        poll_interval_seconds: float = 3.0,
        poll_timeout_seconds: float = 30.0,
    ) -> bytes:
        """Starts a transformation job and polls every poll_interval_seconds until poll_timeout_seconds, then returns result bytes.

        :param media_reference: A reference to the media item to transform.
        :param transformation: The transformation to apply.
        :param poll_interval_seconds: Seconds between status polls.
        :param poll_timeout_seconds: Maximum seconds to wait before raising a timeout error.
        :returns: ``bytes`` of the completed transformation.
        """
        return _transform_and_wait(
            self._media_sets_client, media_reference, transformation, poll_interval_seconds, poll_timeout_seconds
        )

    @beta("Transforming media is in beta and may change in future versions.")
    async def async_transform_and_wait(
        self,
        media_reference: MediaReference,
        transformation: Transformation,
        poll_interval_seconds: float = 3.0,
        poll_timeout_seconds: float = 30.0,
    ) -> bytes:
        """Starts a transformation job and polls every poll_interval_seconds until poll_timeout_seconds, then returns result bytes.

        :param media_reference: A reference to the media item to transform.
        :param transformation: The transformation to apply.
        :param poll_interval_seconds: Seconds between status polls.
        :param poll_timeout_seconds: Maximum seconds to wait before raising a timeout error.
        :returns: ``bytes`` of the completed transformation.
        """
        return await _async_transform_and_wait(
            self._async_media_sets_client, media_reference, transformation, poll_interval_seconds, poll_timeout_seconds
        )
