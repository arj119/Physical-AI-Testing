"""
This module provides environment variables for the authentication token and hostname.
They are used as an option to initialize the FoundryClient in the Python OSDK
The order in which environment variables are listed is the priority in which they are tried
For example: if both "FOUNDRY_PYTHON_OSDK_TOKEN" and "FOUNDRY_TOKEN" are set, we prioritize "FOUNDRY_PYTHON_OSDK_TOKEN"
"""

FOUNDRY_TOKEN_ENV_VARS: list[str] = ["FOUNDRY_PYTHON_OSDK_TOKEN", "FOUNDRY_TOKEN"]
FOUNDRY_HOSTNAME_ENV_VARS: list[str] = [
    "FOUNDRY_PYTHON_OSDK_HOSTNAME",
    "FOUNDRY_HOSTNAME",
]
FOUNDRY_ONTOLOGY_RID_ENV_VARS: list[str] = ["FOUNDRY_ONTOLOGY_RID"]
