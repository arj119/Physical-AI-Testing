from typing import Optional

from foundry_sdk.v2.ontologies.models import MethodObjectSet, ObjectSetMethodInputType

from ._derived_property_builder import DerivedPropertyBuilder
from ._mixins import (
    BaseDatePropertyBuilderMixin,
    BaseDatetimePropertyBuilderMixin,
    BaseNumericalPropertyBuilderMixin,
    GenericDerivedPropertyBuilderMixin,
    GetDerivedPropertyBuilderMixin,
)


class SingleLinkDateDerivedPropertyBuilder(
    BaseDatePropertyBuilderMixin, GenericDerivedPropertyBuilderMixin, GetDerivedPropertyBuilderMixin
):
    def __init__(
        self,
        property_name: str,
        object_set_type: Optional[MethodObjectSet] = None,
    ) -> None:
        DerivedPropertyBuilder.__init__(
            self,
            object_set_type=object_set_type or ObjectSetMethodInputType(type="methodInput"),
            property_name=property_name,
        )


class SingleLinkDatetimeDerivedPropertyBuilder(
    BaseDatetimePropertyBuilderMixin, GenericDerivedPropertyBuilderMixin, GetDerivedPropertyBuilderMixin
):
    def __init__(
        self,
        property_name: str,
        object_set_type: Optional[MethodObjectSet] = None,
    ) -> None:
        DerivedPropertyBuilder.__init__(
            self,
            object_set_type=object_set_type or ObjectSetMethodInputType(type="methodInput"),
            property_name=property_name,
        )


class SingleLinkFloatDerivedPropertyBuilder(
    BaseNumericalPropertyBuilderMixin, GenericDerivedPropertyBuilderMixin, GetDerivedPropertyBuilderMixin
):
    def __init__(
        self,
        property_name: str,
        object_set_type: Optional[MethodObjectSet] = None,
    ) -> None:
        DerivedPropertyBuilder.__init__(
            self,
            object_set_type=object_set_type or ObjectSetMethodInputType(type="methodInput"),
            property_name=property_name,
        )


class SingleLinkIntegerDerivedPropertyBuilder(
    BaseNumericalPropertyBuilderMixin, GenericDerivedPropertyBuilderMixin, GetDerivedPropertyBuilderMixin
):
    def __init__(
        self,
        property_name: str,
        object_set_type: Optional[MethodObjectSet] = None,
    ) -> None:
        DerivedPropertyBuilder.__init__(
            self,
            object_set_type=object_set_type or ObjectSetMethodInputType(type="methodInput"),
            property_name=property_name,
        )


class SingleLinkGenericDerivedPropertyBuilder(GenericDerivedPropertyBuilderMixin, GetDerivedPropertyBuilderMixin):
    def __init__(
        self,
        property_name: str,
        object_set_type: Optional[MethodObjectSet] = None,
    ) -> None:
        DerivedPropertyBuilder.__init__(
            self,
            object_set_type=object_set_type or ObjectSetMethodInputType(type="methodInput"),
            property_name=property_name,
        )
