from typing import Optional

from foundry_sdk.v2.ontologies.models import MethodObjectSet, ObjectSetMethodInputType

from ._derived_property_builder import DerivedPropertyBuilder
from ._mixins import (
    BaseDatePropertyBuilderMixin,
    BaseDatetimePropertyBuilderMixin,
    BaseNumericalPropertyBuilderMixin,
)


class BaseDateDerivedPropertyBuilder(BaseDatePropertyBuilderMixin):
    def __init__(
        self,
        property_name: str,
        object_set_type: Optional[MethodObjectSet] = None,
    ) -> None:
        DerivedPropertyBuilder.__init__(
            self,
            object_set_type=object_set_type or ObjectSetMethodInputType(type="methodInput"),
            property_name=property_name,
        )


class BaseDatetimeDerivedPropertyBuilder(BaseDatetimePropertyBuilderMixin):
    def __init__(
        self,
        property_name: str,
        object_set_type: Optional[MethodObjectSet] = None,
    ) -> None:
        DerivedPropertyBuilder.__init__(
            self,
            object_set_type=object_set_type or ObjectSetMethodInputType(type="methodInput"),
            property_name=property_name,
        )


class BaseFloatDerivedPropertyBuilder(BaseNumericalPropertyBuilderMixin):
    def __init__(
        self,
        property_name: str,
        object_set_type: Optional[MethodObjectSet] = None,
    ) -> None:
        DerivedPropertyBuilder.__init__(
            self,
            object_set_type=object_set_type or ObjectSetMethodInputType(type="methodInput"),
            property_name=property_name,
        )


class BaseIntegerDerivedPropertyBuilder(BaseNumericalPropertyBuilderMixin):
    def __init__(
        self,
        property_name: str,
        object_set_type: Optional[MethodObjectSet] = None,
    ) -> None:
        DerivedPropertyBuilder.__init__(
            self,
            object_set_type=object_set_type or ObjectSetMethodInputType(type="methodInput"),
            property_name=property_name,
        )
