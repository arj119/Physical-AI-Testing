from typing import TYPE_CHECKING, Union, get_args

from foundry_sdk.v2.ontologies.models import (
    AbsoluteValuePropertyExpression,
    AddPropertyExpression,
    DerivedPropertyDefinition,
    DividePropertyExpression,
    ExtractPropertyExpression,
    GetSelectedPropertyOperation,
    GreatestPropertyExpression,
    LeastPropertyExpression,
    MultiplyPropertyExpression,
    NegatePropertyExpression,
    PropertyApiNameSelector,
    SelectedPropertyApproximateDistinctAggregation,
    SelectedPropertyApproximatePercentileAggregation,
    SelectedPropertyAvgAggregation,
    SelectedPropertyCollectListAggregation,
    SelectedPropertyCollectSetAggregation,
    SelectedPropertyExactDistinctAggregation,
    SelectedPropertyExpression,
    SelectedPropertyMaxAggregation,
    SelectedPropertyMinAggregation,
    SelectedPropertySumAggregation,
    SubtractPropertyExpression,
)

from ._derived_property_builder import DerivedPropertyBuilder

if TYPE_CHECKING:
    from foundry_sdk_runtime.properties import ObjectTypeProperty


class GenericDerivedPropertyBuilderMixin(DerivedPropertyBuilder):
    def collect_to_list(self, limit: int) -> SelectedPropertyExpression:
        return SelectedPropertyExpression(
            objectSet=self._object_set_type,  # type: ignore[call-arg]
            operation=SelectedPropertyCollectListAggregation(
                selectedPropertyApiName=self._property_name,
                limit=limit,  # type: ignore[call-arg]
                type="collectList",
            ),
            type="selection",
        )

    def collect_to_set(self, limit: int) -> SelectedPropertyExpression:
        return SelectedPropertyExpression(
            objectSet=self._object_set_type,  # type: ignore[call-arg]
            operation=SelectedPropertyCollectSetAggregation(
                selectedPropertyApiName=self._property_name,
                limit=limit,  # type: ignore[call-arg]
                type="collectSet",
            ),
            type="selection",
        )

    def exact_distinct(self) -> SelectedPropertyExpression:
        return SelectedPropertyExpression(
            objectSet=self._object_set_type,  # type: ignore[call-arg]
            operation=SelectedPropertyExactDistinctAggregation(
                selectedPropertyApiName=self._property_name,  # type: ignore[call-arg]
                type="exactDistinct",
            ),
            type="selection",
        )

    def approximate_distinct(self) -> SelectedPropertyExpression:
        return SelectedPropertyExpression(
            objectSet=self._object_set_type,  # type: ignore[call-arg]
            operation=SelectedPropertyApproximateDistinctAggregation(
                selectedPropertyApiName=self._property_name,  # type: ignore[call-arg]
                type="approximateDistinct",
            ),
            type="selection",
        )


class GetDerivedPropertyBuilderMixin(DerivedPropertyBuilder):
    def get(self) -> SelectedPropertyExpression:
        return SelectedPropertyExpression(
            objectSet=self._object_set_type,  # type: ignore[call-arg]
            operation=GetSelectedPropertyOperation(
                selectedPropertyApiName=self._property_name,  # type: ignore[call-arg]
                type="get",
            ),
            type="selection",
        )


class BaseDatePropertyBuilderMixin(DerivedPropertyBuilder):
    @property
    def day(self) -> ExtractPropertyExpression:
        return ExtractPropertyExpression(
            property=PropertyApiNameSelector(apiName=self._property_name, type="property"),  # type: ignore[call-arg]
            part="DAYS",
            type="extract",
        )

    @property
    def month(self) -> ExtractPropertyExpression:
        return ExtractPropertyExpression(
            property=PropertyApiNameSelector(apiName=self._property_name, type="property"),  # type: ignore[call-arg]
            part="MONTHS",
            type="extract",
        )

    @property
    def quarter(self) -> ExtractPropertyExpression:
        return ExtractPropertyExpression(
            property=PropertyApiNameSelector(apiName=self._property_name, type="property"),  # type: ignore[call-arg]
            part="QUARTERS",
            type="extract",
        )

    @property
    def year(self) -> ExtractPropertyExpression:
        return ExtractPropertyExpression(
            property=PropertyApiNameSelector(apiName=self._property_name, type="property"),  # type: ignore[call-arg]
            part="YEARS",
            type="extract",
        )


class BaseDatetimePropertyBuilderMixin(BaseDatePropertyBuilderMixin):
    pass


class BaseNumericalPropertyBuilderMixin(DerivedPropertyBuilder):
    @staticmethod
    def _get_properties_for_math_operation(
        *args: Union[DerivedPropertyDefinition, "ObjectTypeProperty", str],
    ) -> list[DerivedPropertyDefinition]:
        from foundry_sdk_runtime.properties import ObjectTypeProperty

        properties = []
        invalid_args = []

        for arg in args:
            # DerivedPropertyDefinition is an Annotated[Union], so we need to first get the Union type,
            # then get the elements of the Union
            if isinstance(arg, get_args(get_args(DerivedPropertyDefinition)[0])):
                properties.append(arg)
            elif isinstance(arg, (DerivedPropertyBuilder, ObjectTypeProperty)):
                properties.append(
                    PropertyApiNameSelector(apiName=arg._property_name, type="property")  # type: ignore[call-arg]
                )
            elif isinstance(arg, str):
                properties.append(PropertyApiNameSelector(apiName=arg, type="property"))  # type: ignore[call-arg]
            else:
                invalid_args.append(arg)

        if invalid_args:
            raise TypeError(
                f"Invalid arguments: {invalid_args}. "
                "Each argument must be one of the following types: "
                "DerivedPropertyDefinition, ObjectTypeProperty, or str. "
                "Please pass a valid property API name, a reference to a property "
                "(e.g., Aircraft.object_type.id), or a derived property math operation "
                "(e.g., Aircraft.object_type.derived.id.div(...))."
            )

        return properties

    def add(self, *args: Union[DerivedPropertyDefinition, "ObjectTypeProperty", str]) -> AddPropertyExpression:
        properties = self.__class__._get_properties_for_math_operation(*args)
        properties.append(
            PropertyApiNameSelector(apiName=self._property_name, type="property")  # type: ignore[call-arg]
        )

        return AddPropertyExpression(properties=properties, type="add")

    def __add__(self, other: Union[DerivedPropertyDefinition, "ObjectTypeProperty"]) -> AddPropertyExpression:
        return self.add(other)

    def div(self, other: Union[DerivedPropertyDefinition, "ObjectTypeProperty", str]) -> DividePropertyExpression:
        other_value = self.__class__._get_properties_for_math_operation(other)[0]

        return DividePropertyExpression(
            left=PropertyApiNameSelector(apiName=self._property_name, type="property"),  # type: ignore[call-arg]
            right=other_value,
            type="divide",
        )

    def __truediv__(self, other: Union[DerivedPropertyDefinition, "ObjectTypeProperty"]) -> DividePropertyExpression:
        return self.div(other)

    def mul(self, *args: Union[DerivedPropertyDefinition, "ObjectTypeProperty", str]) -> MultiplyPropertyExpression:
        properties = self.__class__._get_properties_for_math_operation(*args)
        properties.append(
            PropertyApiNameSelector(apiName=self._property_name, type="property")  # type: ignore[call-arg]
        )

        return MultiplyPropertyExpression(properties=properties, type="multiply")

    def __mul__(self, other: Union[DerivedPropertyDefinition, "ObjectTypeProperty"]) -> MultiplyPropertyExpression:
        return self.mul(other)

    def sub(self, other: Union[DerivedPropertyDefinition, "ObjectTypeProperty", str]) -> SubtractPropertyExpression:
        other_value = self.__class__._get_properties_for_math_operation(other)[0]

        return SubtractPropertyExpression(
            left=PropertyApiNameSelector(apiName=self._property_name, type="property"),  # type: ignore[call-arg]
            right=other_value,
            type="subtract",
        )

    def __sub__(self, other: Union[DerivedPropertyDefinition, "ObjectTypeProperty"]) -> SubtractPropertyExpression:
        return self.sub(other)

    def abs(self) -> AbsoluteValuePropertyExpression:
        return AbsoluteValuePropertyExpression(
            property=PropertyApiNameSelector(apiName=self._property_name, type="property"),  # type: ignore[call-arg]
            type="absoluteValue",
        )

    def __abs__(self) -> AbsoluteValuePropertyExpression:
        return self.abs()

    def negate(self) -> NegatePropertyExpression:
        return NegatePropertyExpression(
            property=PropertyApiNameSelector(apiName=self._property_name, type="property"),  # type: ignore[call-arg]
            type="negate",
        )

    def __neg__(self) -> NegatePropertyExpression:
        return self.negate()

    def least(self, *args: Union[DerivedPropertyDefinition, "ObjectTypeProperty", str]) -> LeastPropertyExpression:
        properties = self.__class__._get_properties_for_math_operation(*args)
        properties.append(
            PropertyApiNameSelector(apiName=self._property_name, type="property")  # type: ignore[call-arg]
        )
        return LeastPropertyExpression(
            properties=properties,
            type="least",
        )

    def greatest(
        self, *args: Union[DerivedPropertyDefinition, "ObjectTypeProperty", str]
    ) -> GreatestPropertyExpression:
        properties = self.__class__._get_properties_for_math_operation(*args)
        properties.append(
            PropertyApiNameSelector(apiName=self._property_name, type="property")  # type: ignore[call-arg]
        )
        return GreatestPropertyExpression(
            properties=properties,
            type="greatest",
        )


class NumericalDerivedPropertyBuilderMixin(DerivedPropertyBuilder):
    def max(self) -> SelectedPropertyExpression:
        return SelectedPropertyExpression(
            objectSet=self._object_set_type,  # type: ignore[call-arg]
            operation=SelectedPropertyMaxAggregation(
                selectedPropertyApiName=self._property_name,  # type: ignore[call-arg]
            ),
            type="selection",
        )

    def min(self) -> SelectedPropertyExpression:
        return SelectedPropertyExpression(
            objectSet=self._object_set_type,  # type: ignore[call-arg]
            operation=SelectedPropertyMinAggregation(
                selectedPropertyApiName=self._property_name,  # type: ignore[call-arg]
            ),
            type="selection",
        )

    def avg(self) -> SelectedPropertyExpression:
        return SelectedPropertyExpression(
            objectSet=self._object_set_type,  # type: ignore[call-arg]
            operation=SelectedPropertyAvgAggregation(
                selectedPropertyApiName=self._property_name,  # type: ignore[call-arg]
            ),
            type="selection",
        )

    def sum(self) -> SelectedPropertyExpression:
        return SelectedPropertyExpression(
            objectSet=self._object_set_type,  # type: ignore[call-arg]
            operation=SelectedPropertySumAggregation(
                selectedPropertyApiName=self._property_name,  # type: ignore[call-arg]
            ),
            type="selection",
        )

    def approximate_percentile(self, approximate_percentile: float) -> SelectedPropertyExpression:
        if not 0 <= approximate_percentile <= 1:
            raise ValueError("approximate_percentile must be between 0 and 1")
        return SelectedPropertyExpression(
            objectSet=self._object_set_type,  # type: ignore[call-arg]
            operation=SelectedPropertyApproximatePercentileAggregation(
                selectedPropertyApiName=self._property_name,  # type: ignore[call-arg]
                approximate_percentile=approximate_percentile,
            ),
            type="selection",
        )
