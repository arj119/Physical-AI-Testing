from typing import Optional

from foundry_sdk.v2.ontologies.models import MethodObjectSet, ObjectSetMethodInputType

from ._derived_property_builder import DerivedPropertyBuilder
from ._mixins import GenericDerivedPropertyBuilderMixin, NumericalDerivedPropertyBuilderMixin


class ManyLinkFloatDerivedPropertyBuilder(NumericalDerivedPropertyBuilderMixin, GenericDerivedPropertyBuilderMixin):
    def __init__(
        self,
        property_name: str,
        object_set_type: Optional[MethodObjectSet] = None,
    ) -> None:
        DerivedPropertyBuilder.__init__(
            self,
            object_set_type=object_set_type or ObjectSetMethodInputType(type="methodInput"),
            property_name=property_name,
        )


class ManyLinkIntegerDerivedPropertyBuilder(NumericalDerivedPropertyBuilderMixin, GenericDerivedPropertyBuilderMixin):
    def __init__(
        self,
        property_name: str,
        object_set_type: Optional[MethodObjectSet] = None,
    ) -> None:
        DerivedPropertyBuilder.__init__(
            self,
            object_set_type=object_set_type or ObjectSetMethodInputType(type="methodInput"),
            property_name=property_name,
        )


class ManyLinkDatetimeDerivedPropertyBuilder(GenericDerivedPropertyBuilderMixin):
    def __init__(
        self,
        property_name: str,
        object_set_type: Optional[MethodObjectSet] = None,
    ) -> None:
        DerivedPropertyBuilder.__init__(
            self,
            object_set_type=object_set_type or ObjectSetMethodInputType(type="methodInput"),
            property_name=property_name,
        )


class ManyLinkDateDerivedPropertyBuilder(GenericDerivedPropertyBuilderMixin):
    def __init__(
        self,
        property_name: str,
        object_set_type: Optional[MethodObjectSet] = None,
    ) -> None:
        DerivedPropertyBuilder.__init__(
            self,
            object_set_type=object_set_type or ObjectSetMethodInputType(type="methodInput"),
            property_name=property_name,
        )


class ManyLinkGenericDerivedPropertyBuilder(GenericDerivedPropertyBuilderMixin):
    def __init__(
        self,
        property_name: str,
        object_set_type: Optional[MethodObjectSet] = None,
    ) -> None:
        DerivedPropertyBuilder.__init__(
            self,
            object_set_type=object_set_type or ObjectSetMethodInputType(type="methodInput"),
            property_name=property_name,
        )
