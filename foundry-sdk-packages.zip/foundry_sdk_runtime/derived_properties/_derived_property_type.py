class DerivedPropertyType:
    """
    Represents a referenced derived property.
    For example: Aircraft.object_type.derived.property("rdp") is a DerivedObjectTypeProperty
    with property_type equal to DerivedPropertyType
    """

    pass
