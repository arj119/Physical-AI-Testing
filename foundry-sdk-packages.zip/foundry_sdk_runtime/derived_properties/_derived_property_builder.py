from typing import Optional

from foundry_sdk.v2.ontologies.models import MethodObjectSet, ObjectSetMethodInputType


class DerivedPropertyBuilder:
    def __init__(
        self,
        property_name: str,
        object_set_type: Optional[MethodObjectSet] = None,
    ):
        self._property_name = property_name
        self._object_set_type = object_set_type or ObjectSetMethodInputType(type="methodInput")
