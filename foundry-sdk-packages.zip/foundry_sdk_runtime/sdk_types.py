from dataclasses import dataclass
from typing import Optional


@dataclass(frozen=True)
class SdkIdentifier:
    rid: str
    version: Optional[str]
