#  (c) Copyright 2023 Palantir Technologies Inc. All rights reserved.
# pylint: disable=super-init-not-called
from typing import TYPE_CHECKING, Any, Type

from foundry_sdk.v2.ontologies.models import (
    AndQueryV2,
    ContainsAllTermsInOrderQuery,
    ContainsAllTermsQuery,
    ContainsAnyTermQuery,
    ContainsQueryV2,
    DoesNotIntersectBoundingBoxQuery,
    DoesNotIntersectPolygonQuery,
    EqualsQueryV2,
    GteQueryV2,
    GtQueryV2,
    InQuery,
    IntersectsBoundingBoxQuery,
    IntersectsPolygonQuery,
    IsNullQueryV2,
    LteQueryV2,
    LtQueryV2,
    NotQueryV2,
    OrQueryV2,
    WithinBoundingBoxQuery,
    WithinDistanceOfQuery,
    WithinPolygonQuery,
)

from foundry_sdk_runtime.geoshapes import BBox, Distance, GeoPoint, Polygon
from foundry_sdk_runtime.properties.expression import ObjectTypeExpression

if TYPE_CHECKING:
    from foundry_sdk_runtime.properties.object_type_property import (
        ObjectTypeProperty,
        ObjectTypePropertyProtocol,
        ObjectTypePropertyWithExpression,
    )

    from .visitor import ExpressionVisitor


class EqualsExpression(ObjectTypeExpression):
    def __init__(self, prop: "ObjectTypeProperty", other: Any) -> None:
        self._prop: "ObjectTypeProperty" = prop
        self._other: Any = other

    def __repr__(self) -> str:
        return f"{self._prop} == {self._other}"

    @classmethod
    def symbol(cls) -> str:
        return "=="

    def accept(self, visitor: Type["ExpressionVisitor"]) -> EqualsQueryV2:
        return visitor._equals(self)


class NotEqualsExpression(ObjectTypeExpression):
    def __init__(self, prop: "ObjectTypeProperty", other: Any) -> None:
        self._expr = EqualsExpression(prop, other)

    def __repr__(self) -> str:
        return f"{self._expr._prop} != {self._expr._other}"

    @classmethod
    def symbol(cls) -> str:
        return "!="

    def accept(self, visitor: Type["ExpressionVisitor"]) -> NotQueryV2:
        return visitor._not_equals(self)


class GreaterThanExpression(ObjectTypeExpression):
    def __init__(self, prop: "ObjectTypeProperty", other: Any) -> None:
        self._prop: "ObjectTypeProperty" = prop
        self._other: Any = other

    def __repr__(self) -> str:
        return f"{self._prop} > {self._other}"

    @classmethod
    def symbol(cls) -> str:
        return ">"

    def accept(self, visitor: Type["ExpressionVisitor"]) -> GtQueryV2:
        return visitor._greater_than(self)


class GreaterThanEqualsExpression(ObjectTypeExpression):
    def __init__(self, prop: "ObjectTypeProperty", other: Any) -> None:
        self._prop: "ObjectTypeProperty" = prop
        self._other: Any = other

    def __repr__(self) -> str:
        return f"{self._prop} >= {self._other}"

    @classmethod
    def symbol(cls) -> str:
        return ">="

    def accept(self, visitor: Type["ExpressionVisitor"]) -> GteQueryV2:
        return visitor._greater_than_equals(self)


class LessThanExpression(ObjectTypeExpression):
    def __init__(self, prop: "ObjectTypeProperty", other: Any) -> None:
        self._prop: "ObjectTypeProperty" = prop
        self._other: Any = other

    def __repr__(self) -> str:
        return f"{self._prop} < {self._other}"

    @classmethod
    def symbol(cls) -> str:
        return "<"

    def accept(self, visitor: Type["ExpressionVisitor"]) -> LtQueryV2:
        return visitor._less_than(self)


class LessThanEqualsExpression(ObjectTypeExpression):
    def __init__(self, prop: "ObjectTypeProperty", other: Any) -> None:
        self._prop: "ObjectTypeProperty" = prop
        self._other: Any = other

    def __repr__(self) -> str:
        return f"{self._prop} <= {self._other}"

    @classmethod
    def symbol(cls) -> str:
        return "<="

    def accept(self, visitor: Type["ExpressionVisitor"]) -> LteQueryV2:
        return visitor._less_than_equals(self)


class AndExpression(ObjectTypeExpression):
    prop: "ObjectTypePropertyWithExpression"
    other: "ObjectTypePropertyWithExpression"

    def __init__(
        self,
        prop: "ObjectTypePropertyWithExpression",
        other: "ObjectTypePropertyWithExpression",
    ) -> None:
        self._prop: "ObjectTypePropertyWithExpression" = prop
        self._other: "ObjectTypePropertyWithExpression" = other

    def __repr__(self) -> str:
        return f"({self._prop}) & ({self._other})"

    @classmethod
    def symbol(cls) -> str:
        return "&"

    def accept(self, visitor: Type["ExpressionVisitor"]) -> AndQueryV2:
        return visitor._and(self)


class OrExpression(ObjectTypeExpression):
    def __init__(
        self,
        prop: "ObjectTypePropertyWithExpression",
        other: "ObjectTypePropertyWithExpression",
    ) -> None:
        self._prop: "ObjectTypePropertyWithExpression" = prop
        self._other: "ObjectTypePropertyWithExpression" = other

    def __repr__(self) -> str:
        return f"({self._prop}) | ({self._other})"

    @classmethod
    def symbol(cls) -> str:
        return "|"

    def accept(self, visitor: Type["ExpressionVisitor"]) -> OrQueryV2:
        return visitor._or(self)


class NegateExpression(ObjectTypeExpression):
    def __init__(self, prop: "ObjectTypePropertyWithExpression") -> None:
        self._prop: "ObjectTypePropertyWithExpression" = prop

    def __repr__(self) -> str:
        return f"~({self._prop})"

    @classmethod
    def symbol(cls) -> str:
        return "~"

    def accept(self, visitor: Type["ExpressionVisitor"]) -> NotQueryV2:
        return visitor._negate(self)


class ArrayContainsExpression(ObjectTypeExpression):
    def __init__(self, prop: "ObjectTypeProperty", other: Any) -> None:
        self._prop: "ObjectTypeProperty" = prop
        self._other: Any = other

    def __repr__(self) -> str:
        return f"{self._prop} in ({self._other})"

    @classmethod
    def symbol(cls) -> str:
        return "contains"

    def accept(self, visitor: Type["ExpressionVisitor"]) -> ContainsQueryV2:
        return visitor._contains(self)


class ContainsAllTermsInOrderExpression(ObjectTypeExpression):
    def __init__(self, prop: "ObjectTypeProperty", other: Any) -> None:
        self._prop: "ObjectTypeProperty" = prop
        self._other: Any = other

    def __repr__(self) -> str:
        return f"{self._prop}.contains_all_terms_in_order({self._other})"

    @classmethod
    def symbol(cls) -> str:
        return ".contains_all_terms_in_order()"

    def accept(self, visitor: Type["ExpressionVisitor"]) -> ContainsAllTermsInOrderQuery:
        return visitor._contains_all_terms_in_order(self)


class ContainsAllTermsInOrderPrefixLastTermExpression(ObjectTypeExpression):
    def __init__(self, prop: "ObjectTypeProperty", other: Any) -> None:
        self._prop: "ObjectTypeProperty" = prop
        self._other: Any = other

    def __repr__(self) -> str:
        return f"{self._prop}.contains_all_terms_in_order({self._other}, prefix_last_term=True)"

    @classmethod
    def symbol(cls) -> str:
        return ".contains_all_terms_in_order(prefix_last_term=True)"

    def accept(self, visitor: Type["ExpressionVisitor"]) -> Any:
        return visitor._contains_all_terms_in_order_prefix_last_term(self)


class ContainsAnyTermExpression(ObjectTypeExpression):
    def __init__(self, prop: "ObjectTypeProperty", other: tuple[Any, bool]) -> None:
        self._prop: "ObjectTypeProperty" = prop
        self._query, self._fuzzy = other

    def __repr__(self) -> str:
        return f"{self._prop}.contains_any_term({self._query}, {self._fuzzy})"

    @classmethod
    def symbol(cls) -> str:
        return ".contains_any_term()"

    def accept(self, visitor: Type["ExpressionVisitor"]) -> ContainsAnyTermQuery:
        return visitor._contains_any_term(self)


class ContainsAllTermsExpression(ObjectTypeExpression):
    def __init__(self, prop: "ObjectTypeProperty", other: tuple[Any, bool]) -> None:
        self._prop: "ObjectTypeProperty" = prop
        self._query, self._fuzzy = other

    def __repr__(self) -> str:
        return f"{self._prop}.contains_all_terms({self._query}, {self._fuzzy})"

    @classmethod
    def symbol(cls) -> str:
        return ".contains_all_terms()"

    def accept(self, visitor: Type["ExpressionVisitor"]) -> ContainsAllTermsQuery:
        return visitor._contains_all_terms(self)


class IsNullExpression(ObjectTypeExpression):
    def __init__(self, prop: "ObjectTypeProperty") -> None:
        self._prop: "ObjectTypeProperty" = prop

    def __repr__(self) -> str:
        return f"{self._prop}.is_null()"

    @classmethod
    def symbol(cls) -> str:
        return ".is_null()"

    def accept(self, visitor: Type["ExpressionVisitor"]) -> IsNullQueryV2:
        return visitor._is_null(self)


class InExpression(ObjectTypeExpression):
    def __init__(self, prop: "ObjectTypePropertyProtocol", values: list[Any]) -> None:
        self._prop = prop
        self._values = values

    def __repr__(self) -> str:
        return f"{self._prop}.in_({self._values})"

    @classmethod
    def symbol(cls) -> str:
        return ".in_()"

    def accept(self, visitor: Type["ExpressionVisitor"]) -> InQuery:
        return visitor._in(self)


class IntersectsPolygonExpression(ObjectTypeExpression):
    def __init__(self, prop: "ObjectTypePropertyProtocol", other: Polygon) -> None:
        self._prop: "ObjectTypePropertyProtocol" = prop
        self._polygon = other

    def __repr__(self) -> str:
        return f"{self._prop}.intersects_polygon({self._polygon})"

    @classmethod
    def symbol(cls) -> str:
        return ".intersects_polygon()"

    def accept(self, visitor: Type["ExpressionVisitor"]) -> IntersectsPolygonQuery:
        return visitor._intersects_polygon(self)


class DoesNotIntersectPolygonExpression(ObjectTypeExpression):
    def __init__(self, prop: "ObjectTypePropertyProtocol", other: Polygon) -> None:
        self._prop: "ObjectTypePropertyProtocol" = prop
        self._polygon = other

    def __repr__(self) -> str:
        return f"{self._prop}.does_not_intersect_polygon({self._polygon})"

    @classmethod
    def symbol(cls) -> str:
        return ".does_not_intersect_polygon()"

    def accept(self, visitor: Type["ExpressionVisitor"]) -> DoesNotIntersectPolygonQuery:
        return visitor._does_not_intersect_polygon(self)


class IntersectsBoundingBoxExpression(ObjectTypeExpression):
    def __init__(self, prop: "ObjectTypePropertyProtocol", bounding_box: BBox) -> None:
        self._prop: "ObjectTypePropertyProtocol" = prop
        self._bounding_box = bounding_box

    def __repr__(self) -> str:
        return f"{self._prop}.intersects_bounding_box({self._bounding_box})"

    @classmethod
    def symbol(cls) -> str:
        return ".intersects_bounding_box()"

    def accept(self, visitor: Type["ExpressionVisitor"]) -> IntersectsBoundingBoxQuery:
        return visitor._intersects_bounding_box(self)


class DoesNotIntersectBoundingBoxExpression(ObjectTypeExpression):
    def __init__(self, prop: "ObjectTypePropertyProtocol", bounding_box: BBox) -> None:
        self._prop: "ObjectTypePropertyProtocol" = prop
        self._bounding_box = bounding_box

    def __repr__(self) -> str:
        return f"{self._prop}.does_not_intersect_bounding_box({self._bounding_box})"

    @classmethod
    def symbol(cls) -> str:
        return ".does_not_intersect_bounding_box()"

    def accept(self, visitor: Type["ExpressionVisitor"]) -> DoesNotIntersectBoundingBoxQuery:
        return visitor._does_not_intersect_bounding_box(self)


class WithinDistanceOfExpression(ObjectTypeExpression):
    def __init__(self, prop: "ObjectTypePropertyProtocol", other: tuple[GeoPoint, Distance]) -> None:
        self._prop: "ObjectTypePropertyProtocol" = prop
        self._location, self._distance = other

    def __repr__(self) -> str:
        return f"{self._prop}.within_distance_of({self._location}, {self._distance})"

    @classmethod
    def symbol(cls) -> str:
        return ".within_distance_of()"

    def accept(self, visitor: Type["ExpressionVisitor"]) -> WithinDistanceOfQuery:
        return visitor._within_distance_of(self)


class WithinBoundingBoxExpression(ObjectTypeExpression):
    def __init__(self, prop: "ObjectTypePropertyProtocol", bounding_box: BBox) -> None:
        self._prop: "ObjectTypePropertyProtocol" = prop
        self._bounding_box = bounding_box

    def __repr__(self) -> str:
        return f"{self._prop}.within_bounding_box({self._bounding_box})"

    @classmethod
    def symbol(cls) -> str:
        return ".within_bounding_box()"

    def accept(self, visitor: Type["ExpressionVisitor"]) -> WithinBoundingBoxQuery:
        return visitor._within_bounding_box(self)


class WithinPolygonExpression(ObjectTypeExpression):
    def __init__(self, prop: "ObjectTypePropertyProtocol", other: Polygon) -> None:
        self._prop: "ObjectTypePropertyProtocol" = prop
        self._polygon = other

    def __repr__(self) -> str:
        return f"{self._prop}.within_polygon({self._polygon})"

    @classmethod
    def symbol(cls) -> str:
        return ".within_polygon()"

    def accept(self, visitor: Type["ExpressionVisitor"]) -> WithinPolygonQuery:
        return visitor._within_polygon(self)
