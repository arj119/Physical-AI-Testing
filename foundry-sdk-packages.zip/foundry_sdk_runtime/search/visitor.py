#  (c) Copyright 2023 Palantir Technologies Inc. All rights reserved.
import abc
from typing import TYPE_CHECKING, Union

from foundry_sdk.v2.ontologies.models import (
    AndQueryV2,
    BoundingBoxValue,
    CenterPoint,
    ContainsAllTermsInOrderPrefixLastTerm,
    ContainsAllTermsInOrderQuery,
    ContainsAllTermsQuery,
    ContainsAnyTermQuery,
    ContainsQueryV2,
    DoesNotIntersectBoundingBoxQuery,
    DoesNotIntersectPolygonQuery,
    EqualsQueryV2,
    GteQueryV2,
    GtQueryV2,
    InQuery,
    IntersectsBoundingBoxQuery,
    IntersectsPolygonQuery,
    IsNullQueryV2,
    LteQueryV2,
    LtQueryV2,
    NotQueryV2,
    OrQueryV2,
    SearchJsonQueryV2,
    WithinBoundingBoxQuery,
    WithinDistanceOfQuery,
    WithinPolygonQuery,
)

from foundry_sdk_runtime.geoshapes import GeoPoint

if TYPE_CHECKING:
    from foundry_sdk_runtime.properties import (
        ObjectTypeExpression,
        ObjectTypePropertyWithExpression,
    )

    from .expression import (
        AndExpression,
        ArrayContainsExpression,
        ContainsAllTermsExpression,
        ContainsAllTermsInOrderExpression,
        ContainsAllTermsInOrderPrefixLastTermExpression,
        ContainsAnyTermExpression,
        DoesNotIntersectBoundingBoxExpression,
        DoesNotIntersectPolygonExpression,
        EqualsExpression,
        GreaterThanEqualsExpression,
        GreaterThanExpression,
        InExpression,
        IntersectsBoundingBoxExpression,
        IntersectsPolygonExpression,
        IsNullExpression,
        LessThanEqualsExpression,
        LessThanExpression,
        NegateExpression,
        NotEqualsExpression,
        OrExpression,
        WithinBoundingBoxExpression,
        WithinDistanceOfExpression,
        WithinPolygonExpression,
    )


class ExpressionVisitor(abc.ABC):
    @classmethod
    @abc.abstractmethod
    def _equals(cls, expression: "EqualsExpression") -> EqualsQueryV2:
        pass

    @classmethod
    @abc.abstractmethod
    def _not_equals(cls, expression: "NotEqualsExpression") -> NotQueryV2:
        pass

    @classmethod
    @abc.abstractmethod
    def _greater_than(cls, expression: "GreaterThanExpression") -> GtQueryV2:
        pass

    @classmethod
    @abc.abstractmethod
    def _greater_than_equals(cls, expression: "GreaterThanEqualsExpression") -> GteQueryV2:
        pass

    @classmethod
    @abc.abstractmethod
    def _less_than(cls, expression: "LessThanExpression") -> LtQueryV2:
        pass

    @classmethod
    @abc.abstractmethod
    def _less_than_equals(cls, expression: "LessThanEqualsExpression") -> LteQueryV2:
        pass

    @classmethod
    @abc.abstractmethod
    def _and(cls, expression: "AndExpression") -> AndQueryV2:
        pass

    @classmethod
    @abc.abstractmethod
    def _or(cls, expression: "OrExpression") -> OrQueryV2:
        pass

    @classmethod
    @abc.abstractmethod
    def _negate(cls, expression: "NegateExpression") -> NotQueryV2:
        pass

    @classmethod
    @abc.abstractmethod
    def _contains(cls, expression: "ArrayContainsExpression") -> ContainsQueryV2:
        pass

    @classmethod
    @abc.abstractmethod
    def _contains_all_terms_in_order(
        cls, expression: "ContainsAllTermsInOrderExpression"
    ) -> ContainsAllTermsInOrderQuery:
        pass

    @classmethod
    @abc.abstractmethod
    def _contains_all_terms_in_order_prefix_last_term(
        cls, expression: "ContainsAllTermsInOrderPrefixLastTermExpression"
    ) -> ContainsAllTermsInOrderPrefixLastTerm:
        pass

    @classmethod
    @abc.abstractmethod
    def _contains_all_terms(cls, expression: "ContainsAllTermsExpression") -> ContainsAllTermsQuery:
        pass

    @classmethod
    @abc.abstractmethod
    def _contains_any_term(cls, expression: "ContainsAnyTermExpression") -> ContainsAnyTermQuery:
        pass

    @classmethod
    @abc.abstractmethod
    def _is_null(cls, expression: "IsNullExpression") -> IsNullQueryV2:
        pass

    @classmethod
    @abc.abstractmethod
    def _in(cls, expression: "InExpression") -> InQuery:
        pass

    @classmethod
    @abc.abstractmethod
    def _intersects_polygon(cls, expression: "IntersectsPolygonExpression") -> IntersectsPolygonQuery:
        pass

    @classmethod
    @abc.abstractmethod
    def _does_not_intersect_polygon(
        cls, expression: "DoesNotIntersectPolygonExpression"
    ) -> DoesNotIntersectPolygonQuery:
        pass

    @classmethod
    @abc.abstractmethod
    def _intersects_bounding_box(cls, expression: "IntersectsBoundingBoxExpression") -> IntersectsBoundingBoxQuery:
        pass

    @classmethod
    @abc.abstractmethod
    def _does_not_intersect_bounding_box(
        cls, expression: "DoesNotIntersectBoundingBoxExpression"
    ) -> DoesNotIntersectBoundingBoxQuery:
        pass

    @classmethod
    @abc.abstractmethod
    def _within_distance_of(cls, expression: "WithinDistanceOfExpression") -> WithinDistanceOfQuery:
        pass

    @classmethod
    @abc.abstractmethod
    def _within_bounding_box(cls, expression: "WithinBoundingBoxExpression") -> WithinBoundingBoxQuery:
        pass

    @classmethod
    @abc.abstractmethod
    def _within_polygon(cls, expression: "WithinPolygonExpression") -> WithinPolygonQuery:
        pass

    @classmethod
    def visit(
        cls,
        expression: Union["ObjectTypeExpression", "ObjectTypePropertyWithExpression"],
    ) -> SearchJsonQueryV2:
        return expression.accept(cls)


class SearchExpressionParser(ExpressionVisitor):
    @classmethod
    def _equals(cls, expression: "EqualsExpression") -> EqualsQueryV2:
        return EqualsQueryV2(field=expression._prop.name, value=expression._other, type="eq")

    @classmethod
    def _not_equals(cls, expression: "NotEqualsExpression") -> NotQueryV2:
        return NotQueryV2(value=cls.visit(expression._expr), type="not")

    @classmethod
    def _greater_than(cls, expression: "GreaterThanExpression") -> GtQueryV2:
        return GtQueryV2(field=expression._prop.name, value=expression._other, type="gt")

    @classmethod
    def _greater_than_equals(cls, expression: "GreaterThanEqualsExpression") -> GteQueryV2:
        return GteQueryV2(field=expression._prop.name, value=expression._other, type="gte")

    @classmethod
    def _less_than(cls, expression: "LessThanExpression") -> LtQueryV2:
        return LtQueryV2(field=expression._prop.name, value=expression._other, type="lt")

    @classmethod
    def _less_than_equals(cls, expression: "LessThanEqualsExpression") -> LteQueryV2:
        return LteQueryV2(field=expression._prop.name, value=expression._other, type="lte")

    @classmethod
    def _and(cls, expression: "AndExpression") -> AndQueryV2:
        return AndQueryV2(
            value=[cls.visit(expression._prop.expr), cls.visit(expression._other.expr)],
            type="and",
        )

    @classmethod
    def _or(cls, expression: "OrExpression") -> OrQueryV2:
        return OrQueryV2(
            value=[cls.visit(expression._prop.expr), cls.visit(expression._other.expr)],
            type="or",
        )

    @classmethod
    def _negate(cls, expression: "NegateExpression") -> NotQueryV2:
        return NotQueryV2(value=cls.visit(expression._prop), type="not")

    @classmethod
    def _contains(cls, expression: "ArrayContainsExpression") -> ContainsQueryV2:
        return ContainsQueryV2(field=expression._prop.name, value=expression._other, type="contains")

    @classmethod
    def _contains_all_terms_in_order(
        cls, expression: "ContainsAllTermsInOrderExpression"
    ) -> ContainsAllTermsInOrderQuery:
        return ContainsAllTermsInOrderQuery(
            field=expression._prop.name,
            value=expression._other,
            type="containsAllTermsInOrder",
        )

    @classmethod
    def _contains_all_terms_in_order_prefix_last_term(
        cls, expression: "ContainsAllTermsInOrderPrefixLastTermExpression"
    ) -> ContainsAllTermsInOrderPrefixLastTerm:
        return ContainsAllTermsInOrderPrefixLastTerm(
            field=expression._prop.name,
            value=expression._other,
            type="containsAllTermsInOrderPrefixLastTerm",
        )

    @classmethod
    def _contains_all_terms(cls, expression: "ContainsAllTermsExpression") -> ContainsAllTermsQuery:
        return ContainsAllTermsQuery(
            field=expression._prop.name,
            value=expression._query,
            fuzzy=expression._fuzzy,
            type="containsAllTerms",
        )

    @classmethod
    def _contains_any_term(cls, expression: "ContainsAnyTermExpression") -> ContainsAnyTermQuery:
        return ContainsAnyTermQuery(
            field=expression._prop.name,
            value=expression._query,
            fuzzy=expression._fuzzy,
            type="containsAnyTerm",
        )

    @classmethod
    def _is_null(cls, expression: "IsNullExpression") -> IsNullQueryV2:
        return IsNullQueryV2(field=expression._prop.name, value=True, type="isNull")

    @classmethod
    def _in(cls, expression: "InExpression") -> InQuery:
        return InQuery(field=expression._prop.name, value=expression._values, type="in")

    @classmethod
    def _intersects_polygon(cls, expression: "IntersectsPolygonExpression") -> IntersectsPolygonQuery:
        return IntersectsPolygonQuery(
            field=expression._prop.name,
            value=expression._polygon,
            type="intersectsPolygon",
        )

    @classmethod
    def _does_not_intersect_polygon(
        cls, expression: "DoesNotIntersectPolygonExpression"
    ) -> DoesNotIntersectPolygonQuery:
        return DoesNotIntersectPolygonQuery(
            field=expression._prop.name,
            value=expression._polygon,
            type="doesNotIntersectPolygon",
        )

    @classmethod
    def _intersects_bounding_box(cls, expression: "IntersectsBoundingBoxExpression") -> IntersectsBoundingBoxQuery:
        return IntersectsBoundingBoxQuery(
            field=expression._prop.name,
            value=BoundingBoxValue(
                top_left=GeoPoint(coordinates=expression._bounding_box[:2], type="Point"),
                bottom_right=GeoPoint(coordinates=expression._bounding_box[2:], type="Point"),
            ),
            type="intersectsBoundingBox",
        )

    @classmethod
    def _does_not_intersect_bounding_box(
        cls, expression: "DoesNotIntersectBoundingBoxExpression"
    ) -> DoesNotIntersectBoundingBoxQuery:
        return DoesNotIntersectBoundingBoxQuery(
            field=expression._prop.name,
            value=BoundingBoxValue(
                top_left=GeoPoint(coordinates=expression._bounding_box[:2], type="Point"),
                bottom_right=GeoPoint(coordinates=expression._bounding_box[2:], type="Point"),
            ),
            type="doesNotIntersectBoundingBox",
        )

    @classmethod
    def _within_distance_of(cls, expression: "WithinDistanceOfExpression") -> WithinDistanceOfQuery:
        return WithinDistanceOfQuery(
            field=expression._prop.name,
            value=CenterPoint(center=expression._location, distance=expression._distance),
            type="withinDistanceOf",
        )

    @classmethod
    def _within_bounding_box(cls, expression: "WithinBoundingBoxExpression") -> WithinBoundingBoxQuery:
        return WithinBoundingBoxQuery(
            field=expression._prop.name,
            value=BoundingBoxValue(
                top_left=GeoPoint(coordinates=expression._bounding_box[:2], type="Point"),
                bottom_right=GeoPoint(coordinates=expression._bounding_box[2:], type="Point"),
            ),
            type="withinBoundingBox",
        )

    @classmethod
    def _within_polygon(cls, expression: "WithinPolygonExpression") -> WithinPolygonQuery:
        return WithinPolygonQuery(
            field=expression._prop.name,
            value=expression._polygon,
            type="withinPolygon",
        )

    @classmethod
    def visit(
        cls,
        expression: Union["ObjectTypeExpression", "ObjectTypePropertyWithExpression"],
    ) -> SearchJsonQueryV2:
        return expression.accept(cls)
