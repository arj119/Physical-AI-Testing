import functools
import warnings
from contextlib import ContextDecorator
from types import TracebackType
from typing import Any, Callable, Optional, Type, TypeVar, cast

IMMUTABLE_TYPES = (int, float, str, tuple, frozenset, bytes)
T = TypeVar("T")


class BetaWarning(UserWarning):
    pass


class WarningControl:
    suppress_warnings = False


class AllowBetaFeatures(ContextDecorator):
    def __enter__(self) -> None:
        self.original_state: bool = WarningControl.suppress_warnings
        WarningControl.suppress_warnings = True

    def __exit__(
        self,
        exc_type: Optional[Type[BaseException]] = None,
        exc_value: Optional[BaseException] = None,
        traceback: Optional[TracebackType] = None,
    ) -> None:
        WarningControl.suppress_warnings = self.original_state


class SuppressBetaWarnings(AllowBetaFeatures):
    def __enter__(self) -> None:
        warnings.warn(
            "SuppressBetaWarnings is deprecated and will be removed in a future version. "
            "Use AllowBetaFeatures instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        super().__enter__()


def beta(message: Optional[str] = None) -> Callable[[T], T]:
    default_message = (
        "Please import AllowBetaFeatures from foundry_sdk_runtime "
        "and execute your code within its context. For example:\n\n"
        "from foundry_sdk_runtime import AllowBetaFeatures\n\n"
        "with AllowBetaFeatures():\n"
        "    <your code>\n\n"
        "If within a Foundry function, add to the function decorator "
        "to allow beta features for the entire functions execution:\n\n"
        "@function(beta=True)\n"
        "def my_function(..."
    )

    def warning() -> None:
        if not WarningControl.suppress_warnings:
            warnings.warn(
                f"{message + ' ' if message else ''}{default_message}",
                category=BetaWarning,
                stacklevel=2,
            )

    def wrap_obj_attribute(obj: T, attr_name: str) -> T:
        """
        Wrap an attribute of an object to alert a BetaWarning.
        """
        original_attr = getattr(obj, attr_name)

        @functools.wraps(original_attr)
        def new_attr(cls: type, *args: Any, **kwargs: Any) -> Any:
            warning()
            return original_attr(cls, *args, **kwargs)

        setattr(obj, attr_name, new_attr)
        return obj

    def decorator(obj: T) -> T:
        if isinstance(obj, type):
            if issubclass(obj, IMMUTABLE_TYPES):
                # Builtin immutable types use __new__ for object creation and initialization.
                return cast(T, wrap_obj_attribute(obj, "__new__"))  # type: ignore[redundant-cast]
            else:
                return cast(T, wrap_obj_attribute(obj, "__init__"))  # type: ignore[redundant-cast]

        elif callable(obj):

            @functools.wraps(obj)
            def wrapper(*args: Any, **kwargs: Any) -> Any:
                warning()
                return obj(*args, **kwargs)

            return cast(T, wrapper)

        elif isinstance(obj, property):

            def getter(instance: Any) -> Any:
                warning()
                if obj.fget is not None:
                    return obj.fget(instance)

            def setter(instance: Any, value: Any) -> None:
                warning()
                if obj.fset is not None:
                    obj.fset(instance, value)

            return cast(T, property(fget=getter, fset=setter, fdel=obj.fdel, doc=obj.__doc__))

        else:
            raise TypeError("The beta_warning decorator can only be applied to classes, functions, or properties.")

    return decorator
