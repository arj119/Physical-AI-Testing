from __future__ import annotations

from foundry_sdk.v2.geo.models import Polygon as PlatformSDKPolygon

from ..types import sanitize_for_hashing
from .geoshape import GeoShape

PlatformSDKPolygon.model_rebuild()


class Polygon(PlatformSDKPolygon, GeoShape):
    """See https://datatracker.ietf.org/doc/html/rfc7946#section-3.1.6"""

    @staticmethod
    def from_geo_json(json_str: str) -> Polygon:
        return Polygon.model_validate_json(json_str)

    def to_geo_json(self) -> str:
        return self.model_dump_json(exclude_unset=True)

    def __hash__(self) -> int:
        return hash(
            (
                type(self),
                sanitize_for_hashing(self.coordinates),
                sanitize_for_hashing(self.bbox),
            )
        )
