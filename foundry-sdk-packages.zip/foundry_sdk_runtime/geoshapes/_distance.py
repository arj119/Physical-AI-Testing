from __future__ import annotations

from foundry_sdk.v2.core.models import Distance as PlatformSDKDistance

from foundry_sdk_runtime.types import sanitize_for_hashing

PlatformSDKDistance.model_rebuild()


class Distance(PlatformSDKDistance):
    @staticmethod
    def from_geo_json(json_str: str) -> Distance:
        return Distance.model_validate_json(json_str)

    def to_geo_json(self) -> str:
        return self.model_dump_json(exclude_unset=True)

    def __hash__(self) -> int:
        return hash(
            (
                type(self),
                sanitize_for_hashing(self.value),
                sanitize_for_hashing(self.unit),
            )
        )
