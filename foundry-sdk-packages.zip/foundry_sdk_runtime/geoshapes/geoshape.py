from abc import ABC, abstractmethod
from typing import Any, Dict


class GeoShape(ABC):
    def to_dict(self) -> Dict[str, Any]: ...  # type: ignore

    @staticmethod
    @abstractmethod
    def from_geo_json(json_str: str) -> "GeoShape": ...

    @abstractmethod
    def to_geo_json(self) -> str:
        pass
