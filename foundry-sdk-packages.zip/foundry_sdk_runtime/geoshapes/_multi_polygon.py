from __future__ import annotations

from foundry_sdk.v2.geo.models import MultiPolygon as PlatformSDKMultiPolygon

from ..types import sanitize_for_hashing
from .geoshape import GeoShape

PlatformSDKMultiPolygon.model_rebuild()


class MultiPolygon(PlatformSDKMultiPolygon, GeoShape):
    @staticmethod
    def from_geo_json(json_str: str) -> MultiPolygon:
        return MultiPolygon.model_validate_json(json_str)

    def to_geo_json(self) -> str:
        return self.model_dump_json(exclude_unset=True)

    def __hash__(self) -> int:
        return hash(
            (
                type(self),
                sanitize_for_hashing(self.coordinates),
                sanitize_for_hashing(self.bbox),
            )
        )
