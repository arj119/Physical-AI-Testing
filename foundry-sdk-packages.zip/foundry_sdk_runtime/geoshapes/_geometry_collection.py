from __future__ import annotations

from foundry_sdk.v2.geo.models import (
    GeometryCollection as PlatformSDKGeometryCollection,
)

from .geoshape import GeoShape

PlatformSDKGeometryCollection.model_rebuild()


# todo(#826): make geometry collections hashable once the platform SDK geo types are hashable
class GeometryCollection(PlatformSDKGeometryCollection, GeoShape):
    @staticmethod
    def from_geo_json(json_str: str) -> GeometryCollection:
        return GeometryCollection.model_validate_json(json_str)

    def to_geo_json(self) -> str:
        return self.model_dump_json(exclude_unset=True)
