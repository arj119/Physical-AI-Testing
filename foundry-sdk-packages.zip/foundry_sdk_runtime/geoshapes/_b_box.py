from foundry_sdk.v2.geo.models import BBox as PlatformSDKBBox

BBox = PlatformSDKBBox
