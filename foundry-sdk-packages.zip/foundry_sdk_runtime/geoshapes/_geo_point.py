from __future__ import annotations

from foundry_sdk.v2.geo.models import GeoPoint as PlatformSDKGeoPoint
from foundry_sdk.v2.geo.models import Position
from pydantic import field_validator

from ..errors import InvalidCoordinatesError
from ..types import sanitize_for_hashing
from .geoshape import GeoShape

PlatformSDKGeoPoint.model_rebuild()


class GeoPoint(PlatformSDKGeoPoint, GeoShape):
    @staticmethod
    def from_geo_json(json_str: str) -> GeoPoint:
        return GeoPoint.model_validate_json(json_str)

    def to_geo_json(self) -> str:
        return self.model_dump_json(exclude_unset=True)

    def __hash__(self) -> int:
        return hash(
            (
                type(self),
                sanitize_for_hashing(self.coordinates),
                sanitize_for_hashing(self.bbox),
            )
        )

    @field_validator("coordinates", mode="after")
    @classmethod
    def validate_lat_lon(cls, coordinates: Position) -> Position:
        # expects to deserialize from lat-lon format
        lon, lat = coordinates[:2]
        invalid_values = {}
        if abs(lon) > 180:
            invalid_values["lon"] = lon
        if abs(lat) > 90:
            invalid_values["lat"] = lat
        if invalid_values:
            raise InvalidCoordinatesError(**invalid_values)
        return coordinates
