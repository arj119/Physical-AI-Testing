import json
from typing import TYPE_CHECKING, Generic, Iterator, List, Optional, TypeVar, Union

from foundry_sdk.v2.ontologies import OntologiesClient
from foundry_sdk.v2.ontologies.models import TimeRange

from foundry_sdk_runtime.helpers import PRIMARY_KEY_UNION_TYPE

from ._time_series_point import TimeSeriesPoint

if TYPE_CHECKING:
    import pyarrow as pa

T = TypeVar("T", float, str, Union[float, str])


class TimeseriesQuery(Generic[T]):
    def __init__(
        self,
        _ontologies_client: OntologiesClient,
        _ontology_rid: str,
        object_type: str,
        object_primary_key: PRIMARY_KEY_UNION_TYPE,
        property_name: str,
        time_range: Optional[TimeRange] = None,
    ):
        self._ontologies_client = _ontologies_client
        self._ontology_rid = _ontology_rid
        self._object_type = object_type
        self._object_primary_key = object_primary_key
        self._property_name = property_name
        self._time_range = time_range

    def __iter__(self) -> Iterator[TimeSeriesPoint[T]]:
        yield from self.iterate()

    def arrow_stream(self) -> "pa.RecordBatchStreamReader":
        try:
            import pyarrow as pa
        except ImportError as e:
            raise ImportError("PyArrow is required for getting the Arrow stream. Please install pyarrow") from e
        stream = self._ontologies_client.TimeSeriesPropertyV2.stream_points(
            ontology=self._ontology_rid,
            object_type=self._object_type,
            primary_key=str(self._object_primary_key),
            property=self._property_name,
            format="ARROW",
            range=self._time_range,
        )

        return pa.ipc.open_stream(stream)

    def all(self) -> List[TimeSeriesPoint[T]]:
        response = self._ontologies_client.TimeSeriesPropertyV2.stream_points(
            ontology=self._ontology_rid,
            object_type=self._object_type,
            primary_key=str(self._object_primary_key),
            property=self._property_name,
            range=self._time_range,
        )

        data = json.loads(response.decode("utf-8"))["data"]
        return [TimeSeriesPoint[T](**point) for point in data]

    def iterate(self) -> Iterator[TimeSeriesPoint[T]]:
        response = self._ontologies_client.TimeSeriesPropertyV2.stream_points(
            ontology=self._ontology_rid,
            object_type=self._object_type,
            primary_key=str(self._object_primary_key),
            property=self._property_name,
            range=self._time_range,
        )
        for point in json.loads(response.decode("utf-8"))["data"]:
            yield TimeSeriesPoint[T](**dict(point.items()))
