#  (c) Copyright 2024 Palantir Technologies Inc. All rights reserved.
from datetime import datetime, timedelta, timezone
from typing import TYPE_CHECKING, Any, Dict, Generic, Optional, TypeVar, Union, cast

from foundry_sdk.v2.ontologies import OntologiesClient
from foundry_sdk.v2.ontologies.models import (
    AbsoluteTimeRange,
    RelativeTime,
    RelativeTimeRange,
    RelativeTimeRelation,
    RelativeTimeSeriesTimeUnit,
    TimeRange,
)

from foundry_sdk_runtime.helpers import PRIMARY_KEY_UNION_TYPE
from foundry_sdk_runtime.types import sanitize_for_hashing

from ._time_series_point import TimeSeriesPoint
from .timeseries_query import TimeseriesQuery
from .types import TimeSeriesPropertyReference

if TYPE_CHECKING:
    import pandas as pd
    import polars as pl

T = TypeVar("T", float, str, Union[float, str])

_SECONDS_PER_MINUTE = 60
_SECONDS_PER_HOUR = 60 * _SECONDS_PER_MINUTE
_SECONDS_PER_DAY = 24 * _SECONDS_PER_HOUR
_SECONDS_PER_WEEK = 7 * _SECONDS_PER_DAY
_SECONDS_PER_YEAR = 365 * _SECONDS_PER_DAY
_STREAM_COLUMN_NAMES = ["timestamp", "value"]


class Timeseries(Generic[T]):
    def __init__(
        self,
        _ontologies_client: OntologiesClient,
        _ontology_rid: Optional[str] = None,
        object_type: Optional[str] = None,
        object_primary_key: Optional[PRIMARY_KEY_UNION_TYPE] = None,
        property_name: Optional[str] = None,
    ) -> None:
        self._ontologies_client = _ontologies_client
        self._ontology_rid = _ontology_rid
        self._object_type = object_type
        self._object_primary_key = object_primary_key
        self._property_name = property_name

    def last_point(self) -> TimeSeriesPoint[T]:
        if not (self._ontology_rid and self._object_type and self._object_primary_key and self._property_name):
            raise AttributeError(
                "Timeseries ontology_rid, object_type, object_primary_key, and property_name must all be set."
            )
        response = self._ontologies_client.TimeSeriesPropertyV2.get_last_point(
            ontology=self._ontology_rid,
            object_type=self._object_type,
            primary_key=str(self._object_primary_key),
            property=self._property_name,
        )
        return TimeSeriesPoint[T].model_validate(response.to_dict())

    def first_point(self) -> TimeSeriesPoint[T]:
        if not (self._ontology_rid and self._object_type and self._object_primary_key and self._property_name):
            raise AttributeError(
                "Timeseries ontology_rid, object_type, object_primary_key, and property_name must all be set."
            )
        response = self._ontologies_client.TimeSeriesPropertyV2.get_first_point(
            ontology=self._ontology_rid,
            object_type=self._object_type,
            primary_key=str(self._object_primary_key),
            property=self._property_name,
        )
        return TimeSeriesPoint[T].model_validate(response.to_dict())

    # this is used by codex clients (eg. FoundryTS) and
    # guarantees that the Timeseries class will always provide
    # these fields
    def get_tsp(self) -> TimeSeriesPropertyReference:
        return TimeSeriesPropertyReference(
            ontology_rid=self._ontology_rid,
            object_type=self._object_type,
            object_primary_key=self._object_primary_key,
            property_name=self._property_name,
        )

    def to_pandas(
        self,
        start: Optional[Union[datetime, timedelta]] = None,
        end: Optional[Union[datetime, timedelta]] = None,
        all_time: bool = False,
        **kwargs: Dict[str, Any],
    ) -> "pd.DataFrame":
        """Generates a Pandas dataframe with the time series points in the time range.

        This is preferred over `.query()` since it streams points in the more efficient Arrow format and
        directly returns the Pandas dataframe.

        The `start` and `end` options should both be either relative (timedelta) or absolute (datetime) but
        not both.

        Pandas and PyArrow are required to be installed in the environment this method is called in, else it raises an `ImportError`.

        Parameters
        ----------
        start : Optional[Union[datetime, timedelta]], optional
            Inclusive start range of the time series, by default None
        end : Optional[Union[datetime, timedelta]], optional
            Inclusive end rnage of the time series, by default None
        all_time : bool, optional
            Set to true for returning all the points, by default False

        Returns
        -------
        pandas.DataFrame
            A Pandas dataframe with the requested points.
        """
        try:
            import pandas as pd  # noqa: F401
        except ImportError as e:
            raise ImportError("Pandas is required for .to_pandas(). Please install pandas") from e

        if not (self._ontology_rid and self._object_type and self._object_primary_key and self._property_name):
            raise AttributeError(
                "Timeseries ontology_rid, object_type, object_primary_key, and property_name must all be set."
            )

        time_range = self._get_time_range(start, end, all_time)

        query = TimeseriesQuery[T](
            _ontologies_client=self._ontologies_client,
            _ontology_rid=self._ontology_rid,
            object_type=self._object_type,
            object_primary_key=self._object_primary_key,
            property_name=self._property_name,
            time_range=time_range,
        )

        stream_reader = query.arrow_stream()
        df = stream_reader.read_all().to_pandas()
        df.columns = _STREAM_COLUMN_NAMES
        return df

    def to_polars(
        self,
        start: Optional[Union[datetime, timedelta]] = None,
        end: Optional[Union[datetime, timedelta]] = None,
        all_time: bool = False,
        **kwargs: Dict[str, Any],
    ) -> "pl.DataFrame":
        """Generates a Polars dataframe with the time series points in the time range.

        This is preferred over `.query()` since it streams points in the more efficient Arrow format and
        directly returns the Polars dataframe.

        The `start` and `end` options should both be either relative (timedelta) or absolute (datetime) but
        not both.

        Polars and PyArrow are required to be installed in the environment this method is called in, else it raises an `ImportError`.

        Parameters
        ----------
        start : Optional[Union[datetime, timedelta]], optional
            Inclusive start range of the time series, by default None
        end : Optional[Union[datetime, timedelta]], optional
            Inclusive end rnage of the time series, by default None
        all_time : bool, optional
            Set to true for returning all the points, by default False

        Returns
        -------
        pandas.DataFrame
            A Polars dataframe with the requested points.
        """
        try:
            import polars as pl
        except ImportError as e:
            raise ImportError("Polars is required for .to_polars(). Please install polars") from e

        if not (self._ontology_rid and self._object_type and self._object_primary_key and self._property_name):
            raise AttributeError(
                "Timeseries ontology_rid, object_type, object_primary_key, and property_name must all be set."
            )

        time_range = self._get_time_range(start, end, all_time)

        query = TimeseriesQuery[T](
            _ontologies_client=self._ontologies_client,
            _ontology_rid=self._ontology_rid,
            object_type=self._object_type,
            object_primary_key=self._object_primary_key,
            property_name=self._property_name,
            time_range=time_range,
        )

        stream_reader = query.arrow_stream()

        return cast(pl.DataFrame, pl.from_arrow(stream_reader, schema=_STREAM_COLUMN_NAMES))

    def query(
        self,
        start: Optional[Union[datetime, timedelta]] = None,
        end: Optional[Union[datetime, timedelta]] = None,
        *,
        all_time: bool = False,
    ) -> TimeseriesQuery[T]:
        """Generates a query for the timeseries data. This query can be one of the following:

        - Absolute between specific timestamps.
        - Relative using timedeltas for the start and end.
        - Retrieving all data from all time.
            - This can be a large amount of data and should be used with caution.

        If using an absolute query, either or both of start and end should be provided as datetimes.
        The datetimes should be timezone-aware, and if naive datetimes are supplied they will be
        interpreted as UTC.

        If using a relative query, either or both of start and end should be provided as timedeltas.
        The timedeltas will be interpreted relative to now. Note that the query only supports
        millisecond precision, and any sub-millisecond values will be truncated. Additionally, only
        a single unit should be used for the timedelta i.e. only days or only minutes.

        For both absolute and relative queries, if either start or end is None the query will be
        unbounded in that direction.

        Example usage:

        ```
        # Absolute query for all data between 2 timestamps
        query = timeseries.query(start=datetime(2024, 1, 1), end=datetime(2024, 2, 1))

        # Absolute query for all data from a timestamp
        query = timeseries.query(start=datetime(2024, 1, 1))

        # Query all data from the last 5 minutes.
        query = timeseries.query(start=timedelta(minutes=-5))

        # Query all data between 1 week ago and 1 week from now
        query = timeseries.query(start=timedelta(weeks=-1), end=timedelta(weeks=1))

        # Query all data from all time.
        query = timeseries.query(all_time=True)
        ```
        """
        if not (self._ontology_rid and self._object_type and self._object_primary_key and self._property_name):
            raise AttributeError(
                "Timeseries ontology_rid, object_type, object_primary_key, and property_name must all be set."
            )

        time_range = self._get_time_range(start, end, all_time)

        return TimeseriesQuery[T](
            _ontologies_client=self._ontologies_client,
            _ontology_rid=self._ontology_rid,
            object_type=self._object_type,
            object_primary_key=self._object_primary_key,
            property_name=self._property_name,
            time_range=time_range,
        )

    def _get_time_range(
        self,
        start: Optional[Union[datetime, timedelta]] = None,
        end: Optional[Union[datetime, timedelta]] = None,
        all_time: bool = False,
    ) -> Optional[TimeRange]:
        if not all_time and start is None and end is None:
            raise ValueError("At least one of start or end must be provided if all_time is False")
        if all_time and (start is not None or end is not None):
            raise ValueError("start and end cannot be provided if all_time is True")
        if all_time:
            time_range: Optional[TimeRange] = None
        else:
            if (isinstance(start, timedelta) or start is None) and (isinstance(end, timedelta) or end is None):
                time_range = RelativeTimeRange(
                    start_time=self._relative_time_range_from_delta(start),
                    end_time=self._relative_time_range_from_delta(end),
                )
            elif (isinstance(start, datetime) or start is None) and (isinstance(end, datetime) or end is None):
                start = self._ensure_not_naive(start)
                end = self._ensure_not_naive(end)

                time_range = AbsoluteTimeRange(start_time=start, end_time=end)
            else:
                raise ValueError("start and end must both be either datetime or timedelta")

        return time_range

    def _relative_time_range_from_delta(self, delta: Optional[timedelta]) -> Optional[RelativeTime]:
        if delta is None:
            return None

        when = "BEFORE" if delta < timedelta() else "AFTER"

        # If milliseconds are provided, need to preserve that precision as milliseconds
        if delta.microseconds >= 1000:
            duration = delta / timedelta(microseconds=1000)
            unit = "MILLISECONDS"
        else:
            # Try and resolve to the biggest unambiguous unit
            duration = delta.total_seconds()
            unit = "SECONDS"
            if duration % (_SECONDS_PER_YEAR) == 0:
                unit = "YEARS"
                duration /= _SECONDS_PER_YEAR
            elif duration % (_SECONDS_PER_WEEK) == 0:
                unit = "WEEKS"
                duration /= _SECONDS_PER_WEEK
            elif duration % (_SECONDS_PER_DAY) == 0:
                unit = "DAYS"
                duration /= _SECONDS_PER_DAY
            elif duration % (_SECONDS_PER_HOUR) == 0:
                unit = "HOURS"
                duration /= _SECONDS_PER_HOUR
            elif duration % _SECONDS_PER_MINUTE == 0:
                unit = "MINUTES"
                duration /= _SECONDS_PER_MINUTE

        return RelativeTime(
            unit=cast(RelativeTimeSeriesTimeUnit, unit), when=cast(RelativeTimeRelation, when), value=abs(int(duration))
        )

    def _ensure_not_naive(self, dt: Optional[datetime]) -> Optional[datetime]:
        if dt is None:
            return None

        if dt.tzinfo is None:
            return dt.replace(tzinfo=timezone.utc)
        return dt

    def __repr__(self) -> str:
        return f"Timeseries({self._property_name})"

    def __eq__(self, other: Any) -> bool:
        return self is other or (
            type(self) is type(other)
            and self._object_type == other._object_type
            and self._object_primary_key == other._object_primary_key
            and self._property_name == other._property_name
        )

    def __hash__(self) -> int:
        return hash(
            (
                type(self),
                sanitize_for_hashing(self._object_type),
                sanitize_for_hashing(self._object_primary_key),
                sanitize_for_hashing(self._property_name),
            )
        )

    def _asdict(self) -> Dict[str, Optional[str]]:
        return {"property_name": self._property_name}

    @staticmethod
    def _fields() -> Dict[str, Any]:
        return {
            "ontology_rid": Optional[str],
            "object_type": Optional[str],
            "object_primary_key": Optional[str],
            "property_name": Optional[str],
        }

    @staticmethod
    def _api_name_to_property_name() -> Dict[str, str]:
        return {
            "ontology_rid": "ontology_rid",
            "object_type": "object_type",
            "object_primary_key": "object_primary_key",
            "property_name": "property_name",
        }
