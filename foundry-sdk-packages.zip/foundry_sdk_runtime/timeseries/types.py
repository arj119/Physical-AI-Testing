# pylint: disable=unused-import
# flake8: noqa: F401
from dataclasses import dataclass
from typing import Optional, TypeVar

from foundry_sdk_runtime.helpers import PRIMARY_KEY_UNION_TYPE

T = TypeVar("T", float, str)


@dataclass
class TimeSeriesPropertyReference:
    ontology_rid: Optional[str]
    object_type: Optional[str]
    object_primary_key: Optional[PRIMARY_KEY_UNION_TYPE]
    property_name: Optional[str]
