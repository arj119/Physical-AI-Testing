from __future__ import annotations

from typing import Generic, TypeVar, Union

from foundry_sdk.v2.ontologies.models import (
    TimeSeriesPoint as PlatformSDKTimeSeriesPoint,
)

PlatformSDKTimeSeriesPoint.model_rebuild()

T = TypeVar("T", float, str, Union[float, str])


class TimeSeriesPoint(PlatformSDKTimeSeriesPoint, Generic[T]):
    """A time and value pair."""

    value: T
