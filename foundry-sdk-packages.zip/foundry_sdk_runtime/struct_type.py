from abc import ABC
from typing import Any

from pydantic import BaseModel


class StructType(BaseModel, ABC):
    model_config = {"populate_by_name": True}

    def to_dict(self) -> dict[str, Any]:
        """Return the dictionary representation of the model using the field aliases."""
        return self.model_dump(by_alias=True, exclude_none=False)
