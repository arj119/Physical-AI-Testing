from __future__ import annotations

from foundry_sdk.v2.ontologies.models import AggregationGroupKeyV2

AggregationGroupKey = AggregationGroupKeyV2
