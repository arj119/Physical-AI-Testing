from typing import List

from foundry_sdk.v2.ontologies.models import AggregateObjectsResponseV2

from ._aggregate_objects_response_item import AggregateObjectsResponseItem

AggregateObjectsResponseV2.model_rebuild()


class AggregateObjectsResponse(AggregateObjectsResponseV2):
    data: List[AggregateObjectsResponseItem]  # type: ignore
