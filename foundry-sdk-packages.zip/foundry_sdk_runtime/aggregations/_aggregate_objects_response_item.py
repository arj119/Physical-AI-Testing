from typing import Dict, List

from foundry_sdk.v2.ontologies.models import AggregateObjectsResponseItemV2

from ._aggregation_group_key import AggregationGroupKey
from ._aggregation_group_value import AggregationGroupValue
from ._aggregation_metric_result import AggregationMetricResult

AggregateObjectsResponseItemV2.model_rebuild()


class AggregateObjectsResponseItem(AggregateObjectsResponseItemV2):
    group: Dict[AggregationGroupKey, AggregationGroupValue]

    metrics: List[AggregationMetricResult]  # type: ignore
