from typing import TYPE_CHECKING, Any, Generic, Optional, Union

from foundry_sdk.v2.ontologies import OntologiesClient

from foundry_sdk_runtime import BaseObjectT
from foundry_sdk_runtime.aggregations import AggregateObjectsResponse

if TYPE_CHECKING:
    from foundry_sdk_runtime.ontology_object_set import BaseOntologyObjectSet


class ComputeStep(Generic[BaseObjectT]):
    def __init__(
        self,
        _ontologies_client: OntologiesClient,
        _ontology_rid: str,
        object_set: "BaseOntologyObjectSet[BaseObjectT]",
        group_by: Optional[list[dict[str, str]]] = None,
        aggregation: Optional[list[dict[str, str]]] = None,
    ):
        self._ontologies_client = _ontologies_client
        self._ontology_rid = _ontology_rid
        self._object_set = object_set
        self._group_by = group_by
        self._aggregation = aggregation

    def compute(self) -> Union[Optional[Any], AggregateObjectsResponse]:
        platform_response = self._ontologies_client.OntologyObjectSet.aggregate(
            ontology=self._ontology_rid,
            aggregation=self._aggregation if self._aggregation else [],
            group_by=self._group_by if self._group_by else [],
            object_set=self._object_set.get_object_set_type().to_dict(),
        )
        response = AggregateObjectsResponse.model_validate(platform_response.to_dict())

        if (not self._group_by) and self._aggregation and (len(self._aggregation) == 1):
            # Used when users call object_set.max, .min, etc. We want to return the value of the single aggregation
            return response.data[0].metrics[0].value
        return response
