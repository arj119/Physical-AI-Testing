#  (c) Copyright 2024 Palantir Technologies Inc. All rights reserved.
from typing import TYPE_CHECKING, Any, Generic, Optional

from foundry_sdk.v2.ontologies import OntologiesClient

from foundry_sdk_runtime import BaseObjectT
from foundry_sdk_runtime.properties import ObjectTypePropertyWithGroupByExpression
from foundry_sdk_runtime.properties.helpers import (
    AggregationType,
    validate_property_type_is_numeric,
)

from . import AggregateObjectsResponse
from .compute_step import ComputeStep

if TYPE_CHECKING:
    from foundry_sdk_runtime.ontology_object_set import BaseOntologyObjectSet
    from foundry_sdk_runtime.properties import ObjectTypeProperty


class GroupedTerminalAggregationOperations(Generic[BaseObjectT]):
    def __init__(
        self,
        _ontologies_client: OntologiesClient,
        _ontology_rid: str,
        object_set: "BaseOntologyObjectSet[BaseObjectT]",
        group_by: Optional[list[dict[str, str]]] = None,
    ):
        self._ontologies_client = _ontologies_client
        self._ontology_rid = _ontology_rid
        self._object_set = object_set
        self._group_by: list[dict[str, str]] = group_by or []

    def count(self) -> ComputeStep[BaseObjectT]:
        return ComputeStep(
            _ontologies_client=self._ontologies_client,
            _ontology_rid=self._ontology_rid,
            object_set=self._object_set,
            group_by=self._group_by,
            aggregation=[{"type": "count"}],
        )

    def _numeric_aggregation(self, prop: "ObjectTypeProperty", aggregation_func: str) -> ComputeStep[BaseObjectT]:
        validate_property_type_is_numeric(prop)
        aggregation = getattr(prop, aggregation_func)()._to_query()
        return ComputeStep(
            _ontologies_client=self._ontologies_client,
            _ontology_rid=self._ontology_rid,
            object_set=self._object_set,
            group_by=self._group_by,
            aggregation=[aggregation],
        )

    def max(self, prop: "ObjectTypeProperty") -> ComputeStep[BaseObjectT]:
        return self._numeric_aggregation(prop, "max")

    def min(self, prop: "ObjectTypeProperty") -> ComputeStep[BaseObjectT]:
        return self._numeric_aggregation(prop, "min")

    def sum(self, prop: "ObjectTypeProperty") -> ComputeStep[BaseObjectT]:
        return self._numeric_aggregation(prop, "sum")

    def avg(self, prop: "ObjectTypeProperty") -> ComputeStep[BaseObjectT]:
        return self._numeric_aggregation(prop, "avg")

    def approximate_distinct(self, prop: "ObjectTypeProperty") -> ComputeStep[BaseObjectT]:
        aggregation = prop.approximate_distinct()._to_query()
        return ComputeStep(
            _ontologies_client=self._ontologies_client,
            _ontology_rid=self._ontology_rid,
            object_set=self._object_set,
            group_by=self._group_by,
            aggregation=[aggregation],
        )

    def exact_distinct(self, prop: "ObjectTypeProperty") -> ComputeStep[BaseObjectT]:
        aggregation = prop.exact_distinct()._to_query()
        return ComputeStep(
            _ontologies_client=self._ontologies_client,
            _ontology_rid=self._ontology_rid,
            object_set=self._object_set,
            group_by=self._group_by,
            aggregation=[aggregation],
        )

    def aggregate(self, multiple_aggregation: dict[str, "AggregationType"]) -> ComputeStep[BaseObjectT]:
        if not isinstance(multiple_aggregation, dict):
            raise TypeError(
                f".aggregate takes in a dict[str:AggregationType]. You supplied: {type(multiple_aggregation)}"
            )
        for name, aggregation_type in multiple_aggregation.items():
            if not isinstance(name, str):
                raise TypeError(f"All names must be of type str. You supplied: {type(name)}")
            if type(aggregation_type) is not AggregationType:
                raise TypeError(
                    "All values passed into .aggregate must be of type AggregationType. E.g. Object.id.max()"
                )
        aggregations = [aggregation._to_query(name) for name, aggregation in multiple_aggregation.items()]
        return ComputeStep(
            _ontologies_client=self._ontologies_client,
            _ontology_rid=self._ontology_rid,
            object_set=self._object_set,
            group_by=self._group_by,
            aggregation=aggregations,
        )


class AggregatableObjectSet(GroupedTerminalAggregationOperations[BaseObjectT]):
    def __init__(
        self,
        _ontologies_client: OntologiesClient,
        _ontology_rid: str,
        object_set: "BaseOntologyObjectSet[BaseObjectT]",
        group_by: Optional[list[dict[str, Any]]] = None,
    ):
        super().__init__(
            _ontologies_client=_ontologies_client,
            _ontology_rid=_ontology_rid,
            object_set=object_set,
            group_by=group_by,
        )

    def group_by(self, expression: ObjectTypePropertyWithGroupByExpression) -> "AggregatableObjectSet[BaseObjectT]":
        if not isinstance(expression, ObjectTypePropertyWithGroupByExpression):
            raise TypeError("group_by can only accept an ObjectTypePropertyWithGroupByExpression")
        group_by = expression.request_body["groupBy"][0]
        if self._group_by:
            for query in self._group_by:
                if query["field"] == group_by["field"]:
                    raise RuntimeError("Duplicate group_by queries.")

        if group_by.get("includeNullValues") and self._object_set._order_by:
            raise TypeError("include_null_values cannot be used with order_by")

        return AggregatableObjectSet(
            _ontologies_client=self._ontologies_client,
            _ontology_rid=self._ontology_rid,
            object_set=self._object_set,
            group_by=self._group_by + [group_by],
        )

    def compute(self) -> Optional[AggregateObjectsResponse]:
        return ComputeStep(
            _ontologies_client=self._ontologies_client,
            _ontology_rid=self._ontology_rid,
            object_set=self._object_set,
            group_by=self._group_by,
        ).compute()
