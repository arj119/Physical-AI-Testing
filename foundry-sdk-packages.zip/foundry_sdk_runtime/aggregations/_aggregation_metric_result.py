from foundry_sdk.v2.ontologies.models import AggregationMetricResultV2

AggregationMetricResultV2.model_rebuild()


class AggregationMetricResult(AggregationMetricResultV2):
    pass
