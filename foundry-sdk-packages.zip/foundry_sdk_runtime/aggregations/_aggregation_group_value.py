from __future__ import annotations

from foundry_sdk.v2.ontologies.models import AggregationGroupValueV2

AggregationGroupValue = AggregationGroupValueV2
