from typing import List, Optional

from foundry_sdk import Config
from foundry_sdk import PublicClientAuth as PlatformSDKPublicClientAuth


class PublicClientAuth(PlatformSDKPublicClientAuth):
    def __init__(
        self,
        client_id: str,
        redirect_url: str,
        hostname: Optional[str] = None,
        scopes: Optional[List[str]] = None,
        should_refresh: bool = True,
        *,
        config: Optional[Config] = None,
    ) -> None:
        self._default_scopes: List[str] = [
            "api:ontologies-read",
            "api:ontologies-write",
            "api:use-ontologies-read",
            "api:use-ontologies-write",
            "api:functions-read",
            "api:use-functions-read",
            "offline_access",
        ]

        super().__init__(
            client_id=client_id,
            redirect_url=redirect_url,
            hostname=hostname,
            scopes=list(set(self._default_scopes + (scopes or []))),
            should_refresh=should_refresh,
            config=config,
        )
