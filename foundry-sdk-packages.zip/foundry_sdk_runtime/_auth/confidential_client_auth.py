from typing import List, Optional

from foundry_sdk import ConfidentialClientAuth as PlatformSDKConfidentialClientAuth
from foundry_sdk import Config


class ConfidentialClientAuth(PlatformSDKConfidentialClientAuth):
    def __init__(
        self,
        client_id: str,
        client_secret: str,
        hostname: Optional[str] = None,
        scopes: Optional[List[str]] = None,
        should_refresh: bool = True,
        *,
        config: Optional[Config] = None,
    ) -> None:
        self._default_scopes: List[str] = [
            "api:ontologies-read",
            "api:ontologies-write",
            "api:use-ontologies-read",
            "api:use-ontologies-write",
            "api:functions-read",
            "api:use-functions-read",
        ]

        # If scopes are provided and not empty, append to default scopes
        # Otherwise, use None
        final_scopes = None
        if scopes:
            final_scopes = list(set(self._default_scopes + scopes))

        super().__init__(
            client_id=client_id,
            client_secret=client_secret,
            hostname=hostname,
            scopes=final_scopes,
            should_refresh=should_refresh,
            config=config,
        )
