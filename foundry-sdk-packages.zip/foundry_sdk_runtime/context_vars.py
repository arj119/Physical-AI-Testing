"""
This module provides context variables for the authentication token and hostname.
They are used as an option to initialize the FoundryClient in the Python OSDK
"""

from contextvars import ContextVar
from typing import Optional

from foundry_sdk import HOSTNAME_VAR, TOKEN_VAR

from .sdk_types import SdkIdentifier

FOUNDRY_TOKEN: ContextVar[Optional[str]] = TOKEN_VAR
FOUNDRY_HOSTNAME: ContextVar[Optional[str]] = HOSTNAME_VAR
FOUNDRY_TOKEN_CONTEXT_VARS: list[ContextVar[Optional[str]]] = [FOUNDRY_TOKEN]
FOUNDRY_HOSTNAME_CONTEXT_VARS: list[ContextVar[Optional[str]]] = [FOUNDRY_HOSTNAME]

FOUNDRY_TRACE_ID: ContextVar[Optional[str]] = ContextVar("FOUNDRY_TRACE_ID", default=None)
FOUNDRY_SPAN_ID: ContextVar[Optional[str]] = ContextVar("FOUNDRY_SPAN_ID", default=None)
FOUNDRY_SAMPLED: ContextVar[Optional[str]] = ContextVar("FOUNDRY_SAMPLED", default=None)
FOUNDRY_TRACE_ID_CONTEXT_VARS: list[ContextVar[Optional[str]]] = [FOUNDRY_TRACE_ID]
FOUNDRY_SPAN_ID_CONTEXT_VARS: list[ContextVar[Optional[str]]] = [FOUNDRY_SPAN_ID]
FOUNDRY_SAMPLED_CONTEXT_VARS: list[ContextVar[Optional[str]]] = [FOUNDRY_SAMPLED]

FOUNDRY_ONTOLOGY_RID: ContextVar[Optional[str]] = ContextVar("FOUNDRY_ONTOLOGY_RID", default=None)
FOUNDRY_ONTOLOGY_RID_CONTEXT_VARS = [FOUNDRY_ONTOLOGY_RID]

FOUNDRY_BRANCH_RID: ContextVar[Optional[str]] = ContextVar("FOUNDRY_BRANCH_RID", default=None)
FOUNDRY_BRANCH_RID_CONTEXT_VARS = [FOUNDRY_BRANCH_RID]

FOUNDRY_DEFAULT_HEADERS_PREPEND: ContextVar[Optional[dict[str, str]]] = ContextVar(
    "FOUNDRY_DEFAULT_HEADERS_PREPEND", default=None
)

FOUNDRY_TRANSACTION_ID: ContextVar[Optional[str]] = ContextVar("FOUNDRY_TRANSACTION_ID", default=None)
FOUNDRY_TRANSACTION_ID_CONTEXT_VARS: list[ContextVar[Optional[str]]] = [FOUNDRY_TRANSACTION_ID]

SDK_IDENTIFIER_MAPPING: ContextVar[Optional[dict[SdkIdentifier, SdkIdentifier]]] = ContextVar(
    "SDK_IDENTIFIER_MAPPING", default=None
)
ATTRIBUTION_RESOURCES: ContextVar[Optional[list[str]]] = ContextVar("ATTRIBUTION_RESOURCES", default=None)
