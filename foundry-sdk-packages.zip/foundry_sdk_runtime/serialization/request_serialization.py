"""
This file contains logic to serialize requests into the json format accepted by API Gateway endpoints
"""

import sys
from datetime import date, datetime, timezone
from typing import Any, Literal

import pydantic

from foundry_sdk_runtime import (
    AllowBetaFeatures,
    BaseOntologyObjectSet,
    OntologyInterface,
    OntologyObject,
    StructType,
    ValueType,
)
from foundry_sdk_runtime.types import Empty


def convert_to_platform_sdk_type(value: Any) -> Any:
    from foundry_sdk.v2.core.models import MediaReference

    from foundry_sdk_runtime.attachments import Attachment, AttachmentMetadata
    from foundry_sdk_runtime.geoshapes import GeoPoint, GeoShape
    from foundry_sdk_runtime.markings import Marking
    from foundry_sdk_runtime.media import Media
    from foundry_sdk_runtime.timeseries import Timeseries
    from foundry_sdk_runtime.vectors import Vector

    if isinstance(value, type) and issubclass(value, OntologyObject):
        return value.api_name()

    if isinstance(value, dict):
        return {
            convert_to_platform_sdk_type(k): convert_to_platform_sdk_type(v)
            for k, v in value.items()
            if not isinstance(v, Empty)
        }
    if isinstance(value, datetime):
        return value.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")
    if isinstance(value, date):
        return value.isoformat()
    if isinstance(value, (Attachment, AttachmentMetadata)):
        return value.rid
    if isinstance(value, (Marking, Vector)):
        return value
    if isinstance(value, GeoPoint):
        return value.to_dict()
    if isinstance(value, GeoShape):
        return value.to_dict()
    if isinstance(value, Timeseries):
        raise NotImplementedError("Timeseries properties are not serializable.")
    if isinstance(value, OntologyInterface):
        object_dict = getattr(value, "_object_dict")
        return {
            "objectTypeApiName": object_dict["$apiName"],
            "primaryKeyValue": object_dict["$primaryKey"],
        }
    if isinstance(value, OntologyObject):
        return value.get_primary_key()
    if isinstance(value, BaseOntologyObjectSet):
        return value.get_object_set_type().to_dict()
    if isinstance(value, StructType):
        return convert_to_platform_sdk_type(value.to_dict())
    if isinstance(value, ValueType):
        if isinstance(value, pydantic.BaseModel):
            return convert_to_platform_sdk_type(value.model_dump(by_alias=True))
        elif isinstance(value, pydantic.RootModel):
            return convert_to_platform_sdk_type(value.model_dump())
        else:
            raise NotImplementedError(
                f"ValueType {type(value)} is not supported for serialization. "
                "Please convert it to a pydantic BaseModel or RootModel before serialization."
            )
    if isinstance(value, list):
        return [convert_to_platform_sdk_type(item) for item in value]
    if isinstance(value, tuple):
        return tuple(convert_to_platform_sdk_type(item) for item in value)

    with AllowBetaFeatures():
        if isinstance(value, Media):
            return value.get_media_reference().to_dict()
        if isinstance(value, MediaReference):
            return value.to_dict()

    numpy = sys.modules.get("numpy")  # Avoid slow import if unnecessary
    if numpy and isinstance(value, numpy.ndarray):
        return [convert_to_platform_sdk_type(item) for item in value.tolist()]

    pandas = sys.modules.get("pandas")  # Avoid slow import if unnecessary
    if pandas and isinstance(value, pandas.DataFrame):
        return [convert_to_platform_sdk_type(item) for item in value.values.tolist()]
    if pandas and isinstance(value, pandas.Series):
        return [convert_to_platform_sdk_type(item) for item in value.tolist()]

    return value


def convert_entry_set(entry_set: dict[Any, Any]) -> list[dict[Literal["key", "value"], Any]]:
    # handle the `EntrySet` data type (https://sourcegraph.palantir.build/github.palantir.build/foundry/api-gateway/-/blob/api-gateway-openapi/src/main/openapi/v1/ontologies-api.yml?L1487)
    return [
        {"key": convert_to_platform_sdk_type(k), "value": convert_to_platform_sdk_type(v)} for k, v in entry_set.items()
    ]


def convert_query_to_platform_sdk_type(query_params: dict[str, Any]) -> Any:
    return {
        k: convert_entry_set(v) if isinstance(v, dict) else convert_to_platform_sdk_type(v)
        for k, v in query_params.items()
        if not isinstance(v, Empty)
    }
