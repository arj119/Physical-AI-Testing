"""
This file contains logic to deserialize responses in the form of JSONs returned from API Gateway endpoints
"""

import inspect
from collections.abc import Iterable
from typing import Any, Union, get_args, get_origin

from foundry_sdk.v2.ontologies import OntologiesClient

from foundry_sdk_runtime import BaseOntologyObjectSet, OntologyObject
from foundry_sdk_runtime.attachments import Attachment
from foundry_sdk_runtime.types import ObjectIterator

from .helpers import PrimaryKeysToObjectsLoader
from .response_deserialization import convert_to_palantir_object, get_non_none_type


def convert_to_query_response_type(
    response_type: Any,
    platform_sdk_response: Any,
    _ontologies_client: OntologiesClient,
    _ontology_rid: str,
) -> Any:
    # pylint: disable=too-many-branches
    # Check if the type is Optional
    if get_origin(response_type) == Union and type(None) in get_args(response_type):
        non_none_type = get_non_none_type(response_type)
        return convert_to_query_response_type(
            response_type=non_none_type,
            platform_sdk_response=platform_sdk_response,
            _ontologies_client=_ontologies_client,
            _ontology_rid=_ontology_rid,
        )

    if get_origin(response_type) is dict and isinstance(platform_sdk_response, list):
        # Case for Queries that return Map types
        # platform_sdk_response returns the keys and values of the dict in a list.
        # For example: [{"key": "1", "value": 2}, ..., {"key": "10", "value": 20}]
        key_type, value_type = get_args(response_type)

        return {
            convert_to_query_response_type(
                response_type=key_type,
                platform_sdk_response=item["key"],
                _ontologies_client=_ontologies_client,
                _ontology_rid=_ontology_rid,
            ): convert_to_query_response_type(
                response_type=value_type,
                platform_sdk_response=item["value"],
                _ontologies_client=_ontologies_client,
                _ontology_rid=_ontology_rid,
            )
            for item in platform_sdk_response
        }

    if get_origin(response_type) is dict and isinstance(platform_sdk_response, dict):
        # Case for Queries that return struct types
        # TODO: Add support for struct types as function outputs. Currently, structs return dict[str, Any].
        # The platform_sdk_response for struct types is the struct as a regular dict
        # For example: {"aircraft": "Boeing", "airport": "JFK"}
        key_type, value_type = get_args(response_type)

        return {
            convert_to_query_response_type(
                response_type=key_type,
                platform_sdk_response=k,
                _ontologies_client=_ontologies_client,
                _ontology_rid=_ontology_rid,
            ): convert_to_query_response_type(
                response_type=value_type,
                platform_sdk_response=v,
                _ontologies_client=_ontologies_client,
                _ontology_rid=_ontology_rid,
            )
            for k, v in platform_sdk_response.items()
        }

    if (get_origin(response_type) is list or getattr(response_type, "__origin__", None) == Iterable) and isinstance(
        platform_sdk_response, list
    ):
        inner_type = get_args(response_type)[0]
        # OntologyObject now inherits from ABC,
        # so issubclass(inner_type, OntologyObject) will throw if inner_type is parameterized
        inner_type = get_origin(inner_type) or inner_type
        if inspect.isclass(inner_type) and issubclass(inner_type, OntologyObject):
            """
            If the type is list[Object], then we want to call the page endpoint and collect all the objects in the list
            instead of calling the 'get' method n objects number of times
            The platform_sdk_response will be a list of primary_keys. e.g. [1, 2, 3]
            """
            primary_key_to_objects_loader = PrimaryKeysToObjectsLoader[OntologyObject](
                _ontologies_client=_ontologies_client,
                _ontology_rid=_ontology_rid,
                object_type=inner_type,
                primary_key_list=platform_sdk_response,
            )
            return list(
                ObjectIterator(
                    paged_func=primary_key_to_objects_loader.load_objects,
                    include_rid=False,
                )
            )
        else:
            return [
                convert_to_query_response_type(
                    response_type=get_args(response_type)[0],
                    platform_sdk_response=item,
                    _ontologies_client=_ontologies_client,
                    _ontology_rid=_ontology_rid,
                )
                for item in platform_sdk_response
            ]

    if inspect.isclass(response_type) and issubclass(get_origin(response_type) or response_type, OntologyObject):
        # when the response_type is an Object Type, the platform_sdk_response is the primary key
        response = _ontologies_client.OntologyObject.get(
            ontology=_ontology_rid,
            object_type=str(response_type.__name__),
            primary_key=str(platform_sdk_response),
            exclude_rid=True,
            select=None,
        )
        return convert_to_palantir_object(
            response_type,
            response,
            _ontologies_client=_ontologies_client,
            _ontology_rid=_ontology_rid,
            paged_response=False,
        )

    if inspect.isclass(response_type) and issubclass(response_type, BaseOntologyObjectSet):
        # When the response_type is an Ontology Object Set, then the platform_sdk_response is the Object Set RID.
        return response_type.init_from_object_set_rid(
            object_set_rid=platform_sdk_response, _ontologies_client=_ontologies_client
        )

    if response_type == Attachment:
        return Attachment(_ontologies_client=_ontologies_client, rid=platform_sdk_response)

    return convert_to_palantir_object(
        response_type,
        platform_sdk_response,
        _ontologies_client=_ontologies_client,
        _ontology_rid=_ontology_rid,
        paged_response=False,
    )
