"""
This file is used to convert Types into types recognized by Functions
Refer to: https://github.palantir.build/foundry/function-execution/blob/0890f90eb1405759c6554e0f863da58519ed29e7/function-executor-api/src/main/conjure/function-executor-api.yml
"""

import json
import sys
from datetime import date, datetime
from typing import Any, get_args

import pydantic
from foundry_sdk.v2.core.models import MediaReference

from foundry_sdk_runtime import AllowBetaFeatures, BaseOntologyObjectSet, Marking, OntologyObject, ValueType
from foundry_sdk_runtime.media import Media
from foundry_sdk_runtime.struct_type import StructType


def serialize_media_reference(media_reference: MediaReference) -> dict[str, Any]:
    """
    Actions expects MediaReferences to have the same dict representation as their MediaReferenceValue
    https://github.palantir.build/foundry/actions/blob/b5c73282b15684d0e4ea04e23b3f0725b56f89f7/actions-api/src/main/conjure/types.yml#L680-L682
    but this differs slightly from api-gateway's MediaReference
    https://github.palantir.build/foundry/api-gateway/blob/d8c2f50a69ae9a45da592827e27c188d7464570c/api-gateway-openapi/src/main/openapi/common/media-reference.yml#L64-L66
    The types are different in that the reference type is "mediaSetViewItem" in gateway, and "mediaViewItem" in actions
    This helper function returns the correct MediaReference json that Actions expects for Ontology Edits.
    """
    media_reference_dict = media_reference.to_dict()
    media_reference_dict["reference"] = {
        "mediaViewItem": media_reference_dict["reference"]["mediaSetViewItem"],
        "type": "mediaViewItem",
    }
    return media_reference_dict


def serialize_value(value: Any) -> Any:
    from foundry_sdk.v2.geo.models import Geometry, GeoPoint

    from foundry_sdk_runtime.attachments import Attachment, AttachmentMetadata
    from foundry_sdk_runtime.timeseries import Timeseries

    if isinstance(value, dict):
        return {k: serialize_value(v) for k, v in value.items()}
    if isinstance(value, datetime):
        return int(value.timestamp() * 1000)
    if isinstance(value, date):
        return value.isoformat()
    if isinstance(value, (Attachment, AttachmentMetadata)):
        return value.rid
    if isinstance(value, GeoPoint):
        lon, lat = value.to_dict()["coordinates"][:2]
        return f"{lat},{lon}"
    # Geometry is an Annotated[Union], so we need to first get the Union type, then get the elements of the Union
    if isinstance(value, get_args(get_args(Geometry)[0])):
        return json.dumps(value.to_dict())
    if isinstance(value, Marking):
        return str(value)
    if isinstance(value, Timeseries):
        raise NotImplementedError("Timeseries properties are not serializable into function types.")
    if isinstance(value, OntologyObject):
        return value.get_primary_key()
    if isinstance(value, BaseOntologyObjectSet):
        return value.get_object_set_rid()
    if isinstance(value, ValueType):
        if isinstance(value, pydantic.BaseModel):
            return serialize_value(value.model_dump(by_alias=True))
        elif isinstance(value, pydantic.RootModel):
            return serialize_value(value.model_dump())
        else:
            raise NotImplementedError(
                f"ValueType {type(value)} is not supported for serialization. "
                "Please convert it to a pydantic BaseModel or RootModel before serialization."
            )

    if isinstance(value, StructType):
        return serialize_value(value.to_dict())
    if isinstance(value, list):
        return [serialize_value(item) for item in value]

    numpy = sys.modules.get("numpy")  # Avoid slow import if unnecessary
    if numpy and isinstance(value, numpy.ndarray):
        return [serialize_value(item) for item in value.tolist()]

    pandas = sys.modules.get("pandas")  # Avoid slow import if unnecessary
    if pandas and isinstance(value, pandas.DataFrame):
        return [serialize_value(item) for item in value.values.tolist()]
    if pandas and isinstance(value, pandas.Series):
        return [serialize_value(item) for item in value.tolist()]

    with AllowBetaFeatures():
        if isinstance(value, Media):
            return serialize_media_reference(value.get_media_reference())
        if isinstance(value, MediaReference):
            return serialize_media_reference(value)

    return value


def serialize_json_for_ontology_edits(request: dict[str, Any]) -> dict[str, Any]:
    assert isinstance(request, dict), "Request body must be a dictionary"
    return {k: serialize_value(v) for k, v in request.items()}
