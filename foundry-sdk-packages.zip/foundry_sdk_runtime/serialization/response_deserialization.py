"""
This file contains logic to deserialize responses in the form of JSONs returned from API Gateway endpoints
"""

import inspect
import re
from collections.abc import Iterable
from datetime import date, datetime, timezone
from enum import EnumMeta
from functools import lru_cache
from importlib import import_module
from typing import Any, ForwardRef, Literal, Optional, Type, Union, get_args, get_origin

import ciso8601
import pydantic
from dateutil.parser import parse
from foundry_sdk.v2.ontologies import OntologiesClient
from foundry_sdk.v2.ontologies.models import QueryThreeDimensionalAggregation, QueryTwoDimensionalAggregation

from foundry_sdk_runtime import OntologyInterface, ValueType
from foundry_sdk_runtime.attachments import Attachment
from foundry_sdk_runtime.geoshapes import (
    GeometryCollection,
    GeoPoint,
    GeoShape,
    LineString,
    MultiLineString,
    MultiPoint,
    MultiPolygon,
    Polygon,
)
from foundry_sdk_runtime.helpers import get_only_element
from foundry_sdk_runtime.media import Media
from foundry_sdk_runtime.ontology_object import BaseObject
from foundry_sdk_runtime.struct_type import StructType
from foundry_sdk_runtime.timeseries import Timeseries
from foundry_sdk_runtime.types import get_type_module

NoneType = type(None)
_PRIMITIVE_TYPES = (str, int, float, bool)

_KEY_NORMALIZATION_MAP = {
    "__primaryKey": "$primaryKey",
    "__apiName": "$apiName",
    "__title": "$title",
    "__rid": "$rid",
}


def _normalize_object_keys(obj: dict[str, Any], property_api_names: set[str]) -> dict[str, Any]:
    """
    Normalizes keys prefixed with '__' to '$' that are NOT actual property API names on the object type.
    This prevents properties named '__rid' from being incorrectly converted to '$rid'.
    """
    return {_KEY_NORMALIZATION_MAP.get(k, k) if k not in property_api_names else k: v for k, v in obj.items()}


def dereference_forward_type_or_string(object_type: Any) -> Type[Any]:
    if _isinstance_cached(object_type, ForwardRef):
        object_type = object_type.__forward_arg__
    if _isinstance_cached(object_type, str):
        object_type = getattr(import_module(get_type_module(object_type)), object_type)
    if not _isinstance_cached(object_type, type):
        raise ValueError("expected reference to type")
    return object_type  # type: ignore[no-any-return]


@lru_cache(maxsize=1000)
def get_non_none_type(optional_type: Optional[Any]) -> Any:
    non_none_type = tuple(arg for arg in _get_args_cached(optional_type) if arg is not NoneType)
    return non_none_type[0] if len(non_none_type) == 1 else Union[non_none_type]


@lru_cache(maxsize=2000)
def unwrap_optional(object_type: Any) -> Any:
    origin = _get_origin_cached(object_type)
    if origin == Union:
        args = _get_args_cached(object_type)
        if NoneType in args:
            return get_non_none_type(object_type)
    return object_type


def convert_to_palantir_object(
    object_type: Any,
    obj: Any,
    _ontologies_client: OntologiesClient,
    _ontology_rid: Optional[str] = None,
    paged_response: bool = False,
    interface_to_object_type_mappings: Optional[dict[str, dict[str, dict[str, str]]]] = None,
) -> Any:
    # pylint: disable=too-many-branches
    if obj is None:
        return None
    object_type = unwrap_optional(object_type)

    # Fast path for common primitive types
    if object_type in _PRIMITIVE_TYPES:
        return object_type(obj)

    obj_isinstance_dict: bool = isinstance(obj, dict)
    if object_type == Any or _get_origin_cached(object_type) == Literal:
        return obj
    if _isinstance_cached(object_type, ForwardRef):  # Extract type name (str) from ForwardRef
        object_type = object_type.__forward_arg__
        return convert_to_palantir_object(
            object_type=object_type,
            obj=obj,
            _ontologies_client=_ontologies_client,
            _ontology_rid=_ontology_rid,
            paged_response=paged_response,
            interface_to_object_type_mappings=interface_to_object_type_mappings,
        )
    if _isinstance_cached(object_type, str):  # Reference to a generated type, so import the type and dereference
        dereferenced_object_type: Type[Any] = getattr(
            import_module(get_type_module(object_type)),
            object_type if object_type != "Point" else "GeoPoint",
        )
        return convert_to_palantir_object(
            object_type=dereferenced_object_type,
            obj=obj,
            _ontologies_client=_ontologies_client,
            _ontology_rid=_ontology_rid,
            paged_response=paged_response,
            interface_to_object_type_mappings=interface_to_object_type_mappings,
        )
    if _get_origin_cached(object_type) == Union:
        # if object_type is Optional
        if NoneType in _get_args_cached(object_type):
            non_none_type = get_non_none_type(object_type)
            return convert_to_palantir_object(
                object_type=non_none_type,
                obj=obj,
                _ontologies_client=_ontologies_client,
                _ontology_rid=_ontology_rid,
                paged_response=paged_response,
                interface_to_object_type_mappings=interface_to_object_type_mappings,
            )

        if obj_isinstance_dict and "type" in obj:  # Union fields will have a field "type"
            # We assume there will be exactly one subtype matching the returned 'type' field
            inner_type = get_only_element(
                [
                    sub_type
                    for sub_type in object_type.__args__
                    if _normalize_identifier(dereference_forward_type_or_string(sub_type).__name__)
                    == _normalize_identifier(obj["type"])
                ]
            )
            del obj["type"]
            return convert_to_palantir_object(
                object_type=inner_type,
                obj=obj,
                _ontologies_client=_ontologies_client,
                _ontology_rid=_ontology_rid,
                paged_response=paged_response,
                interface_to_object_type_mappings=interface_to_object_type_mappings,
            )

        return convert_to_palantir_object(
            object_type=get_args(object_type)[0],
            obj=obj,
            _ontologies_client=_ontologies_client,
            _ontology_rid=_ontology_rid,
            paged_response=paged_response,
            interface_to_object_type_mappings=interface_to_object_type_mappings,
        )
    if _get_origin_cached(object_type) is dict and obj_isinstance_dict:
        key_type, value_type = _get_args_cached(object_type)
        return {
            convert_to_palantir_object(
                object_type=key_type,
                obj=k,
                _ontologies_client=_ontologies_client,
                _ontology_rid=_ontology_rid,
                paged_response=paged_response,
                interface_to_object_type_mappings=interface_to_object_type_mappings,
            ): convert_to_palantir_object(
                object_type=value_type,
                obj=v,
                _ontologies_client=_ontologies_client,
                _ontology_rid=_ontology_rid,
                paged_response=paged_response,
                interface_to_object_type_mappings=interface_to_object_type_mappings,
            )
            for k, v in obj.items()
        }
    if (_get_origin_cached(object_type) is list or getattr(object_type, "__origin__", None) == Iterable) and isinstance(
        obj, list
    ):
        return [
            convert_to_palantir_object(
                object_type=get_args(object_type)[0],
                obj=x,
                _ontologies_client=_ontologies_client,
                _ontology_rid=_ontology_rid,
                paged_response=paged_response,
                interface_to_object_type_mappings=interface_to_object_type_mappings,
            )
            for x in obj
        ]
    if object_type == datetime or object_type == date:
        assert isinstance(obj, str), "Cannot instantiate datetime from a non-string response"

        try:
            dt = ciso8601.parse_datetime(obj)
            if dt.tzinfo is None:  # ciso8601 already parses timezone info correctly, but ensure UTC if needed
                dt = dt.replace(tzinfo=timezone.utc)
        except Exception:
            dt = parse(obj).replace(tzinfo=timezone.utc)

        if object_type == date:
            return dt.date()
        return dt
    if _is_class_cached(object_type) and (
        _issubclass_cached(object_type, QueryTwoDimensionalAggregation)
        or _issubclass_cached(object_type, QueryThreeDimensionalAggregation)
    ):
        return object_type.model_validate(obj)
    if _is_class_cached(object_type) and _issubclass_cached(object_type, GeoShape) and "type" in obj:
        if obj["type"] == "GeometryCollection":
            return GeometryCollection(
                geometries=[
                    convert_to_palantir_object(
                        object_type=i["type"],
                        obj=i,
                        _ontologies_client=_ontologies_client,
                        _ontology_rid=_ontology_rid,
                        paged_response=paged_response,
                        interface_to_object_type_mappings=interface_to_object_type_mappings,
                    )
                    for i in obj["geometries"]
                ],
                bbox=None,
                type=obj["type"],
            )
        elif obj["type"] == "Point":
            return GeoPoint(coordinates=obj["coordinates"], type=obj["type"])
        elif obj["type"] == "LineString":
            return LineString(coordinates=obj["coordinates"], type=obj["type"])
        elif obj["type"] == "MultiLineString":
            return MultiLineString(coordinates=obj["coordinates"], type=obj["type"])
        elif obj["type"] == "MultiPoint":
            return MultiPoint(coordinates=obj["coordinates"], type=obj["type"])
        elif obj["type"] == "MultiPolygon":
            return MultiPolygon(coordinates=obj["coordinates"], type=obj["type"])
        elif obj["type"] == "Polygon":
            return Polygon(coordinates=obj["coordinates"], type=obj["type"])
        else:
            raise NotImplementedError(f"{object_type} is an unsupported GeoShape.")
    if object_type == Attachment and "rid" in obj:
        # Attachment Properties returned from gateway look like "permit": {"rid": "attachment_rid"}
        return Attachment(_ontologies_client=_ontologies_client, rid=obj["rid"])
    if object_type == Timeseries or _get_origin_cached(object_type) == Timeseries:
        # We reinitialize Timeseries properties when Ontology Objects are initialized.
        return Timeseries(_ontologies_client=_ontologies_client, _ontology_rid=_ontology_rid)
    if obj_isinstance_dict and (object_type == Media or _get_origin_cached(object_type) == Media):
        # Media properties returned from gateway look like:
        # {'mimeType': 'type/here', 'reference': {'type': 'mediaSetViewItem', 'mediaSetViewItem':
        # {'mediaSetRid': 'ri.mio.main.media-set.1234', 'mediaSetViewRid': 'ri.mio.main.view.2345',
        # 'mediaItemRid': 'ri.mio.main.media-item.3456'}}}
        if "mimeType" in obj and "reference" in obj:
            # object_type, object_primary_key, and property_name get's set during `object_type(**formatted_dict)`
            from foundry_sdk.v2.core.models import MediaReference, Reference

            return Media(
                _ontologies_client=_ontologies_client,
                _ontology_rid=_ontology_rid,
                media_reference=MediaReference(mime_type=obj["mimeType"], reference=Reference(**obj["reference"])),
            )
    if obj_isinstance_dict and _issubclass_cached(object_type, StructType):
        return object_type.model_validate(obj, context={"ontologies_client": _ontologies_client})
    if obj_isinstance_dict and _issubclass_cached(object_type, ValueType):
        if _issubclass_cached(object_type, pydantic.BaseModel):
            # If the ValueType is a Pydantic BaseModel, we can use model_validate to convert it
            return object_type.model_validate(obj)
        elif _issubclass_cached(object_type, pydantic.RootModel):
            # If the ValueType is a Pydantic RootModel, we can use model_validate to convert it
            return object_type.model_validate(obj)
        else:
            raise NotImplementedError(
                f"ValueType {object_type} is not supported for deserialization. "
                "Please convert it to a pydantic BaseModel or RootModel before deserialization."
            )
    if _is_class_cached(object_type) and _issubclass_cached(object_type, OntologyInterface):
        if not interface_to_object_type_mappings:
            raise RuntimeError(
                "No interface_to_object_type_mappings provided. Unable to instantiate OntologyInterface."
            )
        interface_prop_to_obj_prop = interface_to_object_type_mappings[object_type.api_name()][obj["$apiName"]]
        obj_prop_to_interface_prop = {v: k for k, v in interface_prop_to_obj_prop.items()}
        interface_properties = {
            obj_prop_to_interface_prop[prop]: prop_val
            for prop, prop_val in obj.items()
            if prop in obj_prop_to_interface_prop
        }
        if obj.get("$rid"):
            interface_properties["$rid"] = obj["$rid"]

        property_types = object_type._fields()
        formatted_dict = {
            object_type._api_name_to_property_name()[prop_api_name]: convert_to_palantir_object(
                object_type=property_types[prop_api_name],
                obj=prop_value,
                _ontologies_client=_ontologies_client,
                _ontology_rid=_ontology_rid,
                paged_response=paged_response,
                interface_to_object_type_mappings=interface_to_object_type_mappings,
            )
            for prop_api_name, prop_value in interface_properties.items()
            if prop_api_name in property_types
        }
        if _ontologies_client and _constructor_accepts_parameter("_ontologies_client", object_type):
            formatted_dict["_ontologies_client"] = _ontologies_client
        if _ontology_rid and _constructor_accepts_parameter("_ontology_rid", object_type):
            formatted_dict["_ontology_rid"] = _ontology_rid

        interface_instance = object_type(**formatted_dict)
        # _object_dict is used to cast the interface into its underlying object
        setattr(interface_instance, "_object_dict", obj)

        setattr(interface_instance, "_initialized", True)
        return interface_instance
    if _is_class_cached(object_type) and _issubclass_cached(get_origin(object_type) or object_type, BaseObject):
        property_types = object_type._fields()
        # Normalize keys: load endpoint returns __-prefixed keys, load_multiple_object_types returns $-prefixed keys
        obj = _normalize_object_keys(obj, set(property_types.keys()))
        # attributes of objects returned by api gateway in addition to the object's properties
        additional_object_attributes = [
            "$primaryKey",
            "$apiName",
            "$title",
            "$rid",
            "$score",
        ]
        known_keys = set(additional_object_attributes) | set(property_types.keys())
        derived_properties = [k for k in obj.keys() if k not in known_keys]
        formatted_dict = {
            object_type._api_name_to_property_name()[prop_api_name]: convert_to_palantir_object(
                property_types[prop_api_name],
                prop_value,
                _ontologies_client,
                _ontology_rid,
            )
            for prop_api_name, prop_value in obj.items()
            if prop_api_name in property_types
        }
        if _ontologies_client and _constructor_accepts_parameter("_ontologies_client", object_type):
            formatted_dict["_ontologies_client"] = _ontologies_client
        if _ontology_rid and _constructor_accepts_parameter("_ontology_rid", object_type):
            formatted_dict["_ontology_rid"] = _ontology_rid

        object_instance = object_type(**formatted_dict)
        for property in derived_properties:
            setattr(object_instance, property, obj.get(property, None))
        # Setting the _initialized property prevents the object from being modified after initialization
        setattr(object_instance, "_initialized", True)
        return object_instance
    if obj_isinstance_dict:
        property_types = object_type._fields()
        formatted_dict = {
            object_type._api_name_to_property_name()[prop_api_name]: convert_to_palantir_object(
                property_types[prop_api_name],
                prop_value,
                _ontologies_client,
                _ontology_rid,
            )
            for prop_api_name, prop_value in obj.items()
            if prop_api_name in property_types
        }
        if _ontologies_client and _constructor_accepts_parameter("_ontologies_client", object_type):
            formatted_dict["_ontologies_client"] = _ontologies_client
        if _ontology_rid and _constructor_accepts_parameter("_ontology_rid", object_type):
            formatted_dict["_ontology_rid"] = _ontology_rid
        return object_type(**formatted_dict)
    if _is_class_cached(object_type) and _issubclass_cached(object_type, EnumMeta):
        if not isinstance(obj, str):
            raise ValueError(f"Expected string to get enum value, got {obj}")
        return getattr(object_type, obj)
    return object_type(obj)


@lru_cache(maxsize=1000)
def _constructor_accepts_parameter(param_name: str, type: type) -> bool:
    return hasattr(type, "__init__") and param_name in inspect.signature(type.__init__).parameters  # type: ignore[misc]


@lru_cache(maxsize=1000)
def _get_origin_cached(object_type: type) -> Any:
    return get_origin(object_type)


@lru_cache(maxsize=1000)
def _is_class_cached(object_type: type) -> bool:
    return inspect.isclass(object_type)


@lru_cache(maxsize=1000)
def _get_args_cached(object_type: type) -> Any:
    return get_args(object_type)


@lru_cache(maxsize=1000)
def _issubclass_cached(object_type: type, other_type: type) -> bool:
    return issubclass(object_type, other_type)


@lru_cache(maxsize=1000)
def _isinstance_cached(object_type: type, other_type: type) -> bool:
    return isinstance(object_type, other_type)


_UPPER_RE = re.compile(r"([A-Z]+)")


@lru_cache(maxsize=100)
def _normalize_identifier(text: str) -> str:
    """
    This helper snake_cases identifiers. However, we do not wish
    for it to be used as a `to_snake_case` method. It is used solely for the
    purpose of de-PascalCasing API names that were PascalCased for
    __name__s of codegenerated classes, for the purpose of comparing with
    the original API names sent in responses. This helper's only use should
    be in the `convert_to_palantir_object` function in `response_deserialization.py`.

    In the future, we plan on ensuring that the original API name is also
    persisted in the codegen, and using that instead of attempting to undo
    the PascalCasing via this function.
    """
    text = text.replace("-", "")
    if len(text) > 0 and text[0].isupper():
        text = text[0].lower() + text[1:]
    return _UPPER_RE.sub(r"_\1", text).lower()
