from typing import Any, Generic, Iterable, Optional, Tuple

from foundry_sdk.v2.ontologies import OntologiesClient
from foundry_sdk.v2.ontologies.models import (
    InQuery,
    ObjectSetBaseType,
    ObjectSetFilterType,
)

from foundry_sdk_runtime.ontology_object import OntologyObjectT

from .request_serialization import convert_to_platform_sdk_type
from .response_deserialization import convert_to_palantir_object


class PrimaryKeysToObjectsLoader(Generic[OntologyObjectT]):
    """
    Takes the list of primary keys from an object, and provides a load objects method
    """

    object_type: type[OntologyObjectT]

    def __init__(
        self,
        _ontologies_client: OntologiesClient,
        _ontology_rid: str,
        object_type: type[OntologyObjectT],
        primary_key_list: list[Any],
    ):
        self._ontologies_client = _ontologies_client
        self._ontology_rid = _ontology_rid
        self.object_type = object_type
        self.primary_key_list = convert_to_platform_sdk_type(primary_key_list)
        self.object_set_type = ObjectSetFilterType(
            object_set=ObjectSetBaseType(object_type=self.object_type.api_name()),
            where=InQuery(
                field=self.object_type.primary_key(),
                value=self.primary_key_list,
                type="in",
            ),
        )

    def load_objects(
        self,
        include_rid: bool = False,
        page_size: Optional[int] = None,
        next_page_token: Optional[str] = None,
        snapshot: Optional[bool] = None,
    ) -> Tuple[Optional[str], list[OntologyObjectT]]:
        response = self._ontologies_client.OntologyObjectSet.load(
            ontology=self._ontology_rid,
            object_set=self.object_set_type,
            select=[],
            select_v2=[],
            exclude_rid=not include_rid,
            order_by=None,
            page_size=page_size,
            page_token=next_page_token,
            snapshot=snapshot,
        )

        result = convert_to_palantir_object(
            Iterable[self.object_type],  # type: ignore[name-defined]
            response.data,
            _ontologies_client=self._ontologies_client,
            _ontology_rid=self._ontology_rid,
            paged_response=True,
        )

        return response.next_page_token, result
