import os
from contextvars import ContextVar
from typing import Optional, TypeVar

from foundry_sdk import EnvironmentNotConfigured

T = TypeVar("T")


def _get_first_valid_env_var(env_vars: list[str]) -> Optional[str]:
    for env_var in env_vars:
        value = os.environ.get(env_var)
        if value is not None:
            return value
    return None


def maybe_get_value_from_context(
    context_vars: list[ContextVar[Optional[T]]],
) -> Optional[T]:
    for context_var in context_vars:
        value = context_var.get()
        if value is not None:
            return value
    return None


def maybe_get_value_from_context_or_env(
    context_vars: list[ContextVar[Optional[str]]], env_vars: list[str]
) -> Optional[str]:
    return maybe_get_value_from_context(context_vars) or _get_first_valid_env_var(env_vars)


def get_value_from_context_or_env(context_vars: list[ContextVar[Optional[str]]], env_vars: list[str]) -> str:
    value = maybe_get_value_from_context_or_env(context_vars, env_vars)

    if value is None:
        raise EnvironmentNotConfigured(
            "Unable to configure client: please pass in values to FoundryClient, "
            "or set the context variable in foundry_sdk_runtime, "
            f"or set one of the following environment variables: {', '.join(env_vars)}."
        )

    return value
