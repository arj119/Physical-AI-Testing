class InvalidApplyActionOptionCombination(Exception):
    def __init__(
        self,
        message: str = "The given options are individually valid but cannot be used in the given combination.",
    ) -> None:
        super().__init__(message)
