#  (c) Copyright 2026 Palantir Technologies Inc. All rights reserved.


class MediaTransformationError(Exception):
    """Base exception for all media transformation errors."""


class MediaTransformationTimeoutError(MediaTransformationError):
    """Raised when a media transformation job exceeds the poll timeout."""


class MediaTransformationFailedError(MediaTransformationError):
    """Raised when a media transformation job status is FAILED."""
