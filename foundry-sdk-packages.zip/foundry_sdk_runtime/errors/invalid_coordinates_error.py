from typing import Optional


class InvalidCoordinatesError(Exception):
    def __init__(self, lat: Optional[float] = None, lon: Optional[float] = None) -> None:
        msg = "Latitude must be in the range [-90, 90] and longitude must be in the range [-180, 180]"
        if lat:
            msg += f" (latitude was {lat})"
        if lon:
            msg += f" (longitude was {lon})"
        super().__init__(msg)
