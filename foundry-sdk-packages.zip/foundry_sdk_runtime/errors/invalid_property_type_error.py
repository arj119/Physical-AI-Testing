from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from foundry_sdk_runtime.properties import ObjectTypeProperty


class InvalidPropertyTypeError(Exception):
    def __init__(self, property: "ObjectTypeProperty"):
        msg = f"Cannot perform operation on {property.property_type}; invalid type."
        super().__init__(msg)
        self.property = property
        self.property_type = property.property_type
