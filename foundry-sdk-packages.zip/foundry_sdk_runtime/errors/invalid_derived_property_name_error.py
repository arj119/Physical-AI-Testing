class InvalidDerivedPropertyNameError(Exception):
    def __init__(self, derived_property_name: str):
        msg = f"{derived_property_name} is not a valid property name."
        super().__init__(msg)
