from abc import ABC, abstractmethod
from functools import cache
from typing import Any, Optional, TypeVar

from foundry_sdk.v2.ontologies import OntologiesClient
from foundry_sdk.v2.ontologies.models import ObjectTypeInterfaceImplementation, ObjectTypeV2
from pydantic import GetCoreSchemaHandler, ValidationInfo
from pydantic_core import core_schema


class BaseObject(ABC):
    _IS_INTERFACE_TYPE: bool

    @staticmethod
    @abstractmethod
    def api_name() -> str: ...

    # Method used for response deserialization
    @cache
    @staticmethod
    @abstractmethod
    def _fields() -> dict[str, Any]: ...

    # Method used for response deserialization
    @cache
    @staticmethod
    @abstractmethod
    def _api_name_to_property_name() -> dict[str, str]: ...

    @cache
    @abstractmethod
    def _asdict(self) -> dict[str, Any]: ...


BaseObjectT = TypeVar("BaseObjectT", bound=BaseObject)


class OntologyObject(BaseObject, ABC):
    _interface_property_mapping: dict[str, ObjectTypeInterfaceImplementation] = {}
    _IS_INTERFACE_TYPE = False

    @staticmethod
    @abstractmethod
    def primary_key() -> str: ...

    @staticmethod
    @abstractmethod
    def primary_key_type() -> type: ...

    @staticmethod
    @abstractmethod
    def init_from_primary_key(
        primary_key: Any, ontologies_client: Optional[OntologiesClient] = None
    ) -> "OntologyObject": ...

    @abstractmethod
    def get_primary_key(self) -> Any: ...

    @classmethod
    def __get_pydantic_core_schema__(cls, source_type: Any, handler: GetCoreSchemaHandler) -> core_schema.CoreSchema:
        # Get the default schema
        python_schema = handler(source_type)

        def validate_from_any(value: Any, handler, info: ValidationInfo):  # type: ignore[no-untyped-def]
            ontologies_client = info.context.get("ontologies_client") if info.context else None

            if isinstance(value, OntologyObject):
                return value
            if isinstance(value, dict):
                # Delegate to Pydantic's default validation
                return handler(value)
            if isinstance(value, cls.primary_key_type()):
                return cls.init_from_primary_key(primary_key=value, ontologies_client=ontologies_client)
            raise ValueError(f"Cannot parse {type(value)} as {cls.__name__}")

        def serialize(instance):  # type: ignore[no-untyped-def]
            return instance.get_primary_key()

        return core_schema.with_info_wrap_validator_function(
            function=validate_from_any,
            schema=python_schema,
            serialization=core_schema.plain_serializer_function_ser_schema(serialize),
        )


OntologyObjectT = TypeVar("OntologyObjectT", bound=OntologyObject)


class OntologyInterface(BaseObject, ABC):
    _implementing_object_metadata: dict[str, ObjectTypeV2] = {}
