#  (c) Copyright 2024 Palantir Technologies Inc. All rights reserved.

from foundry_sdk.v2.ontologies.models import AttachmentV2

AttachmentV2.model_rebuild()


class AttachmentMetadata(AttachmentV2):
    pass
