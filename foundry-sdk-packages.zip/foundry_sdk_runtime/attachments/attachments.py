import os

from foundry_sdk.v2.ontologies import OntologiesClient

from foundry_sdk_runtime.attachments import Attachment


class Attachments:
    def __init__(self, _ontologies_client: OntologiesClient):
        self._ontologies_client = _ontologies_client

    def upload(self, file_path: str, attachment_name: str) -> Attachment:
        """
        Upload an attachment to use in an action. Any attachment which has not been linked to an object via
        an action within one hour after upload will be removed.
        :param file_path: path to the attachment file
        :param attachment_name: name of the attachment to be uploaded
        :rtype: The Attachment that was uploaded. Note: this attachment is ephemeral, and if not linked to an
        object via an action within one hour will be removed.
        """
        response = self._ontologies_client.Attachment.upload(
            body=Attachments._read_file(file_path),
            content_length=os.path.getsize(file_path),
            content_type="application/octet-stream",
            filename=attachment_name,
            request_timeout=None,
        )
        return Attachment(_ontologies_client=self._ontologies_client, rid=response.rid)

    @staticmethod
    def _read_file(file_path: str) -> bytes:
        with open(file_path, "rb") as file:
            return file.read()
