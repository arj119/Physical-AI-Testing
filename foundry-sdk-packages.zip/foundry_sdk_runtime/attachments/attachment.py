#  (c) Copyright 2024 Palantir Technologies Inc. All rights reserved.
from io import BytesIO
from typing import Any, Dict, Optional

from foundry_sdk.v2.ontologies import OntologiesClient

from foundry_sdk_runtime.types import sanitize_for_hashing

from .attachment_metadata import AttachmentMetadata


class Attachment:
    def __init__(
        self,
        _ontologies_client: OntologiesClient,
        rid: str,
    ) -> None:
        self._ontologies_client = _ontologies_client
        self._rid = rid

    @staticmethod
    def init_from_attachment_rid(attachment_rid: str) -> "Attachment":
        from foundry_sdk_runtime.client.foundry_client_base_class import (
            FoundryClientBaseClass,
        )

        foundry_client = FoundryClientBaseClass()

        return Attachment(foundry_client._ontologies_client, attachment_rid)

    @property
    def rid(self) -> str:
        return self._rid

    def read(self) -> BytesIO:
        response = self._ontologies_client.Attachment.read(attachment_rid=self._rid, request_timeout=None)
        return BytesIO(response)

    def __repr__(self) -> str:
        return f"Attachment(rid={self.rid})"

    def __hash__(self) -> int:
        return hash(
            (
                type(self),
                sanitize_for_hashing(self.rid),
            )
        )

    def get_metadata(self) -> AttachmentMetadata:
        response = self._ontologies_client.Attachment.get(attachment_rid=self._rid, request_timeout=None)
        return AttachmentMetadata.model_validate(response.to_dict())

    def __eq__(self, other: Any) -> bool:
        return self is other or (type(self) is type(other) and self._rid == other._rid)

    def _asdict(self) -> Dict[str, Optional[str]]:
        return {"rid": self._rid}

    @staticmethod
    def _fields() -> Dict[str, Any]:
        return {
            "rid": Optional[str],
        }

    @staticmethod
    def _api_name_to_property_name() -> Dict[str, str]:
        return {
            "rid": "rid",
        }
