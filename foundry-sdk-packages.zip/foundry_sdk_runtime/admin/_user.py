from __future__ import annotations

from foundry_sdk.v2.admin.models import User as PlatformSDKUser

PlatformSDKUser.model_rebuild()


class User(PlatformSDKUser):
    """The representation of a User."""

    pass
