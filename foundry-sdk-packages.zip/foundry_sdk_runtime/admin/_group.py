from __future__ import annotations

from foundry_sdk.v2.admin.models import Group as PlatformSDKGroup

PlatformSDKGroup.model_rebuild()


class Group(PlatformSDKGroup):
    """The representation of a Group."""

    pass
