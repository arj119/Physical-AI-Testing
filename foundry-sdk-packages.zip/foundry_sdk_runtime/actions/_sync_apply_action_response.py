from __future__ import annotations

from typing import Optional

from foundry_sdk.v2.ontologies.models import SyncApplyActionResponseV2  # NOQA

from ._validate_action_response import ValidateActionResponse

SyncApplyActionResponseV2.model_rebuild()


class SyncApplyActionResponse(SyncApplyActionResponseV2):
    validation: Optional[ValidateActionResponse] = None
