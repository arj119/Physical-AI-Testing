from __future__ import annotations

from foundry_sdk.v2.ontologies.models import BatchApplyActionResponseV2

BatchApplyActionResponseV2.model_rebuild()


class BatchApplyActionResponse(BatchApplyActionResponseV2):
    pass
