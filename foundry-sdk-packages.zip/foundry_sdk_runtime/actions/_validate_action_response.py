from __future__ import annotations

from foundry_sdk.v2.ontologies.models import ValidateActionResponseV2

ValidateActionResponseV2.model_rebuild()


class ValidateActionResponse(ValidateActionResponseV2):
    """ValidateActionResponseV2"""
