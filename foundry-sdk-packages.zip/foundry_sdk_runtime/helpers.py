from collections.abc import Iterable
from typing import TypeVar, Union

PRIMARY_KEY_UNION_TYPE = Union[str, int, float, bool]


T = TypeVar("T")


def get_only_element(iterable: Iterable[T]) -> T:
    it = iter(iterable)

    try:
        first_value = next(it)
    except StopIteration as e:
        raise (ValueError("Too few items in iterable (expected 1)")) from e

    try:
        second_value = next(it)
    except StopIteration:
        pass
    else:
        msg = "Expected exactly one item in iterable, but got {!r}, {!r}, and perhaps more.".format(
            first_value, second_value
        )
        raise ValueError(msg)

    return first_value
