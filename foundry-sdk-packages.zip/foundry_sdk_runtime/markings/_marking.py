from foundry_sdk_runtime.decorators import beta


@beta("Marking types are in beta and may change in future versions.")
class Marking(str):
    def __repr__(self) -> str:
        return f"Marking({super().__repr__()})"
