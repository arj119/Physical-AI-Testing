from foundry_sdk_runtime.decorators import beta


@beta("Vector types are in beta and may change in future versions.")
class Vector(list[float]):
    def __init__(self, elements: list[float]):
        if not all(isinstance(x, float) for x in elements):
            raise TypeError("All elements must be of type float")
        super().__init__(elements)

    def __repr__(self) -> str:
        return f"Vector({super().__repr__()})"
