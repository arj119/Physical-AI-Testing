#  (c) Copyright 2025 Palantir Technologies Inc. All rights reserved.
# pylint: disable=unused-import
# flake8: noqa: F401
from ._vector import Vector
