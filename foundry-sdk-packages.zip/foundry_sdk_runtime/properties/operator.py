from typing import TYPE_CHECKING, Any, Callable, Optional, Type, TypeVar

from foundry_sdk_runtime.derived_properties import DerivedPropertyType

if TYPE_CHECKING:
    from .expression import ObjectTypeExpression
    from .object_type_property import (
        ObjectTypePropertyProtocol,
        ObjectTypePropertyWithExpression,
    )

T = TypeVar("T")


def _comparator(
    expr: Type["ObjectTypeExpression"],
    return_type: Type["ObjectTypePropertyWithExpression"],
    doc: str = "comparator operator",
) -> Callable[["ObjectTypePropertyProtocol", Any], "ObjectTypePropertyWithExpression"]:
    """Create a method for given comparator operator."""

    def _(self: "ObjectTypePropertyProtocol", other: Any) -> "ObjectTypePropertyWithExpression":
        """
        Check to see if the object property type matches the type it's being compared to
        For Derived Properties, because we don't know the object property's type,
        we can't check to see if it matches the type it's being compared to
        """
        if self.property_type is float and isinstance(other, int):
            other = float(other)
        elif self.property_type is int and isinstance(other, float) and other.is_integer():
            other = int(other)
        if not isinstance(other, self.property_type) and not issubclass(self.property_type, DerivedPropertyType):
            raise ValueError(
                f"cannot process '{self.name} {expr.symbol()} {other}': '{other}' should be a"
                f" '{self.property_type.__name__}'"
            )

        from foundry_sdk_runtime.serialization.request_serialization import (
            convert_to_platform_sdk_type,
        )

        return return_type(self, expr(self, convert_to_platform_sdk_type(other)))

    _.__doc__ = doc
    return _


def _contains_terms_comparator(
    expr: Type["ObjectTypeExpression"],
    return_type: Type["ObjectTypePropertyWithExpression"],
    doc: str = "contains terms comparator operator",
) -> Callable[
    ["ObjectTypePropertyProtocol", Any, Optional[bool]],
    "ObjectTypePropertyWithExpression",
]:
    """Create a method for given "contains terms" type operator."""

    def _(self: "ObjectTypePropertyProtocol", query: Any, fuzzy: Optional[bool]) -> "ObjectTypePropertyWithExpression":
        """
        Check to see if the object property type matches the type it's being compared to
        For Derived Properties, because we don't know the object property's type,
        we can't check to see if it matches the type it's being compared to
        """
        if not isinstance(query, self.property_type) and not issubclass(self.property_type, DerivedPropertyType):
            raise ValueError(
                f"cannot process '{self.name} {expr.symbol()} {query}': '{query}' should be a"
                f" '{self.property_type.__name__}'"
            )
        if fuzzy and not isinstance(fuzzy, bool):
            raise ValueError(f"cannot process '{self.name} {expr.symbol()} {fuzzy}': '{fuzzy}' should be a 'bool'")

        from foundry_sdk_runtime.serialization.request_serialization import (
            convert_to_platform_sdk_type,
        )

        return return_type(self, expr(self, convert_to_platform_sdk_type((query, fuzzy))))

    _.__doc__ = doc
    return _


def _unary(
    expr: Type["ObjectTypeExpression"],
    return_type: Type["ObjectTypePropertyWithExpression"],
    doc: str = "unary operator",
) -> Callable[["ObjectTypePropertyProtocol"], "ObjectTypePropertyWithExpression"]:
    """Create a method for given unary operator."""

    def _(self: "ObjectTypePropertyProtocol") -> "ObjectTypePropertyWithExpression":
        return return_type(self, expr(self))

    _.__doc__ = doc
    return _


def _boolean(
    expr: Type["ObjectTypeExpression"],
    return_type: Type["ObjectTypePropertyWithExpression"],
    doc: str = "boolean operator",
) -> Callable[["ObjectTypePropertyProtocol", Any], "ObjectTypePropertyWithExpression"]:
    """Create a method for given boolean operator."""

    def _(self: "ObjectTypePropertyProtocol", other: Any) -> "ObjectTypePropertyWithExpression":
        """
        Check to see if the object property type matches the type it's being compared to
        For Derived Properties, because we don't know the object property's type,
        we can't check to see if it matches the type it's being compared to
        """
        if not isinstance(other, return_type) and not issubclass(self.property_type, DerivedPropertyType):
            raise ValueError(
                f"cannot process '{self.name} {expr.symbol()} {other}': '{other}' should be a property with an"
                " expression"
            )

        return return_type(self, expr(self, other))

    _.__doc__ = doc
    return _


def _unsupported_comparator() -> Callable[["ObjectTypePropertyProtocol", Any], "ObjectTypePropertyWithExpression"]:
    def _compare(self: "ObjectTypePropertyProtocol", other: Any) -> "ObjectTypePropertyWithExpression":
        raise ValueError("Unsupported comparator.")

    return _compare
