#  (c) Copyright 2023 Palantir Technologies Inc. All rights reserved.
import abc
from abc import ABC
from typing import TYPE_CHECKING, Any, Type

from foundry_sdk.v2.ontologies.models import SearchJsonQueryV2

if TYPE_CHECKING:
    from foundry_sdk_runtime.search.visitor import ExpressionVisitor


class ObjectTypeExpression(ABC):
    def __init__(self, *args: Any, **kwargs: Any) -> None:
        pass

    @abc.abstractmethod
    def __repr__(self) -> str:
        pass

    @classmethod
    @abc.abstractmethod
    def symbol(cls) -> str:
        """The symbol representation for this expression."""
        raise NotImplementedError("Must implement symbol")

    @abc.abstractmethod
    def accept(self, visitor: Type["ExpressionVisitor"]) -> SearchJsonQueryV2:
        pass
