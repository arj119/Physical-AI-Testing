from datetime import date, datetime

from foundry_sdk_runtime.derived_properties import (
    BaseNumericalPropertyBuilderMixin,
    DerivedPropertyType,
)
from foundry_sdk_runtime.geoshapes import GeoPoint, GeoShape

from .mixins import (
    ArrayMixin,
    BetweenMixin,
    GeoPointPropertyMixin,
    GeoShapePropertyMixin,
    GroupByDateDurationMixin,
    GroupByDatetimeDurationMixin,
    GroupByExactMixin,
    GroupByFixedWidthMixin,
    GroupByRangesMixin,
    NumericalAggregationMixin,
    OrderByMixin,
    StringPropertyMixin,
)
from .object_type_property import ObjectTypeProperty
from .operator import _unsupported_comparator


class ArrayObjectTypeProperty(ObjectTypeProperty, ArrayMixin, GroupByExactMixin):
    def __init__(self, sub_property: ObjectTypeProperty) -> None:
        ObjectTypeProperty.__init__(
            self,
            property_name=sub_property.name,
            property_type=sub_property.property_type,
        )

    __lt__ = _unsupported_comparator()
    __le__ = _unsupported_comparator()
    __ge__ = _unsupported_comparator()
    __gt__ = _unsupported_comparator()


class VectorObjectTypeProperty(ObjectTypeProperty, ArrayMixin):
    def __init__(self, name: str) -> None:
        ObjectTypeProperty.__init__(self, property_name=name, property_type=float)

    __lt__ = _unsupported_comparator()
    __le__ = _unsupported_comparator()
    __ge__ = _unsupported_comparator()
    __gt__ = _unsupported_comparator()


class StringObjectTypeProperty(ObjectTypeProperty, StringPropertyMixin, GroupByExactMixin, OrderByMixin):
    def __init__(self, name: str) -> None:
        ObjectTypeProperty.__init__(self, property_name=name, property_type=str)


class IntegerObjectTypeProperty(
    ObjectTypeProperty,
    NumericalAggregationMixin,
    BetweenMixin,
    GroupByExactMixin,
    GroupByRangesMixin,
    OrderByMixin,
):
    def __init__(self, name: str) -> None:
        ObjectTypeProperty.__init__(self, property_name=name, property_type=int)


class FloatObjectTypeProperty(
    ObjectTypeProperty,
    NumericalAggregationMixin,
    BetweenMixin,
    GroupByExactMixin,
    GroupByFixedWidthMixin,
    GroupByRangesMixin,
    OrderByMixin,
):
    def __init__(self, name: str) -> None:
        ObjectTypeProperty.__init__(self, property_name=name, property_type=float)


class GeoPointObjectTypeProperty(ObjectTypeProperty, GeoPointPropertyMixin):
    def __init__(self, name: str) -> None:
        ObjectTypeProperty.__init__(self, property_name=name, property_type=GeoPoint)

    __lt__ = _unsupported_comparator()
    __le__ = _unsupported_comparator()
    __ge__ = _unsupported_comparator()
    __gt__ = _unsupported_comparator()


class GeoShapeObjectTypeProperty(ObjectTypeProperty, GeoShapePropertyMixin):
    def __init__(self, name: str) -> None:
        ObjectTypeProperty.__init__(self, property_name=name, property_type=GeoShape)

    __lt__ = _unsupported_comparator()
    __le__ = _unsupported_comparator()
    __ge__ = _unsupported_comparator()
    __gt__ = _unsupported_comparator()


class BooleanObjectTypeProperty(ObjectTypeProperty, GroupByExactMixin, OrderByMixin):
    def __init__(self, name: str) -> None:
        ObjectTypeProperty.__init__(self, property_name=name, property_type=bool)

    __lt__ = _unsupported_comparator()
    __le__ = _unsupported_comparator()
    __ge__ = _unsupported_comparator()
    __gt__ = _unsupported_comparator()


class DatetimeObjectTypeProperty(
    ObjectTypeProperty,
    NumericalAggregationMixin,
    BetweenMixin,
    GroupByExactMixin,
    GroupByDatetimeDurationMixin,
    GroupByRangesMixin,
    OrderByMixin,
):
    def __init__(self, name: str) -> None:
        ObjectTypeProperty.__init__(self, property_name=name, property_type=datetime)


class DateObjectTypeProperty(
    ObjectTypeProperty,
    NumericalAggregationMixin,
    BetweenMixin,
    GroupByExactMixin,
    GroupByDateDurationMixin,
    GroupByRangesMixin,
    OrderByMixin,
):
    def __init__(self, name: str) -> None:
        ObjectTypeProperty.__init__(self, property_name=name, property_type=date)


class DerivedObjectTypeProperty(
    ObjectTypeProperty,
    ArrayMixin,
    BaseNumericalPropertyBuilderMixin,
    BetweenMixin,
    GeoPointPropertyMixin,
    GroupByDatetimeDurationMixin,
    GroupByExactMixin,
    GroupByFixedWidthMixin,
    GroupByRangesMixin,
    NumericalAggregationMixin,
    OrderByMixin,
    StringPropertyMixin,
):
    def __init__(self, name: str) -> None:
        ObjectTypeProperty.__init__(self, property_name=name, property_type=DerivedPropertyType)
