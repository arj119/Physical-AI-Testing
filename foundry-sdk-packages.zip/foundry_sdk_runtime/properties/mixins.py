from datetime import date, datetime
from typing import TYPE_CHECKING, Any, Optional, Union

from foundry_sdk_runtime.derived_properties import DerivedPropertyType
from foundry_sdk_runtime.geoshapes import BBox, Distance, GeoPoint, Polygon
from foundry_sdk_runtime.search.expression import (
    ArrayContainsExpression,
    ContainsAllTermsExpression,
    ContainsAllTermsInOrderExpression,
    ContainsAllTermsInOrderPrefixLastTermExpression,
    ContainsAnyTermExpression,
    DoesNotIntersectBoundingBoxExpression,
    DoesNotIntersectPolygonExpression,
    IntersectsBoundingBoxExpression,
    IntersectsPolygonExpression,
    WithinBoundingBoxExpression,
    WithinDistanceOfExpression,
    WithinPolygonExpression,
)

from .helpers import NUMERICAL_TYPES, RANGE_ELEMENT_TYPE, AggregationType, valid_bbox
from .object_type_property import (
    ObjectTypePropertyWithExpression,
    ObjectTypePropertyWithGroupByExpression,
    ObjectTypePropertyWithOrderbyExpression,
)
from .operator import _comparator, _contains_terms_comparator

if TYPE_CHECKING:
    from .object_type_property import ObjectTypePropertyProtocol


class ArrayMixin:
    def contains(self: "ObjectTypePropertyProtocol", value: Any) -> "ObjectTypePropertyWithExpression":
        """
        Return a boolean if the array contains the given value.

        :param value: value to check
        :return: new expression with membership test
        """
        return _comparator(
            expr=ArrayContainsExpression,
            return_type=ObjectTypePropertyWithExpression,
            doc="The provided property contains the provided value.",
        )(self, value)


class StringPropertyMixin:
    def contains_all_terms(
        self: "ObjectTypePropertyProtocol",
        query: list[str],
        fuzzy: Optional[bool] = None,
    ) -> "ObjectTypePropertyWithExpression":
        return _contains_terms_comparator(
            expr=ContainsAllTermsExpression,
            return_type=ObjectTypePropertyWithExpression,
            doc="The provided property contains all the terms in any order.",
        )(self, " ".join(query), fuzzy)

    def contains_all_terms_in_order(
        self: "ObjectTypePropertyProtocol", other: list[str], prefix_last_term: bool = False
    ) -> "ObjectTypePropertyWithExpression":
        if prefix_last_term:
            return _comparator(
                expr=ContainsAllTermsInOrderPrefixLastTermExpression,
                return_type=ObjectTypePropertyWithExpression,
                doc="The provided property contains the provided terms in order. "
                "The last term can be a partial prefix match.",
            )(self, " ".join(other))
        else:
            return _comparator(
                expr=ContainsAllTermsInOrderExpression,
                return_type=ObjectTypePropertyWithExpression,
                doc="The provided property contains the provided terms in order.",
            )(self, " ".join(other))

    def contains_any_term(
        self: "ObjectTypePropertyProtocol",
        query: list[str],
        fuzzy: Optional[bool] = None,
    ) -> "ObjectTypePropertyWithExpression":
        return _contains_terms_comparator(
            expr=ContainsAnyTermExpression,
            return_type=ObjectTypePropertyWithExpression,
            doc="The provided property contains at least one of the terms in any order.",
        )(self, " ".join(query), fuzzy)


class BetweenMixin:
    def between(self, lower_bound: Any, upper_bound: Any, inclusive: bool = True) -> "ObjectTypePropertyWithExpression":
        """A boolean expression that is evaluated to true if the value of this expression is between the given bounds."""
        if inclusive:
            return (self >= lower_bound) & (self <= upper_bound)  # type: ignore
        return (self > lower_bound) & (self < upper_bound)  # type: ignore


class GeometryPropertyMixin:
    """Filter methods available for both GeoPoint and GeoShape type properties."""

    def within_bounding_box(
        self: "ObjectTypePropertyProtocol", bounding_box: BBox
    ) -> "ObjectTypePropertyWithExpression":
        if not valid_bbox(bounding_box):
            raise ValueError(
                f"cannot process '{self.name} {WithinBoundingBoxExpression.symbol()} {bounding_box}': '{bounding_box}' should be a"
                f" 'BBox' of length 4"
            )
        return ObjectTypePropertyWithExpression(self, WithinBoundingBoxExpression(self, bounding_box))

    def within_polygon(self: "ObjectTypePropertyProtocol", polygon: Polygon) -> "ObjectTypePropertyWithExpression":
        if not isinstance(polygon, Polygon):
            raise ValueError(
                f"cannot process '{self.name} {WithinPolygonExpression.symbol()} {polygon}': '{polygon}' should be a"
                f" 'Polygon'"
            )
        return ObjectTypePropertyWithExpression(self, WithinPolygonExpression(self, polygon))


class GeoPointPropertyMixin(GeometryPropertyMixin):
    def within_distance_of(
        self: "ObjectTypePropertyProtocol", location: GeoPoint, distance: Distance
    ) -> "ObjectTypePropertyWithExpression":
        if not isinstance(location, GeoPoint):
            raise ValueError(
                f"cannot process '{self.name} {WithinDistanceOfExpression.symbol()} {location}': '{location}' should be a"
                f" 'GeoPoint'"
            )
        if not isinstance(distance, Distance):
            raise ValueError(
                f"cannot process '{self.name} {WithinDistanceOfExpression.symbol()} {distance}': '{distance}' should be a"
                f" 'Distance'"
            )
        return ObjectTypePropertyWithExpression(self, WithinDistanceOfExpression(self, (location, distance)))


class GeoShapePropertyMixin(GeometryPropertyMixin):
    def intersects_polygon(self: "ObjectTypePropertyProtocol", polygon: Polygon) -> "ObjectTypePropertyWithExpression":
        if not isinstance(polygon, Polygon):
            raise ValueError(
                f"cannot process '{self.name} {IntersectsPolygonExpression.symbol()} {polygon}': '{polygon}' should be a"
                f" 'Polygon'"
            )
        return ObjectTypePropertyWithExpression(self, IntersectsPolygonExpression(self, polygon))

    def does_not_intersect_polygon(
        self: "ObjectTypePropertyProtocol", polygon: Polygon
    ) -> "ObjectTypePropertyWithExpression":
        if not isinstance(polygon, Polygon):
            raise ValueError(
                f"cannot process '{self.name} {DoesNotIntersectPolygonExpression.symbol()} {polygon}': '{polygon}' should be a"
                f" 'Polygon'"
            )
        return ObjectTypePropertyWithExpression(self, DoesNotIntersectPolygonExpression(self, polygon))

    def intersects_bounding_box(
        self: "ObjectTypePropertyProtocol", bounding_box: BBox
    ) -> "ObjectTypePropertyWithExpression":
        if not valid_bbox(bounding_box):
            raise ValueError(
                f"cannot process '{self.name} {IntersectsBoundingBoxExpression.symbol()} {bounding_box}': '{bounding_box}' should be a"
                f" 'BBox' of length 4"
            )
        return ObjectTypePropertyWithExpression(self, IntersectsBoundingBoxExpression(self, bounding_box))

    def does_not_intersect_bounding_box(
        self: "ObjectTypePropertyProtocol", bounding_box: BBox
    ) -> "ObjectTypePropertyWithExpression":
        if not valid_bbox(bounding_box):
            raise ValueError(
                f"cannot process '{self.name} {DoesNotIntersectBoundingBoxExpression.symbol()} {bounding_box}': '{bounding_box}' should be a"
                f" 'BBox' of length 4"
            )
        return ObjectTypePropertyWithExpression(self, DoesNotIntersectBoundingBoxExpression(self, bounding_box))


class GroupByFixedWidthMixin:
    def fixed_width(self: "ObjectTypePropertyProtocol", fixed_width: int) -> ObjectTypePropertyWithGroupByExpression:
        if not isinstance(fixed_width, int):
            raise TypeError(f"fixed_width must be an int. You passed in a {type(fixed_width)}")
        return ObjectTypePropertyWithGroupByExpression(
            group_by_type="fixedWidth",
            property_name=self.name,
            group_by_param_value=fixed_width,
        )


class GroupByRangesMixin:
    def ranges(
        self: "ObjectTypePropertyProtocol",
        ranges: set[tuple[RANGE_ELEMENT_TYPE, RANGE_ELEMENT_TYPE]],
    ) -> "ObjectTypePropertyWithGroupByExpression":
        """
        Method for constructing the ranges a user wants to group by with.
        For example:
        MyObjectSet.group_by(
            MyObject.object_type.int_property.ranges(
                {(1, 2), (3, 4)}
            )
        ).count().compute()
        Returns the count of int_property for each group (1, 2) and (3, 4)

        :param ranges: set of tuples of len 2, where the first element of the tuple is the start_value and
            the second element the end_value
        """

        def _serialize_value(value: RANGE_ELEMENT_TYPE) -> Union[int, float, str]:
            if isinstance(value, datetime):
                return value.isoformat() + "Z"
            if isinstance(value, date):
                return value.isoformat()
            return value

        def _validate_ranges_dont_overlap(range_list: list[tuple[RANGE_ELEMENT_TYPE, RANGE_ELEMENT_TYPE]]) -> None:
            for (start1, end1), (start2, end2) in zip(range_list, range_list[1:]):
                if end1 > start2:
                    # If the end_value of an earlier range is > the start_value of a later range, they overlap
                    raise ValueError(f"Ranges cannot overlap: {start1, end1} and {start2, end2} overlap.")

        if not isinstance(ranges, set):
            raise TypeError(f"ranges must be a set of tuples. You passed in a {type(ranges).__name__}")

        final_ranges = []
        ranges_list: list[tuple[RANGE_ELEMENT_TYPE, RANGE_ELEMENT_TYPE]] = []
        for start_and_end in ranges:
            if not isinstance(start_and_end, tuple):
                raise TypeError(
                    f"ranges must be a set of tuples. Element '{start_and_end}' is a {type(start_and_end).__name__}"
                )
            if len(start_and_end) != 2:
                raise ValueError(f"Tuple {start_and_end} must contain exactly two elements: (start_value, end_value)")

            start_value, end_value = start_and_end

            if end_value <= start_value:
                raise ValueError(f"Tuple {start_and_end} cannot have an end_value less than or equal its start_value.")

            """
            Check to see if the object property type matches the value in the range comparison
            For Derived Properties, because we don't know the object property's type, 
            we can't check to see if it matches the type in the range comparison
            """
            if not issubclass(self.property_type, DerivedPropertyType):
                for val, name in zip(start_and_end, ["start_value", "end_value"]):
                    if not isinstance(val, self.property_type):
                        raise TypeError(f"{name} '{val}' must be of type {self.property_type.__name__}")

            final_ranges.append(
                {
                    "startValue": _serialize_value(start_value),
                    "endValue": _serialize_value(end_value),
                }
            )
            ranges_list.append(start_and_end)

        _validate_ranges_dont_overlap(sorted(ranges_list))

        return ObjectTypePropertyWithGroupByExpression(
            group_by_type="ranges",
            property_name=self.name,
            group_by_param_value=final_ranges,
        )


class GroupByExactMixin:
    def exact(
        self: "ObjectTypePropertyProtocol",
        max_group_count: int | None = None,
        include_null_values: bool | None = None,
        default_value: Any | None = None,
    ) -> ObjectTypePropertyWithGroupByExpression:
        if max_group_count and not isinstance(max_group_count, int):
            raise TypeError(f"max_group_count must be an int. You passed in a {type(max_group_count)}")
        if include_null_values and default_value is not None:
            raise TypeError("default_value cannot be used with include_null_values enabled.")
        return ObjectTypePropertyWithGroupByExpression(
            group_by_type="exact",
            property_name=self.name,
            group_by_param_value=max_group_count,
            include_null_values=include_null_values,
            default_value=default_value,
        )


class GroupByDateDurationMixin:
    def by_days(self: "ObjectTypePropertyProtocol", duration: int) -> ObjectTypePropertyWithGroupByExpression:
        if not duration or not isinstance(duration, int):
            raise TypeError(f"duration must be an int. You passed in a {type(duration)}")
        return ObjectTypePropertyWithGroupByExpression(
            group_by_type="duration",
            property_name=self.name,
            group_by_param_value=duration,
            duration_unit="DAYS",
        )

    def by_weeks(
        self: "ObjectTypePropertyProtocol",
    ) -> ObjectTypePropertyWithGroupByExpression:
        return ObjectTypePropertyWithGroupByExpression(
            group_by_type="duration",
            property_name=self.name,
            group_by_param_value=1,
            duration_unit="WEEKS",
        )

    def by_months(
        self: "ObjectTypePropertyProtocol",
    ) -> ObjectTypePropertyWithGroupByExpression:
        return ObjectTypePropertyWithGroupByExpression(
            group_by_type="duration",
            property_name=self.name,
            group_by_param_value=1,
            duration_unit="MONTHS",
        )

    def by_years(
        self: "ObjectTypePropertyProtocol",
    ) -> ObjectTypePropertyWithGroupByExpression:
        return ObjectTypePropertyWithGroupByExpression(
            group_by_type="duration",
            property_name=self.name,
            group_by_param_value=1,
            duration_unit="YEARS",
        )

    def by_quarters(
        self: "ObjectTypePropertyProtocol",
    ) -> ObjectTypePropertyWithGroupByExpression:
        return ObjectTypePropertyWithGroupByExpression(
            group_by_type="duration",
            property_name=self.name,
            group_by_param_value=1,
            duration_unit="QUARTERS",
        )


class GroupByDatetimeDurationMixin(GroupByDateDurationMixin):
    def by_seconds(self: "ObjectTypePropertyProtocol", duration: int) -> ObjectTypePropertyWithGroupByExpression:
        if not duration or not isinstance(duration, int):
            raise TypeError(f"duration must be an int. You passed in a {type(duration)}")
        return ObjectTypePropertyWithGroupByExpression(
            group_by_type="duration",
            property_name=self.name,
            group_by_param_value=duration,
            duration_unit="SECONDS",
        )

    def by_minutes(self: "ObjectTypePropertyProtocol", duration: int) -> ObjectTypePropertyWithGroupByExpression:
        if not duration or not isinstance(duration, int):
            raise TypeError(f"duration must be an int. You passed in a {type(duration)}")
        return ObjectTypePropertyWithGroupByExpression(
            group_by_type="duration",
            property_name=self.name,
            group_by_param_value=duration,
            duration_unit="MINUTES",
        )

    def by_hours(self: "ObjectTypePropertyProtocol", duration: int) -> ObjectTypePropertyWithGroupByExpression:
        if not duration or not isinstance(duration, int):
            raise TypeError(f"duration must be an int. You passed in a {type(duration)}")
        return ObjectTypePropertyWithGroupByExpression(
            group_by_type="duration",
            property_name=self.name,
            group_by_param_value=duration,
            duration_unit="HOURS",
        )


class NumericalAggregationMixin:
    def max(self: "ObjectTypePropertyProtocol") -> AggregationType:
        if self.property_type not in NUMERICAL_TYPES:
            raise ValueError(f"Cannot perform max over {self.property_type}")
        return AggregationType(aggregation_type="max", property_name=self.name)

    def min(self: "ObjectTypePropertyProtocol") -> AggregationType:
        if self.property_type not in NUMERICAL_TYPES:
            raise ValueError(f"Cannot perform min over {self.property_type}")
        return AggregationType(aggregation_type="min", property_name=self.name)

    def sum(self: "ObjectTypePropertyProtocol") -> AggregationType:
        if self.property_type not in NUMERICAL_TYPES:
            raise ValueError(f"Cannot perform sum over {self.property_type}")
        return AggregationType(aggregation_type="sum", property_name=self.name)

    def avg(self: "ObjectTypePropertyProtocol") -> AggregationType:
        if self.property_type not in NUMERICAL_TYPES:
            raise ValueError(f"Cannot perform avg over {self.property_type}")
        return AggregationType(aggregation_type="avg", property_name=self.name)


class OrderByMixin:
    def asc(
        self: "ObjectTypePropertyProtocol",
    ) -> ObjectTypePropertyWithOrderbyExpression:
        return ObjectTypePropertyWithOrderbyExpression(property_name=self.name, direction="asc")

    def desc(
        self: "ObjectTypePropertyProtocol",
    ) -> ObjectTypePropertyWithOrderbyExpression:
        return ObjectTypePropertyWithOrderbyExpression(property_name=self.name, direction="desc")
