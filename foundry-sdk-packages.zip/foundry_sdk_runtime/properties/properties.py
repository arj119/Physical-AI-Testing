import logging
from abc import ABC

from .property_types import (
    ArrayObjectTypeProperty,
    BooleanObjectTypeProperty,
    DateObjectTypeProperty,
    DatetimeObjectTypeProperty,
    FloatObjectTypeProperty,
    GeoPointObjectTypeProperty,
    GeoShapeObjectTypeProperty,
    IntegerObjectTypeProperty,
    ObjectTypeProperty,
    StringObjectTypeProperty,
    VectorObjectTypeProperty,
)

logger = logging.getLogger(__name__)


class Properties(ABC):
    @staticmethod
    def array(subtype: ObjectTypeProperty) -> ArrayObjectTypeProperty:
        return ArrayObjectTypeProperty(sub_property=subtype)

    @staticmethod
    def boolean(name: str) -> BooleanObjectTypeProperty:
        return BooleanObjectTypeProperty(name=name)

    @staticmethod
    def datetime(name: str) -> DatetimeObjectTypeProperty:
        return DatetimeObjectTypeProperty(name=name)

    @staticmethod
    def date(name: str) -> DateObjectTypeProperty:
        return DateObjectTypeProperty(name=name)

    @staticmethod
    def float(name: str) -> FloatObjectTypeProperty:
        return FloatObjectTypeProperty(name=name)

    @staticmethod
    def GeoShape(name: str) -> GeoShapeObjectTypeProperty:
        return GeoShapeObjectTypeProperty(name=name)

    @staticmethod
    def GeoPoint(name: str) -> GeoPointObjectTypeProperty:
        return GeoPointObjectTypeProperty(name=name)

    @staticmethod
    def integer(name: str) -> IntegerObjectTypeProperty:
        return IntegerObjectTypeProperty(name=name)

    @staticmethod
    def string(name: str) -> StringObjectTypeProperty:
        return StringObjectTypeProperty(name=name)

    @staticmethod
    def Vector(name: str) -> VectorObjectTypeProperty:
        return VectorObjectTypeProperty(name=name)
