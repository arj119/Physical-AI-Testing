from typing import TYPE_CHECKING, Any, Iterable, NamedTuple, Optional, Protocol, Type

from foundry_sdk.v2.ontologies.models import SearchOrderingV2

from foundry_sdk_runtime.search.expression import (
    AndExpression,
    EqualsExpression,
    GreaterThanEqualsExpression,
    GreaterThanExpression,
    InExpression,
    IsNullExpression,
    LessThanEqualsExpression,
    LessThanExpression,
    NegateExpression,
    NotEqualsExpression,
    OrExpression,
)

from .helpers import DIRECTION, AggregationType, group_by_request_body
from .operator import _boolean, _comparator, _unary

if TYPE_CHECKING:
    from foundry_sdk_runtime.search.visitor import ExpressionVisitor

    from .expression import ObjectTypeExpression


class ObjectTypePropertyProtocol(Protocol):
    """
    Protocol class used to for type hinting.
    Is the interface of an object with a name and property_type properties.
    """

    @property
    def name(self) -> str: ...

    @property
    def property_type(self) -> type: ...

    @property
    def operator_return_type(self) -> Type["ObjectTypePropertyWithExpression"]: ...


class PropertyOperatorOverloads:
    def __init__(
        self,
        property_name: str,
        operator_return_type: Type["ObjectTypePropertyWithExpression"],
    ):
        self.property_name = property_name
        self.operator_return_type = operator_return_type

    def __eq__(self, other: Any) -> "ObjectTypePropertyWithExpression":  # type: ignore[override]
        return _comparator(
            expr=EqualsExpression,
            return_type=self.operator_return_type,
            doc="Equals expression for object type properties",
        )(self, other)  # type: ignore

    def __ne__(self, other: Any) -> "ObjectTypePropertyWithExpression":  # type: ignore[override]
        return _comparator(
            expr=NotEqualsExpression,
            return_type=self.operator_return_type,
            doc="Not equals expression for object type properties",
        )(self, other)  # type: ignore

    def __lt__(self: "ObjectTypePropertyProtocol", other: Any) -> "ObjectTypePropertyWithExpression":
        return _comparator(
            expr=LessThanExpression,
            return_type=self.operator_return_type,
            doc="Less than expression for object type properties",
        )(self, other)

    def __le__(self: "ObjectTypePropertyProtocol", other: Any) -> "ObjectTypePropertyWithExpression":
        return _comparator(
            expr=LessThanEqualsExpression,
            return_type=self.operator_return_type,
            doc="Less than or equals expression for object type properties",
        )(self, other)

    def __ge__(self: "ObjectTypePropertyProtocol", other: Any) -> "ObjectTypePropertyWithExpression":
        return _comparator(
            expr=GreaterThanEqualsExpression,
            return_type=self.operator_return_type,
            doc="Greater than or equals expression for object type properties",
        )(self, other)

    def __gt__(self: "ObjectTypePropertyProtocol", other: Any) -> "ObjectTypePropertyWithExpression":
        return _comparator(
            expr=GreaterThanExpression,
            return_type=self.operator_return_type,
            doc="Greater than expression for object type properties",
        )(self, other)

    # `and`, `or`, `not` cannot be overloaded in Python, so use bitwise operators as boolean operators
    def __and__(self: "ObjectTypePropertyProtocol", other: Any) -> "ObjectTypePropertyWithExpression":
        return _boolean(
            expr=AndExpression,
            return_type=self.operator_return_type,
            doc="'And' logical operator for constructing nested object search queries",
        )(self, other)

    def __or__(self: "ObjectTypePropertyProtocol", other: Any) -> "ObjectTypePropertyWithExpression":
        return _boolean(
            expr=OrExpression,
            return_type=self.operator_return_type,
            doc="'Or' logical operator for constructing nested object search queries",
        )(self, other)

    def __rand__(self: "ObjectTypePropertyProtocol", other: Any) -> "ObjectTypePropertyWithExpression":
        return _boolean(
            expr=AndExpression,
            return_type=self.operator_return_type,
            doc="'And' logical operator for constructing nested object search queries",
        )(self, other)

    def __ror__(self: "ObjectTypePropertyProtocol", other: Any) -> "ObjectTypePropertyWithExpression":
        return _boolean(
            expr=OrExpression,
            return_type=self.operator_return_type,
            doc="'Or' logical operator for constructing nested object search queries",
        )(self, other)

    def is_null(
        self: "ObjectTypePropertyProtocol",
    ) -> "ObjectTypePropertyWithExpression":
        return _unary(
            expr=IsNullExpression,
            return_type=self.operator_return_type,
            doc="The provided property is null.",
        )(self)

    def approximate_distinct(self) -> AggregationType:
        return AggregationType(aggregation_type="approximateDistinct", property_name=self.property_name)

    def exact_distinct(self) -> AggregationType:
        return AggregationType(aggregation_type="exactDistinct", property_name=self.property_name)

    def count(self) -> AggregationType:
        return AggregationType(aggregation_type="count")

    def in_(self: ObjectTypePropertyProtocol, values: list[Any]) -> "ObjectTypePropertyWithExpression":
        if not isinstance(values, Iterable):
            raise ValueError(f"cannot process {values}: in_() accepts an Iterable.")
        for i in range(len(values)):
            if self.property_type is float and isinstance(values[i], int):
                values[i] = float(values[i])
            elif self.property_type is int and isinstance(values[i], float) and values[i].is_integer():
                values[i] = int(values[i])
            if not isinstance(values[i], self.property_type):
                raise ValueError(
                    f"cannot process {values[i]}: '{values[i]}' should be a '{self.property_type.__name__}'"
                )

        from foundry_sdk_runtime.serialization.request_serialization import (
            convert_to_platform_sdk_type,
        )

        return ObjectTypePropertyWithExpression(self, InExpression(self, convert_to_platform_sdk_type(values)))


class ObjectTypePropertyWithExpression(PropertyOperatorOverloads):
    def __init__(self, delegate: "ObjectTypePropertyProtocol", expr: "ObjectTypeExpression") -> None:
        super().__init__(
            property_name=delegate.name,
            operator_return_type=ObjectTypePropertyWithExpression,
        )
        self._delegate = delegate
        self._expr = expr

    def __repr__(self) -> str:
        return f"{self._expr}"

    def __invert__(self) -> "ObjectTypePropertyWithExpression":
        return ObjectTypePropertyWithExpression(self, NegateExpression(self))

    @property
    def name(self) -> str:
        return self._delegate.name

    @property
    def property_type(self) -> type:
        return self._delegate.property_type

    @property
    def expr(self) -> "ObjectTypeExpression":
        return self._expr

    def accept(self, visitor: Type["ExpressionVisitor"]) -> Any:
        return self._expr.accept(visitor)


class ObjectTypeProperty(PropertyOperatorOverloads):
    _property_name: str
    """Helper class to deal with queries on ObjectTypeProperty's."""

    def __init__(self, property_name: str, property_type: type):
        super().__init__(
            property_name=property_name,
            operator_return_type=ObjectTypePropertyWithExpression,
        )
        self._property_name = property_name
        self._property_type = property_type

    def __repr__(self) -> str:
        return f"Property['{self._property_name}']"

    @property
    def name(self) -> str:
        return self._property_name

    @property
    def property_type(self) -> type:
        return self._property_type


class ObjectTypePropertyWithGroupByExpression(NamedTuple):
    group_by_type: str
    property_name: str
    group_by_param_value: Optional[Any] = None
    duration_unit: Optional[str] = None
    include_null_values: bool | None = None
    default_value: Any | None = None

    @property
    def request_body(self) -> dict[str, list[dict[str, Any]]]:
        return group_by_request_body(**self._asdict())


class ObjectTypePropertyWithOrderbyExpression:
    def __init__(self, property_name: str, direction: DIRECTION) -> None:
        self._property_name = property_name
        self._direction = direction

    @property
    def property_name(self) -> str:
        return self._property_name

    @property
    def direction(self) -> DIRECTION:
        return self._direction

    @property
    def request_body(self) -> SearchOrderingV2:
        return SearchOrderingV2(field=self._property_name, direction=self._direction)
