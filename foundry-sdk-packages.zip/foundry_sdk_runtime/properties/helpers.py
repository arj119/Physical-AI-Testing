#  (c) Copyright 2023 Palantir Technologies Inc. All rights reserved.
from datetime import date, datetime
from typing import TYPE_CHECKING, Any, Literal, Optional, TypeVar

from foundry_sdk_runtime.derived_properties import DerivedPropertyType
from foundry_sdk_runtime.errors import InvalidPropertyTypeError

from ..geoshapes import BBox

if TYPE_CHECKING:
    from .object_type_property import ObjectTypeProperty

NUMERICAL_TYPES = [int, float, datetime, date, DerivedPropertyType]

RANGE_ELEMENT_TYPE = TypeVar("RANGE_ELEMENT_TYPE", date, datetime, float, int)

GROUP_BY_TYPE_TO_PARAM_NAME = {
    "fixedWidth": "fixedWidth",
    "ranges": "ranges",
    "exact": "maxGroupCount",
    "duration": "value",
}

PAGE_SIZE_LIMIT = 1000

DIRECTION = Literal["asc", "desc"]


def valid_bbox(bbox: BBox) -> bool:
    """
    Method used to validate if a bounding box passed into a search expression is valid.
    """
    if not (isinstance(bbox, list) and len(bbox) == 4 and all(isinstance(item, (int, float)) for item in bbox)):
        return False
    else:
        return True


def validate_property_type_is_numeric(property: "ObjectTypeProperty") -> None:
    if property.property_type not in NUMERICAL_TYPES:
        raise InvalidPropertyTypeError(property)


def validate_property_list(
    properties: Optional[list["ObjectTypeProperty"]] = None,
) -> None:
    from .object_type_property import ObjectTypeProperty

    if properties and (
        not isinstance(properties, list) or not all(isinstance(prop, ObjectTypeProperty) for prop in properties)
    ):
        raise ValueError("The select operation requires a list of ObjectTypeProperty.")


def group_by_request_body(
    group_by_type: str,
    property_name: str,
    group_by_param_value: Optional[Any] = None,
    duration_unit: Optional[str] = None,
    include_null_values: bool | None = None,
    default_value: Any | None = None,
) -> dict[str, list[dict[str, Any]]]:
    group_by_clause: dict[str, Any] = {"type": group_by_type, "field": property_name}
    if group_by_param_value:
        group_by_clause[GROUP_BY_TYPE_TO_PARAM_NAME[group_by_type]] = group_by_param_value
    if duration_unit:
        group_by_clause["unit"] = duration_unit
    if include_null_values:
        group_by_clause["includeNullValues"] = include_null_values
    if default_value is not None:
        group_by_clause["defaultValue"] = default_value
    return {"groupBy": [group_by_clause]}


class AggregationType:
    def __init__(self, aggregation_type: str, property_name: Optional[str] = None):
        self._aggregation_type = aggregation_type
        self._property_name = property_name

    def _to_query(self, name: Optional[str] = None) -> dict[str, str]:
        request_body = {"type": self._aggregation_type}
        if self._property_name:
            request_body["field"] = self._property_name
        if name:
            request_body["name"] = name
        return request_body
