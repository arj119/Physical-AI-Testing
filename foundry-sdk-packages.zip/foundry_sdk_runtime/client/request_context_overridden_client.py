import json
from typing import Any, Generic, TypeVar

from foundry_sdk.v2.ontologies.action import ActionClient
from foundry_sdk.v2.ontologies.query import QueryClient
from httpx import Headers

Client = TypeVar("Client", ActionClient, QueryClient)


class RequestContextOverriddenClient(Generic[Client]):
    """
    Context manager that temporarily overwrites the "X-OSDK-Request-Context" header
    in an OntologiesClient for the duration of the context.

    It requires that config and config.default_headers be already present in the
    underlying OntologiesClient.
    """

    _underlying_client: Client
    _request_context: dict[str, Any]
    _old_headers: Headers

    def __init__(
        self,
        underlying_client: Client,
        request_context: dict[str, Any],
    ) -> None:
        self._underlying_client = underlying_client
        self._request_context = request_context
        self._old_headers = underlying_client._api_client._session.headers

    def __enter__(self) -> Client:
        self._underlying_client._api_client._session.headers = {
            **self._old_headers,
            "X-OSDK-Request-Context": json.dumps(self._request_context),
        }
        return self._underlying_client

    def __exit__(self, type: Any, value: Any, traceback: Any) -> None:
        self._underlying_client._api_client._session.headers = self._old_headers
