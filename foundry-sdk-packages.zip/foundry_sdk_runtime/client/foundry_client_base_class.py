#  (c) Copyright 2024 Palantir Technologies Inc. All rights reserved.
from typing import Optional

from foundry_sdk import Auth, Config, UserTokenAuth
from foundry_sdk.v2.ontologies import OntologiesClient

from foundry_sdk_runtime.client_config_helpers import get_value_from_context_or_env
from foundry_sdk_runtime.context_vars import (
    FOUNDRY_HOSTNAME_CONTEXT_VARS,
    FOUNDRY_TOKEN_CONTEXT_VARS,
)
from foundry_sdk_runtime.environment_vars import (
    FOUNDRY_HOSTNAME_ENV_VARS,
    FOUNDRY_TOKEN_ENV_VARS,
)


class FoundryClientBaseClass:
    def __init__(
        self,
        auth: Optional[Auth] = None,
        hostname: Optional[str] = None,
        config: Optional[Config] = None,
    ):
        """
        FoundryClient is the client provided by the osdk to make requests to api gateway.
        The priority by which auth and hostname for FoundryClient is set is:
          1. User input
          2. If there is no user input, then check context variables in foundry_sdk_runtime
          3. If no context variables are set, then check environment variables
        :auth: The auth object used to make requests, can be user token or oauth
        :hostname: The name of the stack used to make the call. Ex: "https://swirl.palantirfoundry.com"
        :config: The configuration passed through to the ontologies client. Notably, any default headers or query params
                 (e.g. the query params required for marketplace remapping OSDK entities) in the config will be included
                  in every request.
        """
        self._hostname = hostname or FoundryClientBaseClass._init_hostname_from_env()
        self._auth = auth or FoundryClientBaseClass._init_user_token_auth_from_env()
        self._ontologies_client = OntologiesClient(auth=self._auth, hostname=self._hostname, config=config)

    @staticmethod
    def _init_hostname_from_env() -> str:
        return get_value_from_context_or_env(
            context_vars=FOUNDRY_HOSTNAME_CONTEXT_VARS,
            env_vars=FOUNDRY_HOSTNAME_ENV_VARS,
        )

    @staticmethod
    def _init_user_token_auth_from_env() -> Auth:
        token = get_value_from_context_or_env(context_vars=FOUNDRY_TOKEN_CONTEXT_VARS, env_vars=FOUNDRY_TOKEN_ENV_VARS)
        return UserTokenAuth(token=token)

    @property
    def auth(self) -> Optional[Auth]:
        return self._auth
