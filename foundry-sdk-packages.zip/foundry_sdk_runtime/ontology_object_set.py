import functools
import math
from abc import ABC, abstractmethod
from collections.abc import Iterable
from functools import cached_property
from typing import (
    TYPE_CHECKING,
    Any,
    Awaitable,
    Generic,
    Iterator,
    Literal,
    Optional,
    Protocol,
    cast,
    get_args,
)

import aioitertools
from foundry_sdk.v2.core.models import PageSize, PageToken
from foundry_sdk.v2.ontologies import AsyncOntologiesClient, OntologiesClient
from foundry_sdk.v2.ontologies.models import (
    DerivedPropertyDefinition,
    LoadObjectSetResponseV2,
    LoadObjectSetV2MultipleObjectTypesResponse,
    ObjectSet,
    ObjectSetBaseType,
    ObjectSetFilterType,
    ObjectSetInterfaceBaseType,
    ObjectSetIntersectionType,
    ObjectSetSubtractType,
    ObjectSetUnionType,
    ObjectSetWithPropertiesType,
    OntologyIdentifier,
    PropertyIdentifier,
    SearchOrderByV2,
    SelectedPropertyApiName,
)
from pydantic import GetCoreSchemaHandler, ValidationInfo
from pydantic_core import core_schema
from typing_extensions import Self, TypedDict, Unpack, override

from foundry_sdk_runtime import BaseObjectT
from foundry_sdk_runtime.aggregations import AggregatableObjectSet
from foundry_sdk_runtime.decorators import beta
from foundry_sdk_runtime.errors import InvalidDerivedPropertyNameError
from foundry_sdk_runtime.ontology_object import OntologyInterface
from foundry_sdk_runtime.properties import (
    ObjectTypeProperty,
)
from foundry_sdk_runtime.properties.helpers import PAGE_SIZE_LIMIT, validate_property_list
from foundry_sdk_runtime.properties.object_type_property import (
    ObjectTypePropertyWithExpression,
    ObjectTypePropertyWithOrderbyExpression,
)
from foundry_sdk_runtime.search import SearchExpressionParser
from foundry_sdk_runtime.types import AsyncObjectIterator, AsyncPageIterator, ObjectIterator, PageIterator

if TYPE_CHECKING:
    import pandas as pd


class ObjectSetLoaderArgs(TypedDict, total=False):
    ontology: OntologyIdentifier
    object_set: ObjectSet
    select: list[SelectedPropertyApiName]
    select_v2: list[PropertyIdentifier] | None
    exclude_rid: bool | None
    order_by: SearchOrderByV2 | None
    page_size: PageSize | None
    page_token: PageToken | None
    snapshot: bool | None


class ObjectSetLoader(Protocol):
    def __call__(
        self,
        **kwargs: Unpack[ObjectSetLoaderArgs],
    ) -> LoadObjectSetV2MultipleObjectTypesResponse | LoadObjectSetResponseV2: ...


class AsyncObjectSetLoader(Protocol):
    def __call__(
        self,
        **kwargs: Unpack[ObjectSetLoaderArgs],
    ) -> Awaitable[LoadObjectSetV2MultipleObjectTypesResponse | LoadObjectSetResponseV2]: ...


class BaseOntologyObjectSet(AggregatableObjectSet[BaseObjectT], ABC, Generic[BaseObjectT]):
    _BASE_OBJECT_CLASS: type[BaseObjectT]
    _ontologies_client: OntologiesClient
    _ontology_rid: str
    _object_set_type: ObjectSet
    _order_by: Optional[SearchOrderByV2] = None
    _selected_properties: Optional[list[Any]] = None

    @property
    @abstractmethod
    def _object_set_loader(self) -> ObjectSetLoader: ...

    @property
    @abstractmethod
    def _async_object_set_loader(self) -> AsyncObjectSetLoader: ...

    def __init__(
        self,
        _ontologies_client: OntologiesClient,
        _ontology_rid: str,
        object_set_type: ObjectSet | None = None,
        order_by: Optional[SearchOrderByV2] = None,
    ):
        super().__init__(_ontologies_client=_ontologies_client, _ontology_rid=_ontology_rid, object_set=self)

        self._ontologies_client = _ontologies_client
        self._ontology_rid = _ontology_rid
        self._order_by = order_by
        self._selected_properties = None

        # doing this constructor-time subclass check instead of an abstract property method overridden
        # in subclasses because you can also pass object_set_type to the constructor
        self._object_set_type = (
            object_set_type
            if object_set_type is not None
            else (
                ObjectSetInterfaceBaseType(interface_type=self.object_type_api_name())
                if issubclass(self._BASE_OBJECT_CLASS, OntologyInterface)
                else ObjectSetBaseType(object_type=self.object_type_api_name())
            )
        )

    @cached_property
    def _async_ontologies_client(self) -> AsyncOntologiesClient:
        return AsyncOntologiesClient(
            self._ontologies_client._auth, self._ontologies_client._hostname, self._ontologies_client._config
        )

    def __eq__(self, other: Any) -> bool:
        return (
            isinstance(other, BaseOntologyObjectSet)
            and type(self) is type(other)
            and self._ontology_rid == other._ontology_rid
            and self._object_set_type == other._object_set_type
            and self._order_by == other._order_by
            and self._selected_properties == other._selected_properties
        )

    def __iter__(self) -> Iterator[BaseObjectT]:
        return self.iterate()

    @beta("async features are in beta and may change in future versions.")
    def __aiter__(self) -> AsyncObjectIterator[BaseObjectT]:
        return self.async_iterate()

    def __repr__(self) -> str:
        return (
            f"{type(self).__name__}("
            f"object_set_type=({self._object_set_type}), "
            f"order_by={self._order_by}, "
            f"selected_properties={self._selected_properties}, "
            f"ontology_rid={self._ontology_rid})"
        )

    @staticmethod
    @abstractmethod
    def object_type_api_name() -> str: ...

    @classmethod
    @abstractmethod
    def init_from_object_set_rid(
        cls, object_set_rid: str, _ontologies_client: Optional[OntologiesClient] = None
    ) -> Self: ...

    def get_object_set_rid(self) -> str:
        response = self._ontologies_client.OntologyObjectSet.create_temporary(
            ontology=self._ontology_rid,
            object_set=self._object_set_type,
        )
        return cast(str, response.object_set_rid)

    def get_object_set_type(self) -> ObjectSet:
        return self._object_set_type

    def _convert_load_object_set_response(
        self, response: LoadObjectSetResponseV2 | LoadObjectSetV2MultipleObjectTypesResponse
    ) -> tuple[str | None, list[BaseObjectT]]:
        from foundry_sdk_runtime.serialization import convert_to_palantir_object

        result = convert_to_palantir_object(
            Iterable[type(self)._BASE_OBJECT_CLASS],  # type: ignore[misc]
            response.data,
            _ontologies_client=self._ontologies_client,
            _ontology_rid=self._ontology_rid,
            paged_response=True,
            interface_to_object_type_mappings=response.interface_to_object_type_mappings
            if isinstance(response, LoadObjectSetV2MultipleObjectTypesResponse)
            else None,
        )

        return response.next_page_token, result

    def _load(
        self,
        include_rid: bool = False,
        page_size: Optional[int] = None,
        next_page_token: Optional[str] = None,
        snapshot: Optional[bool] = None,
        **kwargs: Any,  # TODO(bryantp): remove unused kwargs (possibly breaking change)
    ) -> tuple[Optional[str], list[BaseObjectT]]:
        response = self._object_set_loader(
            ontology=self._ontology_rid,
            object_set=self._object_set_type,
            select=[prop.name for prop in self._selected_properties] if self._selected_properties else [],
            select_v2=[],
            exclude_rid=not include_rid,
            order_by=self._order_by,
            page_size=page_size,
            page_token=next_page_token,
            snapshot=snapshot,
        )

        return self._convert_load_object_set_response(response)

    async def _async_load(
        self,
        include_rid: bool = False,
        page_size: Optional[int] = None,
        next_page_token: Optional[str] = None,
        snapshot: Optional[bool] = None,
    ) -> tuple[Optional[str], list[BaseObjectT]]:
        response = await self._async_object_set_loader(
            ontology=self._ontology_rid,
            object_set=self._object_set_type,
            select=[prop.name for prop in self._selected_properties] if self._selected_properties else [],
            select_v2=[],
            exclude_rid=not include_rid,
            order_by=self._order_by,
            page_size=page_size,
            page_token=next_page_token,
            snapshot=snapshot,
        )

        return self._convert_load_object_set_response(response)

    def _validate_and_set_selected_properties(self, properties: Optional[list[ObjectTypeProperty]]) -> None:
        validate_property_list(properties)
        self._selected_properties = properties

    def page(
        self,
        page_size: Optional[int] = None,
        page_token: Optional[str] = None,
        properties: Optional[list[ObjectTypeProperty]] = None,
        include_rid: bool = False,
    ) -> PageIterator[BaseObjectT]:
        self._validate_and_set_selected_properties(properties)
        return PageIterator[BaseObjectT](
            paged_func=self._load, page_size=page_size, include_rid=include_rid, page_token=page_token
        )

    @beta("async features are in beta and may change in future versions.")
    def async_page(
        self,
        page_size: Optional[int] = None,
        page_token: Optional[str] = None,
        properties: Optional[list[ObjectTypeProperty]] = None,
        include_rid: bool = False,
    ) -> AsyncPageIterator[BaseObjectT]:
        self._validate_and_set_selected_properties(properties)
        return AsyncPageIterator(
            paged_func=self._async_load, page_size=page_size, include_rid=include_rid, page_token=page_token
        )

    def iterate(
        self, properties: Optional[list[ObjectTypeProperty]] = None, include_rid: bool = False
    ) -> ObjectIterator[BaseObjectT]:
        self._validate_and_set_selected_properties(properties)
        return ObjectIterator[BaseObjectT](paged_func=self._load, include_rid=include_rid, snapshot=True)

    @beta("async features are in beta and may change in future versions.")
    def async_iterate(
        self, properties: Optional[list[ObjectTypeProperty]] = None, include_rid: bool = False
    ) -> AsyncObjectIterator[BaseObjectT]:
        self._validate_and_set_selected_properties(properties)
        return AsyncObjectIterator(paged_func=self._async_load, include_rid=include_rid, snapshot=True)

    def take(
        self, num_items: int, properties: Optional[list[ObjectTypeProperty]] = None, include_rid: bool = False
    ) -> list[BaseObjectT]:
        num_pages = math.ceil(num_items / PAGE_SIZE_LIMIT)
        page_size = math.ceil(num_items / num_pages)
        page = self.page(page_size=page_size, properties=properties, include_rid=include_rid)
        if not page._data:
            return []
        else:
            return [item for _ in range(num_pages) for item in next(page)][:num_items]

    @beta("async features are in beta and may change in future versions.")
    async def async_take(
        self, num_items: int, properties: Optional[list[ObjectTypeProperty]] = None, include_rid: bool = False
    ) -> list[BaseObjectT]:
        iterator = self.async_iterate(properties=properties, include_rid=include_rid)
        return [item async for item in aioitertools.islice(iterator, num_items)]

    def where(self, expression: ObjectTypePropertyWithExpression) -> Self:
        """Used for object set filtering. Accepts an expression, e.g. <ObjectOrInterface>.object_type.<property> == 1.
        Returns an <ObjectOrInterface>ObjectSet containing only the objects satisfying the filter expression.

        :param expression: ObjectTypePropertyWithExpression E.g. <ObjectOrInterface>.object_type.<property> == 1
        :return: <ObjectOrInterface>ObjectSet containing the objects satisfying the filter expression.
        :rtype: <ObjectOrInterface>ObjectSet

        Usage::

            >>> object_set = client.ontology.objects.{{ object_type.api_name_sanitized }}.where({{ object_type.api_name_sanitized }}.object_type.<property> == 1)
            >>> object_set
            {{ object_type.api_name_sanitized }}ObjectSet()
        """
        if not isinstance(expression, ObjectTypePropertyWithExpression):
            raise TypeError(
                "The provided expression isn't valid. Example of a valid expression: <ObjectOrInterface>.object_type.<property> == 1"
            )
        query = SearchExpressionParser.visit(expression)
        return self._copy_with(
            object_set_type=ObjectSetFilterType(object_set=self._object_set_type, where=query, type="filter"),
        )

    def intersect(self, other: Self) -> Self:
        return self._copy_with(
            object_set_type=ObjectSetIntersectionType(
                object_sets=[self._object_set_type, other._object_set_type], type="intersect"
            ),
        )

    def union(self, other: Self) -> Self:
        return self._copy_with(
            object_set_type=ObjectSetUnionType(
                object_sets=[self._object_set_type, other._object_set_type],
                type="union",
            ),
        )

    def subtract(self, other: Self) -> Self:
        return self._copy_with(
            object_set_type=ObjectSetSubtractType(
                object_sets=[self._object_set_type, other._object_set_type],
                type="subtract",
            ),
        )

    def order_by(self, expression: ObjectTypePropertyWithOrderbyExpression) -> Self:
        if expression == "relevance":  # type: ignore[comparison-overlap]
            raise TypeError("Invalid input. Interface Object Sets cannot be ordered by relevance.")
        if not isinstance(expression, ObjectTypePropertyWithOrderbyExpression):
            raise TypeError("Invalid input. Ex valid input: Aircraft.object_type.<some_property>.asc()")
        if self._order_by and self._order_by.fields:
            if expression.request_body.field in [f.field for f in self._order_by.fields]:
                raise RuntimeError("Multiple order_by on the same field is not supported.")
        order_by_fields = (self._order_by.fields if self._order_by and self._order_by.fields else []) + [
            expression.request_body
        ]
        return self._copy_with(order_by=SearchOrderByV2(order_type="fields", fields=order_by_fields))

    def _copy_with(
        self,
        object_set_type: Optional[ObjectSet] = None,
        order_by: Optional[SearchOrderByV2] = None,
    ) -> Self:
        """Create a new ObjectSet with the same properties, except for the given overrides."""
        return type(self)(
            _ontologies_client=self._ontologies_client,
            _ontology_rid=self._ontology_rid,
            object_set_type=object_set_type or self._object_set_type,
            order_by=order_by or self._order_by,
        )

    @classmethod
    def __get_pydantic_core_schema__(cls, source_type: Any, handler: GetCoreSchemaHandler) -> core_schema.CoreSchema:
        def validate_from_any(value: Any, info: ValidationInfo) -> BaseOntologyObjectSet[BaseObjectT]:
            ontologies_client = info.context.get("ontologies_client") if info.context else None

            if isinstance(value, BaseOntologyObjectSet):
                return value
            if isinstance(value, str):
                return cls.init_from_object_set_rid(object_set_rid=value, _ontologies_client=ontologies_client)
            raise ValueError(f"Cannot parse {type(value)} as {cls.__name__}")

        def serialize(instance: BaseOntologyObjectSet[BaseObjectT]) -> str:
            return instance.get_object_set_rid()

        return core_schema.with_info_plain_validator_function(
            function=validate_from_any, serialization=core_schema.plain_serializer_function_ser_schema(serialize)
        )

    def to_dataframe(self) -> "pd.DataFrame":
        try:
            import pandas as pd
        except ImportError as e:
            raise ImportError("Pandas is required for .to_dataframe(). Please install pandas.") from e

        column_names = list(type(self)._BASE_OBJECT_CLASS._fields().keys())
        rows = []
        for object in self.iterate():
            rows.append(list(object._asdict().values()))

        return pd.DataFrame(rows, columns=column_names)

    @beta("async features are in beta and may change in future versions.")
    async def async_to_dataframe(self) -> "pd.DataFrame":
        try:
            import pandas as pd
        except ImportError as e:
            raise ImportError("Pandas is required for .to_dataframe(). Please install pandas.") from e

        column_names = list(type(self)._BASE_OBJECT_CLASS._fields().keys())
        rows = []
        async for object in self.async_iterate():
            rows.append(list(object._asdict().values()))

        return pd.DataFrame(rows, columns=column_names)


class OntologyObjectSet(BaseOntologyObjectSet[BaseObjectT], ABC):
    @property
    @override
    def _object_set_loader(self) -> ObjectSetLoader:
        # wrapping in a functools.partial without any arguments applied because for
        # some reason it doesn't typecheck correctly otherwise
        return functools.partial(self._ontologies_client.OntologyObjectSet.load)

    @property
    @override
    def _async_object_set_loader(self) -> AsyncObjectSetLoader:
        return functools.partial(self._async_ontologies_client.OntologyObjectSet.load)

    def order_by(self, expression: ObjectTypePropertyWithOrderbyExpression | Literal["relevance"]) -> Self:
        if expression == "relevance":
            return self._copy_with(
                order_by=SearchOrderByV2(order_type="relevance", fields=[]),
            )
        return super().order_by(expression)

    def with_properties(self, **kwargs: DerivedPropertyDefinition) -> Self:
        invalid_property_names = set(vars(self._BASE_OBJECT_CLASS).keys()) | set(vars(self._BASE_OBJECT_CLASS()).keys())

        for key, value in kwargs.items():
            if not isinstance(value, get_args(get_args(DerivedPropertyDefinition)[0])):
                raise TypeError(
                    f"Failed to assign '{key}'. {value} must be of type DerivedPropertyDefinition. For example, Aircraft.object_type.derived.id"
                )
            if key in invalid_property_names:
                raise InvalidDerivedPropertyNameError(derived_property_name=key)

        return self._copy_with(
            object_set_type=ObjectSetWithPropertiesType(
                derived_properties=kwargs,
                object_set=self._object_set_type,
            ),
        )


class OntologyInterfaceObjectSet(BaseOntologyObjectSet[BaseObjectT], ABC):
    @property
    @override
    def _object_set_loader(self) -> ObjectSetLoader:
        return functools.partial(self._ontologies_client.OntologyObjectSet.load_multiple_object_types, preview=True)

    @property
    @override
    def _async_object_set_loader(self) -> AsyncObjectSetLoader:
        return functools.partial(
            self._async_ontologies_client.OntologyObjectSet.load_multiple_object_types, preview=True
        )

    def _wrap_with_include_all_base_object_properties_set(self) -> None:
        object_set_base_type = ObjectSetInterfaceBaseType(
            interface_type=self._BASE_OBJECT_CLASS.api_name(),
            include_all_base_object_properties=True,
            type="interfaceBase",
        )
        # Intersect object_set_base_type with self._object_set_type, so that include_all_base_object_properties
        # is the include_all_base_object_properties that was passed to the terminal call. E.g. .page(), .iterate(), etc
        self._object_set_type = ObjectSetIntersectionType(
            object_sets=[self._object_set_type, object_set_base_type], type="intersect"
        )

    @override
    def iterate(
        self,
        properties: Optional[list[ObjectTypeProperty]] = None,
        include_rid: bool = False,
        include_all_base_object_properties: bool = False,
    ) -> ObjectIterator[BaseObjectT]:
        if include_all_base_object_properties:
            self._wrap_with_include_all_base_object_properties_set()
        return super().iterate(properties=properties, include_rid=include_rid)

    @override
    def page(
        self,
        page_size: Optional[int] = None,
        page_token: Optional[str] = None,
        properties: Optional[list[ObjectTypeProperty]] = None,
        include_rid: bool = False,
        include_all_base_object_properties: bool = False,
    ) -> PageIterator[BaseObjectT]:
        if include_all_base_object_properties:
            self._wrap_with_include_all_base_object_properties_set()
        return super().page(page_size=page_size, page_token=page_token, properties=properties, include_rid=include_rid)

    @override
    def take(
        self,
        num_items: int,
        properties: Optional[list[ObjectTypeProperty]] = None,
        include_rid: bool = False,
        include_all_base_object_properties: bool = False,
    ) -> list[BaseObjectT]:
        if include_all_base_object_properties:
            self._wrap_with_include_all_base_object_properties_set()
        return super().take(
            num_items=num_items,
            properties=properties,
            include_rid=include_rid,
        )
