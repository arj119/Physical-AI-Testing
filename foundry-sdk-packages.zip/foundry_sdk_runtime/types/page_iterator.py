from typing import Generic, Optional, Protocol, Tuple, TypeVar

T = TypeVar("T")


class GetPageCallable(Protocol[T]):
    def __call__(
        self,
        include_rid: bool,
        page_size: Optional[int],
        next_page_token: Optional[str],
        snapshot: Optional[bool],
    ) -> Tuple[Optional[str], list[T]]: ...


class PageIterator(Generic[T]):
    """A generic class for iterating over paged responses."""

    def __init__(
        self,
        paged_func: GetPageCallable[T],
        page_size: Optional[int] = None,
        include_rid: bool = False,
        page_token: Optional[str] = None,
        snapshot: Optional[bool] = None,
    ) -> None:
        self._page_size = page_size
        self._paged_func = paged_func
        self._next_page_token = page_token
        self._include_rid = include_rid
        self._snapshot = snapshot
        self._has_next = True
        self._get_data()

    @property
    def next_page_token(self) -> Optional[str]:
        return self._next_page_token

    @property
    def data(self) -> list[T]:
        return self._data

    def __iter__(self) -> "PageIterator[T]":
        return self

    def __next__(self) -> list[T]:
        if not self._data and not self._has_next:
            raise StopIteration("End of iteration reached")
        data = self._data
        self._get_data()
        return data

    def _get_data(self) -> None:
        if self._has_next:
            self._next_page_token, self._data = self._paged_func(
                page_size=self._page_size,
                next_page_token=self._next_page_token,
                include_rid=self._include_rid,
                snapshot=self._snapshot,
            )
            self._has_next = self._next_page_token is not None
        else:
            self._data = []
