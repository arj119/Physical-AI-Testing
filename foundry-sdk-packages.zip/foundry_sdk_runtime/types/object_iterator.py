from typing import Iterator, Optional

from .. import BaseObjectT
from .page_iterator import GetPageCallable, PageIterator


class ObjectIterator(Iterator[BaseObjectT]):
    """A generic class for iterating over paged responses."""

    def __init__(
        self,
        paged_func: GetPageCallable[BaseObjectT],
        page_size: Optional[int] = 10_000,
        include_rid: bool = False,
        snapshot: Optional[bool] = None,
    ) -> None:
        self._page_iterator: PageIterator[BaseObjectT] = PageIterator(
            paged_func=paged_func, page_size=page_size, include_rid=include_rid, snapshot=snapshot
        )
        self._data: list[BaseObjectT] = []
        self._index: int = 0

    def __iter__(self) -> Iterator[BaseObjectT]:
        return self

    def __next__(self) -> BaseObjectT:
        while self._index >= len(self._data):
            self._get_data()

        obj = self._data[self._index]
        self._index += 1
        return obj

    def _get_data(self) -> None:
        try:
            self._data = next(self._page_iterator)
            self._index = 0
        except StopIteration:
            raise StopIteration("End of iteration reached")
