from typing import Awaitable, Generic, Optional, Protocol, Tuple, TypeVar

T = TypeVar("T")


class GetAsyncPageCallable(Protocol[T]):
    def __call__(
        self,
        include_rid: bool,
        page_size: Optional[int],
        next_page_token: Optional[str],
        snapshot: Optional[bool],
    ) -> Awaitable[Tuple[Optional[str], list[T]]]: ...


class AsyncPageIterator(Generic[T]):
    """A generic class for iterating over paged responses."""

    def __init__(
        self,
        paged_func: GetAsyncPageCallable[T],
        page_size: Optional[int] = None,
        include_rid: bool = False,
        page_token: Optional[str] = None,
        snapshot: Optional[bool] = None,
    ) -> None:
        self._page_size = page_size
        self._paged_func = paged_func
        self._next_page_token = page_token
        self._include_rid = include_rid
        self._snapshot = snapshot
        self._has_next = True
        self._data: list[T] = []

    @property
    def next_page_token(self) -> Optional[str]:
        return self._next_page_token

    @property
    def data(self) -> list[T]:
        return self._data

    def __aiter__(self) -> "AsyncPageIterator[T]":
        return self

    async def __anext__(self) -> list[T]:
        if not self._has_next:
            raise StopAsyncIteration("End of iteration reached")
        await self._get_data()
        return self._data

    async def _get_data(self) -> None:
        if self._has_next:
            self._next_page_token, self._data = await self._paged_func(
                page_size=self._page_size,
                next_page_token=self._next_page_token,
                include_rid=self._include_rid,
                snapshot=self._snapshot,
            )
            self._has_next = self._next_page_token is not None
        else:
            self._data = []
