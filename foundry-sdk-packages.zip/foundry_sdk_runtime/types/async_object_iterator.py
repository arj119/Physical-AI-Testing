from typing import AsyncIterator, Optional

from .. import BaseObjectT
from .async_page_iterator import AsyncPageIterator, GetAsyncPageCallable


class AsyncObjectIterator(AsyncIterator[BaseObjectT]):
    """A generic class for iterating over async paged responses."""

    def __init__(
        self,
        paged_func: GetAsyncPageCallable[BaseObjectT],
        page_size: Optional[int] = 10_000,
        include_rid: bool = False,
        snapshot: Optional[bool] = None,
    ) -> None:
        self._page_iterator: AsyncPageIterator[BaseObjectT] = AsyncPageIterator(
            paged_func=paged_func, page_size=page_size, include_rid=include_rid, snapshot=snapshot
        )
        self._data: list[BaseObjectT] = []
        self._index: int = 0

    def __aiter__(self) -> AsyncIterator[BaseObjectT]:
        return self

    async def __anext__(self) -> BaseObjectT:
        while self._index >= len(self._data):
            await self._get_data()

        obj = self._data[self._index]
        self._index += 1
        return obj

    async def _get_data(self) -> None:
        try:
            self._data = await self._page_iterator.__anext__()
            self._index = 0
        except StopAsyncIteration:
            raise StopAsyncIteration("End of iteration reached")
