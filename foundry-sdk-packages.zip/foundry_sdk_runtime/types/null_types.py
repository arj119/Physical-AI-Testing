from __future__ import annotations

from enum import Enum
from typing import Any, Literal, Optional


class Unloaded(Enum):
    value = 0

    def __bool__(self) -> Literal[False]:
        return False


class Empty(Enum):
    value = 0

    def __bool__(self) -> Literal[False]:
        return False


NULL_VALUE_MAP: dict[Optional[Empty], Literal["explicitNone", "empty"]] = {
    Empty.value: "empty",
    None: "explicitNone",
}


def extract_null_params(
    params: dict[str, Any | Empty | None],
) -> dict[str, list[Literal["explicitNone", "empty"]]]:
    return {
        "nullParameters": list(
            map(
                lambda n: NULL_VALUE_MAP[n],
                filter(lambda v: v in (None, Empty.value), params.values()),
            )
        )
    }
