#  (c) Copyright 2023 Palantir Technologies Inc. All rights reserved.
from typing import Any

import pydantic

from foundry_sdk_runtime.struct_type import StructType
from foundry_sdk_runtime.value_type import ValueType


def get_type_module(type_name: str) -> str:
    """
    Returns the module name for a given type.

    This is used to dereference and import a type during deserialization. The number of references and hardcoded classes
    is expected to grow as new Ontology features are added.
    """
    if type_name in (
        "BatchApplyActionResponse",
        "SyncApplyActionResponse",
    ):
        return "foundry_sdk_runtime.actions"
    if type_name in (
        "BBox",
        "Distance",
        "Point",
        "GeoPoint",
        "GeometryCollection",
        "LineString",
        "MultiLineString",
        "MultiPoint",
        "MultiPolygon",
        "Polygon",
        "GeoShape",
    ):
        return "foundry_sdk_runtime.geoshapes"
    if type_name == "Attachment":
        return "foundry_sdk_runtime.attachments"
    if type_name == "AggregationMetricResult":
        return "foundry_sdk_runtime.aggregations"
    raise ValueError(f"Unknown type name: {type_name}")


def sanitize_for_hashing(value: Any) -> Any:
    # TODO: Handle more types here as needed
    if isinstance(value, (list, tuple)):
        return tuple(sanitize_for_hashing(v) for v in value)
    if isinstance(value, dict):
        return frozenset((sanitize_for_hashing(k), sanitize_for_hashing(v)) for k, v in value.items())
    if isinstance(value, set):
        return frozenset(sanitize_for_hashing(v) for v in value)
    if isinstance(value, StructType):
        return frozenset((sanitize_for_hashing(k), sanitize_for_hashing(v)) for k, v in value.to_dict().items())
    if isinstance(value, ValueType):
        if isinstance(value, pydantic.BaseModel):
            return frozenset(
                (sanitize_for_hashing(k), sanitize_for_hashing(v)) for k, v in value.model_dump(by_alias=True).items()
            )
        elif isinstance(value, pydantic.RootModel):
            return sanitize_for_hashing(value.root)
        else:
            raise NotImplementedError(
                f"ValueType {type(value)} is not supported for serialization. "
                "Please convert it to a pydantic BaseModel or RootModel before serialization."
            )
    return value
