#  (c) Copyright 2025 Palantir Technologies Inc. All rights reserved.
from typing import Optional

from foundry_sdk.v2.ontologies.models import (
    ApplyActionRequestOptions,
    BatchApplyActionRequestOptions,
)

ApplyActionRequestOptions.model_rebuild()
BatchApplyActionRequestOptions.model_rebuild()


class ActionMode:
    """
    VALIDATE_AND_EXECUTE: Validate the input and execute the action.
    VALIDATE_ONLY: Validate the input without executing the action.
    """

    VALIDATE_AND_EXECUTE = "VALIDATE_AND_EXECUTE"
    VALIDATE_ONLY = "VALIDATE_ONLY"


class ReturnEditsMode:
    """
    ALL: Return all edits. For non-batch actions, this includes deletions.
    NONE: Default, Return no edits.
    """

    ALL = "ALL"
    NONE = "NONE"


class ActionConfig(ApplyActionRequestOptions):
    """ActionConfig lets you configure the behavior of the action."""

    pass


class BatchActionConfig(BatchApplyActionRequestOptions):
    """BatchActionConfig lets you configure the behavior of the batch action."""

    pass


def _get_action_mode(apply_action_mode: Optional[str] = None) -> str:
    if apply_action_mode is None or apply_action_mode == ActionMode.VALIDATE_AND_EXECUTE:
        return "VALIDATE_AND_EXECUTE"
    elif apply_action_mode == ActionMode.VALIDATE_ONLY:
        return "VALIDATE_ONLY"
    raise ValueError(f"Invalid action config (unknown mode): {apply_action_mode}")


def _get_action_return_edits(return_edits_mode: Optional[str] = None, batch: bool = False) -> str:
    """Get the string representation of the ReturnEditsMode."""
    if batch:
        if return_edits_mode in (None, ReturnEditsMode.NONE):
            return "NONE"
        elif return_edits_mode == ReturnEditsMode.ALL:
            return "ALL"
        # Returning all incl. deletions is not supported for batch yet
    else:
        if return_edits_mode in (None, ReturnEditsMode.NONE):
            return "NONE"
        elif return_edits_mode in (ReturnEditsMode.ALL, "ALL_V2_WITH_DELETIONS"):
            return "ALL_V2_WITH_DELETIONS"
    raise ValueError(f"Invalid ReturnEditsMode: {return_edits_mode}")
