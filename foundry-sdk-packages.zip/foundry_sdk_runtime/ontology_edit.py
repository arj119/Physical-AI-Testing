from typing import Any, NamedTuple, Optional, Union


class ObjectLocator(NamedTuple):
    object_api_name: str
    primary_key: Any


class LinkLocator(NamedTuple):
    relationship_api_name: str
    source: ObjectLocator
    target: ObjectLocator


class AddObject(NamedTuple):
    locator: ObjectLocator
    fields: dict[str, Any]


class ModifyObject(NamedTuple):
    locator: ObjectLocator
    fields: dict[str, Optional[Any]]


class DeleteObject(NamedTuple):
    locator: ObjectLocator


class AddLink(NamedTuple):
    relationship_api_name: str
    source: ObjectLocator
    target: ObjectLocator


class RemoveLink(NamedTuple):
    relationship_api_name: str
    source: ObjectLocator
    target: ObjectLocator


OntologyEdit = Union[AddObject, ModifyObject, DeleteObject, AddLink, RemoveLink]


class OntologyEdits:
    def __init__(self) -> None:
        self._add_objects: dict[ObjectLocator, dict[str, Any]] = {}
        self._modify_objects: dict[ObjectLocator, dict[str, Any]] = {}
        self._delete_objects: dict[ObjectLocator, None] = {}
        self._add_links: set[LinkLocator] = set()
        self._remove_links: set[LinkLocator] = set()

    def get_edits(self) -> list[OntologyEdit]:
        edits: list[OntologyEdit] = []
        for locator, fields in self._add_objects.items():
            edits.append(AddObject(locator, fields))
        for locator, fields in self._modify_objects.items():
            edits.append(ModifyObject(locator, fields))
        for locator in self._delete_objects:
            edits.append(DeleteObject(locator))
        for add_link in self._add_links:
            edits.append(AddLink(add_link.relationship_api_name, add_link.source, add_link.target))
        for remove_link in self._remove_links:
            edits.append(
                RemoveLink(
                    remove_link.relationship_api_name,
                    remove_link.source,
                    remove_link.target,
                )
            )
        return edits

    def add(self, locator: ObjectLocator, fields: dict[str, Any]) -> None:
        if locator in self._delete_objects:
            raise ValueError(f"an object with this primary key has already been deleted: {locator}")
        if locator in self._add_objects:
            raise ValueError(f"an object with this primary key has already been created: {locator}")
        if locator in self._modify_objects:
            raise ValueError(f"an object with this primary key has already been modified: {locator}")

        self._add_objects[locator] = fields

    def modify(self, locator: ObjectLocator, fields: dict[str, Any]) -> None:
        if locator in self._delete_objects:
            raise ValueError(f"an object with this primary key has already been deleted: {locator}")

        if locator in self._add_objects:
            self._add_objects[locator].update(fields)
        elif locator in self._modify_objects:
            self._modify_objects[locator].update(fields)
        else:
            self._modify_objects[locator] = fields

    def delete(self, locator: ObjectLocator) -> None:
        if locator in self._add_objects:
            del self._add_objects[locator]
        else:
            if locator in self._modify_objects:
                del self._modify_objects[locator]
            self._delete_objects[locator] = None

    def add_link(self, relation_api_name: str, source: ObjectLocator, target: ObjectLocator) -> None:
        link_locator = LinkLocator(relation_api_name, source, target)
        if link_locator in self._remove_links:
            self._remove_links.remove(link_locator)
        else:
            self._add_links.add(link_locator)

    def remove_link(self, relation_api_name: str, source: ObjectLocator, target: ObjectLocator) -> None:
        link_locator = LinkLocator(relation_api_name, source, target)
        if link_locator in self._add_links:
            self._add_links.remove(link_locator)
        else:
            self._remove_links.add(link_locator)
